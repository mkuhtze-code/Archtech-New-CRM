import React, { useEffect, useMemo, useState } from 'react';
import { BookOpen, Check, ClipboardList, Plus, Ruler, ShoppingCart, Pencil, X } from 'lucide-react';
import { FlashingDesigner } from './FlashingDesigner';
import { FlashingProfile, Project } from '../types/crm';

type WorkshopView = 'library' | 'orders';

interface FlashingOrderLine {
  id: string;
  profileId: string;
  profileName: string;
  quantity: number;
  pieceLengthLm: number;
  totalLinearMetres: number;
  notes?: string;
  createdAt: string;
  status: 'Draft' | 'Ready for production';
}

interface Props {
  view: WorkshopView;
  onChangeView: (view: WorkshopView) => void;
  projects: Project[];
  activeMemberName: string;
  project?: Project;
  onClose?: () => void;
}

const LIBRARY_STORAGE_KEY = 'archtech_flashing_library';
const ORDER_STORAGE_KEY = 'archtech_flashing_orders';

function readStoredArray<T,>(key: string): T[] {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed as T[] : [];
  } catch {
    return [];
  }
}

function makeId(prefix: string) {
  return prefix + '-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8);
}

function developedLength(profile: FlashingProfile) {
  return profile.developedLengthMm || profile.segments.reduce((sum, segment) => sum + segment.lengthMm, 0);
}

function profilePreviewPoints(profile: FlashingProfile) {
  let points: { x: number; y: number }[];
  if (profile.geometryPointsMm?.length === profile.segments.length + 1) {
    // Use the same exact outline the designer reopens, not a rounded-angle approximation.
    points = profile.geometryPointsMm.slice(0, 15).map((point) => ({ x: point.x, y: -point.y }));
  } else {
    points = [{ x: 8, y: 44 }];
    let heading = 0;
    let x = 8;
    let y = 44;
    const segments = profile.segments.slice(0, 14);
    segments.forEach((segment, index) => {
      const length = Math.max(8, segment.lengthMm || 8);
      const scale = 145 / Math.max(1, segments.reduce((sum, item) => sum + Math.max(8, item.lengthMm || 8), 0));
      x += Math.cos(heading * Math.PI / 180) * length * scale;
      y -= Math.sin(heading * Math.PI / 180) * length * scale;
      points.push({ x, y });
      if (index < segments.length - 1) {
        const bend = Math.max(0, Math.min(180, 180 - (segment.angleDeg || 90)));
        heading += bend * (segment.turnDirection || 1);
      }
    });
  }
  const minX = Math.min(...points.map((point) => point.x));
  const maxX = Math.max(...points.map((point) => point.x));
  const minY = Math.min(...points.map((point) => point.y));
  const maxY = Math.max(...points.map((point) => point.y));
  const width = Math.max(1, maxX - minX);
  const height = Math.max(1, maxY - minY);
  const scale = Math.min(210 / width, 66 / height);
  const offsetX = (240 - width * scale) / 2;
  const offsetY = (90 - height * scale) / 2;
  return points.map((point) => `${(offsetX + (point.x - minX) * scale).toFixed(1)},${(offsetY + (point.y - minY) * scale).toFixed(1)}`).join(' ');
}

function ProfileThumbnail({ profile, large = false }: { profile: FlashingProfile; large?: boolean }) {
  return (
    <div className={`flex items-center justify-center rounded-xl border border-slate-200 bg-gradient-to-br from-slate-50 to-slate-100 ${large ? 'h-28' : 'h-20'}`}>
      <svg viewBox="0 0 240 90" role="img" aria-label={`Cross-section drawing of ${profile.name}`} className="h-full w-full max-w-[280px] overflow-visible">
        <polyline points={profilePreviewPoints(profile)} fill="none" stroke="#0284c7" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
        <circle cx="120" cy="45" r="2.5" fill="#0f172a" opacity="0.45" />
      </svg>
    </div>
  );
}

export const FlashingWorkshop: React.FC<Props> = ({ view, onChangeView, projects, activeMemberName, project, onClose }) => {
  const [library, setLibrary] = useState<FlashingProfile[]>(() => readStoredArray<FlashingProfile>(LIBRARY_STORAGE_KEY));
  const [orders, setOrders] = useState<FlashingOrderLine[]>(() => readStoredArray<FlashingOrderLine>(ORDER_STORAGE_KEY));
  const [designerOpen, setDesignerOpen] = useState(false);
  const [workingProfiles, setWorkingProfiles] = useState<FlashingProfile[]>([]);
  const [initialProfileId, setInitialProfileId] = useState<string | null>(null);
  const [designerInstance, setDesignerInstance] = useState(0);
  const [orderProfileId, setOrderProfileId] = useState('');
  const [quantity, setQuantity] = useState('1');
  const [pieceLengthLm, setPieceLengthLm] = useState('3');
  const [orderNotes, setOrderNotes] = useState('');
  const [orderMessage, setOrderMessage] = useState('');

  useEffect(() => {
    localStorage.setItem(LIBRARY_STORAGE_KEY, JSON.stringify(library));
  }, [library]);

  useEffect(() => {
    localStorage.setItem(ORDER_STORAGE_KEY, JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    if (!orderProfileId && library.length > 0) setOrderProfileId(library[0].id);
    if (orderProfileId && !library.some((profile) => profile.id === orderProfileId)) {
      setOrderProfileId(library[0]?.id || '');
    }
  }, [library, orderProfileId]);

  const baseProject = project || projects.find((item) => item.id === project?.id) || projects[0];
  const visibleOrders = project ? orders.filter((line) => line.projectId === project.id) : orders;
  const designerProject = useMemo(() => ({
    ...(baseProject || {}),
    projectNumber: baseProject?.projectNumber || 'FLASHING-DESIGN',
    material: baseProject?.material || 'Kiwicolour® Vitor+ PVDF (The Roofing Store)',
    colorName: baseProject?.colorName || 'Ebony',
    flashingProfiles: workingProfiles
  } as Project), [baseProject, workingProfiles]);

  const openBlankDesigner = () => {
    setWorkingProfiles([]);
    setInitialProfileId(null);
    setDesignerInstance((value) => value + 1);
    setDesignerOpen(true);
  };

  const openLibraryProfile = (profile: FlashingProfile) => {
    setWorkingProfiles([{ ...profile, segments: profile.segments.map((segment) => ({ ...segment })) }]);
    setInitialProfileId(profile.id);
    setDesignerInstance((value) => value + 1);
    setDesignerOpen(true);
  };

  const saveToLibrary = (profile: FlashingProfile) => {
    const name = profile.name.trim();
    if (!name || library.some((item) => item.name.trim().toLowerCase() === name.toLowerCase())) return 'duplicate';
    // Persist synchronously before confirming success. The state effect remains as
    // a fallback for later edits, but the success toast must mean storage succeeded.
    const nextLibrary = [profile, ...library];
    try {
      localStorage.setItem(LIBRARY_STORAGE_KEY, JSON.stringify(nextLibrary));
    } catch (error) {
      console.error('Unable to persist flashing library to this browser storage.', error);
      return 'storage-error';
    }
    setLibrary(nextLibrary);
    return 'saved';
  };

  const addOrderLine = (event: React.FormEvent) => {
    event.preventDefault();
    const profile = library.find((item) => item.id === orderProfileId);
    const count = Number(quantity);
    const length = Number(pieceLengthLm);
    if (!profile || !Number.isFinite(count) || count < 1 || !Number.isInteger(count) || !Number.isFinite(length) || length <= 0) {
      setOrderMessage('Choose a library profile, whole-piece quantity and a length greater than zero.');
      return;
    }
    const line: FlashingOrderLine = {
      id: makeId('fl-order'),
      projectId: project?.id,
      projectName: project?.title,
      profileId: profile.id,
      profileName: profile.name,
      quantity: count,
      pieceLengthLm: length,
      totalLinearMetres: Math.round(count * length * 1000) / 1000,
      notes: orderNotes.trim() || undefined,
      createdAt: new Date().toISOString(),
      status: 'Draft'
    };
    setOrders((previous) => [line, ...previous]);
    setQuantity('1');
    setPieceLengthLm('3');
    setOrderNotes('');
    setOrderMessage('Added to flashing order.');
  };

  const removeOrderLine = (id: string) => setOrders((previous) => previous.filter((line) => line.id !== id));

  if (designerOpen) {
    return (
      <FlashingDesigner
        key={designerInstance}
        project={designerProject}
        activeMemberName={activeMemberName}
        onUpdateProject={(updated) => setWorkingProfiles(updated.flashingProfiles || [])}
        onClose={() => setDesignerOpen(false)}
        initialProfileId={initialProfileId}
        onSaveToLibrary={saveToLibrary}
      />
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-sky-700">
            <Ruler className="h-4 w-4" /> Flashing workshop
          </div>
          <h2 className="mt-1 text-2xl font-bold text-slate-900">{view === 'library' ? 'Flashing Library' : 'Flashing Orders'}</h2>
          {project && <p className="mt-1 text-xs font-semibold text-slate-500">Job: {project.title || project.projectNumber}</p>}
          <p className="mt-1 max-w-2xl text-sm text-slate-500">
            {view === 'library'
              ? 'Build a reusable collection of folded profiles. A drawing enters the library only when you explicitly save it.'
              : 'Select a saved profile, then specify the number of pieces and length of each piece. Orders do not change the profile geometry.'}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
        {onClose && <button onClick={onClose} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-bold text-slate-700"><X className="h-4 w-4" /> Back to site</button>}
        {view === 'library' && (
          <button onClick={openBlankDesigner} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-bold text-white shadow-sm hover:bg-slate-800">
            <Plus className="h-4 w-4" /> New flashing drawing
          </button>
        )}
        </div>
      </div>

      <div className="flex gap-2 border-b border-slate-200">
        <button onClick={() => onChangeView('library')} className={view === 'library' ? 'inline-flex items-center gap-2 border-b-2 border-sky-600 px-3 py-3 text-sm font-bold text-sky-800' : 'inline-flex items-center gap-2 border-b-2 border-transparent px-3 py-3 text-sm font-semibold text-slate-500 hover:text-slate-900'}>
          <BookOpen className="h-4 w-4" /> Library <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs">{library.length}</span>
        </button>
        <button onClick={() => onChangeView('orders')} className={view === 'orders' ? 'inline-flex items-center gap-2 border-b-2 border-sky-600 px-3 py-3 text-sm font-bold text-sky-800' : 'inline-flex items-center gap-2 border-b-2 border-transparent px-3 py-3 text-sm font-semibold text-slate-500 hover:text-slate-900'}>
          <ClipboardList className="h-4 w-4" /> Orders <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs">{visibleOrders.length}</span>
        </button>
      </div>

      {view === 'library' ? (
        <section className="space-y-4">
          <div className="rounded-xl border border-sky-100 bg-sky-50 p-4 text-sm text-sky-950">
            <strong>Explicit-save library.</strong> Drawings are not added automatically. Finish a profile in the designer and choose <em>Save as new library profile</em>. Existing library profiles are never silently replaced. Library and order data currently live in this browser's local storage for this exact site address; they do not sync to other users, devices, or separate Vercel preview URLs.
          </div>
          {library.length === 0 ? (
            <div className="rounded-2xl border-2 border-dashed border-slate-300 bg-white px-6 py-14 text-center">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-slate-100 text-slate-500"><BookOpen className="h-6 w-6" /></div>
              <h3 className="mt-4 text-base font-bold text-slate-900">Your flashing library is empty</h3>
              <p className="mx-auto mt-2 max-w-md text-sm text-slate-500">No example profiles have been preloaded. Create a drawing and explicitly save it here when it is ready to reuse.</p>
              <button onClick={openBlankDesigner} className="mt-5 inline-flex min-h-11 items-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-bold text-white"><Plus className="h-4 w-4" /> Create first profile</button>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
              {library.map((profile) => (
                <article key={profile.id} className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <h3 className="font-bold text-slate-900">{profile.name}</h3>
                      <p className="mt-1 text-xs text-slate-500">{profile.segments.length} edges</p>
                    </div>
                    <span className="rounded-lg bg-slate-100 px-2 py-1 text-[10px] font-bold uppercase text-slate-600">Library</span>
                  </div>
                  <div className="mt-3"><ProfileThumbnail profile={profile} /></div>
                  <div className="mt-3 flex items-center justify-between rounded-lg bg-sky-50 px-3 py-2">
                    <span className="text-xs font-semibold text-sky-900">Full girth</span>
                    <strong className="text-sm text-sky-950">{developedLength(profile)} mm</strong>
                  </div>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {profile.segments.map((segment, index) => (
                      <span key={segment.id} className="rounded-md border border-slate-200 bg-slate-50 px-2 py-1 text-[11px] text-slate-600">L{index + 1} · {segment.lengthMm} mm</span>
                    ))}
                  </div>
                  <div className="mt-4 flex items-center justify-between gap-2 border-t border-slate-100 pt-3">
                    <span className="text-xs text-slate-500">{profile.paintSide || 'outside'} paint · {profile.thicknessMm || 0.55} mm</span>
                    <button onClick={() => openLibraryProfile(profile)} className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-3 py-2 text-xs font-bold text-white"><Pencil className="h-3.5 w-3.5" /> Edit drawing</button>
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>
      ) : (
        <section className="space-y-4">
          <form onSubmit={addOrderLine} className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="mb-4 flex items-center gap-2"><ShoppingCart className="h-5 w-5 text-sky-700" /><h3 className="font-bold text-slate-900">Add flashing order line</h3></div>
            {library.length === 0 ? (
              <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50 p-5 text-sm text-slate-600">
                The library is empty. Create and explicitly save a flashing profile before adding it to an order.
                <button type="button" onClick={() => onChangeView('library')} className="ml-1 font-bold text-sky-700 underline">Open library</button>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 gap-3 md:grid-cols-4">
                  <div className="md:col-span-4">
                    <p className="mb-2 text-xs font-semibold text-slate-600">Choose a flashing profile</p>
                    <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
                      {library.map((profile) => (
                        <button type="button" key={profile.id} onClick={() => setOrderProfileId(profile.id)} aria-pressed={orderProfileId === profile.id}
                          className={`rounded-xl border p-3 text-left transition ${orderProfileId === profile.id ? 'border-sky-500 bg-sky-50 ring-2 ring-sky-100' : 'border-slate-200 bg-white hover:border-slate-300'}`}>
                          <ProfileThumbnail profile={profile} />
                          <div className="mt-2 flex items-start justify-between gap-2">
                            <span className="text-sm font-bold text-slate-900">{profile.name}</span>
                            {orderProfileId === profile.id && <Check className="h-4 w-4 shrink-0 text-sky-700" />}
                          </div>
                          <p className="mt-1 text-xs text-slate-500">Full girth · {developedLength(profile)} mm</p>
                        </button>
                      ))}
                    </div>
                  </div>
                  <label className="text-xs font-semibold text-slate-600">Quantity (pieces)
                    <input type="number" min="1" step="1" required value={quantity} onChange={(event) => setQuantity(event.target.value)} className="mt-1 block min-h-11 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm text-slate-900" />
                  </label>
                  <label className="text-xs font-semibold text-slate-600">Length per piece (m)
                    <input type="number" min="0.1" max="100" step="0.1" required value={pieceLengthLm} onChange={(event) => setPieceLengthLm(event.target.value)} className="mt-1 block min-h-11 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm text-slate-900" />
                  </label>
                </div>
                <label className="mt-3 block text-xs font-semibold text-slate-600">Notes (optional)
                  <input value={orderNotes} onChange={(event) => setOrderNotes(event.target.value)} placeholder="Location, finish, delivery or job reference" className="mt-1 block min-h-11 w-full rounded-lg border border-slate-300 bg-white px-3 text-sm text-slate-900" />
                </label>
                <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                  <p className="text-sm text-slate-600">Total required: <strong className="text-slate-900">{Math.max(0, Number(quantity) || 0) * Math.max(0, Number(pieceLengthLm) || 0)} linear metres</strong></p>
                  <button type="submit" className="inline-flex min-h-11 items-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-bold text-white"><Plus className="h-4 w-4" /> Add to order</button>
                </div>
              </>
            )}
            {orderMessage && <p role="status" className="mt-3 text-sm text-sky-800">{orderMessage}</p>}
          </form>

          <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
            <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3"><h3 className="font-bold text-slate-900">Flashing order lines</h3><span className="text-xs text-slate-500">{visibleOrders.length} lines</span></div>
            {visibleOrders.length === 0 ? (
              <div className="px-6 py-12 text-center text-sm text-slate-500">No flashing order lines yet. Add a saved library profile above.</div>
            ) : (
              <div className="divide-y divide-slate-100">
                {visibleOrders.map((line) => {
                  const orderedProfile = library.find((profile) => profile.id === line.profileId);
                  return (
                  <div key={line.id} className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
                    <div className="flex min-w-0 items-start gap-3">
                      <div className="w-36 shrink-0">{orderedProfile ? <ProfileThumbnail profile={orderedProfile} /> : <div className="flex h-20 items-center justify-center rounded-xl bg-slate-100 text-xs text-slate-400">Profile unavailable</div>}</div>
                      <div className="min-w-0">
                      <h4 className="font-bold text-slate-900">{line.profileName}</h4>
                      <p className="mt-1 text-sm text-slate-600">{line.quantity} pieces × {line.pieceLengthLm} m = <strong>{line.totalLinearMetres} lm</strong></p>
                      {line.notes && <p className="mt-1 text-xs text-slate-500">{line.notes}</p>}
                      {line.projectName && !project && <p className="mt-1 text-xs text-slate-500">Job: {line.projectName}</p>}
                      <p className="mt-1 text-[11px] text-slate-400">Created {new Date(line.createdAt).toLocaleDateString('en-NZ')} · {line.status}</p>
                      </div>
                    </div>
                    <button onClick={() => removeOrderLine(line.id)} className="inline-flex min-h-9 items-center justify-center gap-1 rounded-lg border border-slate-200 px-3 py-2 text-xs font-semibold text-slate-600 hover:border-rose-300 hover:text-rose-700"><X className="h-3.5 w-3.5" /> Remove</button>
                  </div>
                  );
                })}
              </div>
            )}
          </div>
        </section>
      )}
    </div>
  );
};
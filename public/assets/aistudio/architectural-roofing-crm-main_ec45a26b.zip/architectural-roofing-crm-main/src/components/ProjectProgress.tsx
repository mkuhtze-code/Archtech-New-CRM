import React, { useState } from 'react';
import { 
  Project, 
  MilestoneItem, 
  ProjectVariation, 
  TimeEntry, 
  ActivityLogItem, 
  JobWorkflowStage,
  JobChecklistItem,
  ArchitecturalPlan
} from '../types/crm';
import { formatNZD, formatDate } from '../utils/formatters';
import { 
  CheckCircle2, 
  Circle, 
  XCircle,
  FileCheck, 
  Camera, 
  Plus, 
  ExternalLink,
  ShieldCheck,
  AlertTriangle,
  Search,
  MessageSquare,
  Phone,
  Mail,
  Calendar,
  Building,
  MapPin,
  Layers,
  ArrowRight,
  User,
  DollarSign,
  FileCode,
  Trash2,
  ChevronDown,
  ChevronUp,
  Maximize2,
  X,
  Compass,
  Wind,
  Check,
  ClipboardList
} from 'lucide-react';

interface Props {
  projects: Project[];
  onUpdateProject: (updated: Project) => void;
  onOpenClientPortal: (projectId: string) => void;
  selectedProjectId?: string;
  onSelectProject?: (id: string) => void;
}

export const ProjectProgress: React.FC<Props> = ({
  projects,
  onUpdateProject,
  onOpenClientPortal,
  selectedProjectId: externalSelectedId,
  onSelectProject: externalOnSelect
}) => {
  const [internalSelectedId, setInternalSelectedId] = useState<string>(projects[0]?.id || '');
  const selectedProjectId = externalSelectedId || internalSelectedId;
  const setSelectedProjectId = (id: string) => {
    if (externalOnSelect) externalOnSelect(id);
    setInternalSelectedId(id);
  };

  const [activeTab, setActiveTab] = useState<'checklist' | 'plans' | 'photos' | 'variations' | 'activity' | 'compliance'>('checklist');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Custom checklist modal & card-popout states
  const [isPopoutCardsOpen, setIsPopoutCardsOpen] = useState(false);
  const [activeCardIndex, setActiveCardIndex] = useState(0);
  const [isAddChecklistOpen, setIsAddChecklistOpen] = useState(false);
  const [newChecklistLabel, setNewChecklistLabel] = useState('');
  const [newChecklistCategory, setNewChecklistCategory] = useState<JobChecklistItem['category']>('Substrate & Framing');
  const [newChecklistNotes, setNewChecklistNotes] = useState('');

  // Architectural drawing modal
  const [selectedPlanForZoom, setSelectedPlanForZoom] = useState<ArchitecturalPlan | null>(null);

  // Variation form
  const [newVariationTitle, setNewVariationTitle] = useState('');
  const [newVariationDesc, setNewVariationDesc] = useState('');
  const [newVariationCost, setNewVariationCost] = useState<number>(1200);
  const [isAddVariationOpen, setIsAddVariationOpen] = useState(false);

  // Photo form
  const [newPhotoCaption, setNewPhotoCaption] = useState('');
  const [newPhotoUrl, setNewPhotoUrl] = useState('');
  const [isAddPhotoOpen, setIsAddPhotoOpen] = useState(false);

  // Activity Entry Form
  const [activityType, setActivityType] = useState<'note' | 'call' | 'site_visit'>('note');
  const [activityTitle, setActivityTitle] = useState('');
  const [activityDetails, setActivityDetails] = useState('');

  // NZBC collapsible toggle
  const [isNzbcExpanded, setIsNzbcExpanded] = useState(false);

  const selectedProject = projects.find((p) => p.id === selectedProjectId) || projects[0];

  // Helper to ensure project has customizable checklist
  const currentChecklist: JobChecklistItem[] = selectedProject?.customChecklist || [
    {
      id: 'chk-1',
      label: 'Plywood Substrate Moisture Content <18%',
      notes: 'Tested with calibrated probe meter across 10 random points on 19mm CD plywood.',
      category: 'Substrate & Framing',
      status: 'pass',
      completed: true,
      completedAt: '2026-03-20',
      inspectorName: 'Marcus Kuhtze (LBP)'
    },
    {
      id: 'chk-2',
      label: 'Synthetic Breather Underlay & 150mm Overlaps',
      notes: 'The Roofing Store certified underlay laid smooth, mechanically fixed with butyl taped joints.',
      category: 'Underlay & Thermal',
      status: 'pass',
      completed: true,
      completedAt: '2026-03-21',
      inspectorName: 'Marcus Kuhtze (LBP)'
    },
    {
      id: 'chk-3',
      label: 'Tray Clips & Thermal Expansion Movement Cleats',
      notes: 'Stainless steel sliding clips installed at 400mm centers allowing longitudinal expansion.',
      category: 'Clips & Seaming',
      status: 'pending',
      completed: false
    },
    {
      id: 'chk-4',
      label: 'Apron & Barge Flashing Soft-Edge Hooking',
      notes: 'Folded flashings hemmed onto continuous hooked cleats. No exposed direct pierce fixings.',
      category: 'Flashings & Penetrations',
      status: 'pending',
      completed: false
    },
    {
      id: 'chk-5',
      label: 'Roof Penetration Dektite & Upstand Cladding Cleat',
      notes: 'Minimum 150mm vertical upstand above finished roof pan level.',
      category: 'Flashings & Penetrations',
      status: 'pending',
      completed: false
    }
  ];

  const handleUpdateChecklistItemStatus = (itemId: string, newStatus: 'pass' | 'fail' | 'na' | 'pending') => {
    if (!selectedProject) return;
    const updated = currentChecklist.map(item => {
      if (item.id === itemId) {
        return {
          ...item,
          status: newStatus,
          completed: newStatus === 'pass',
          completedAt: newStatus === 'pass' ? new Date().toISOString().split('T')[0] : undefined,
          inspectorName: newStatus === 'pass' ? 'Marcus Kuhtze (LBP)' : undefined
        };
      }
      return item;
    });

    const passedCount = updated.filter(i => i.status === 'pass').length;
    const progressPercent = Math.min(100, Math.round((passedCount / updated.length) * 100));

    const updatedProj: Project = {
      ...selectedProject,
      customChecklist: updated,
      progressPercent,
      activityFeed: [
        {
          id: `act-${Date.now()}`,
          entityId: selectedProject.id,
          entityType: 'project',
          type: 'milestone',
          title: `Checklist Item Updated: ${updated.find(i => i.id === itemId)?.label}`,
          details: `Status set to ${newStatus.toUpperCase()} by Marcus Kuhtze (LBP).`,
          author: 'Marcus Kuhtze (LBP)',
          timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16)
        },
        ...(selectedProject.activityFeed || [])
      ]
    };
    onUpdateProject(updatedProj);
  };

  const handleAddChecklistItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject || !newChecklistLabel.trim()) return;

    const newItem: JobChecklistItem = {
      id: `chk-${Date.now()}`,
      label: newChecklistLabel.trim(),
      notes: newChecklistNotes.trim() || 'Custom site inspection checkpoint for this specific job.',
      category: newChecklistCategory,
      completed: false,
      status: 'pending'
    };

    const updatedProj: Project = {
      ...selectedProject,
      customChecklist: [...currentChecklist, newItem],
      activityFeed: [
        {
          id: `act-${Date.now()}`,
          entityId: selectedProject.id,
          entityType: 'project',
          type: 'note',
          title: `Added Checklist Item: ${newItem.label}`,
          details: `Category: ${newItem.category}. Added directly to job inspection list.`,
          author: 'Marcus Kuhtze (LBP)',
          timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16)
        },
        ...(selectedProject.activityFeed || [])
      ]
    };

    onUpdateProject(updatedProj);
    setNewChecklistLabel('');
    setNewChecklistNotes('');
    setIsAddChecklistOpen(false);
  };

  const handleDeleteChecklistItem = (itemId: string) => {
    if (!selectedProject) return;
    const updated = currentChecklist.filter(i => i.id !== itemId);
    const updatedProj: Project = {
      ...selectedProject,
      customChecklist: updated
    };
    onUpdateProject(updatedProj);
  };

  const handleAddVariation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject || !newVariationTitle) return;

    const newVar: ProjectVariation = {
      id: `var-${Date.now()}`,
      title: newVariationTitle,
      description: newVariationDesc || 'Architectural scope adjustment per site instruction.',
      amountNZD: Number(newVariationCost) || 0,
      status: 'pending_client',
      requestedAt: new Date().toISOString().split('T')[0]
    };

    const newActivity: ActivityLogItem = {
      id: `act-${Date.now()}`,
      entityId: selectedProject.id,
      entityType: 'project',
      type: 'variation',
      title: `Variation Added: ${newVariationTitle} (${formatNZD(newVar.amountNZD)})`,
      details: newVariationDesc || 'Submitted for client digital review.',
      author: 'Marcus Kuhtze (LBP)',
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16)
    };

    const updatedProject: Project = {
      ...selectedProject,
      variations: [...selectedProject.variations, newVar],
      activityFeed: [newActivity, ...(selectedProject.activityFeed || [])]
    };

    onUpdateProject(updatedProject);
    setNewVariationTitle('');
    setNewVariationDesc('');
    setIsAddVariationOpen(false);
  };

  const handleAddActivity = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject || !activityTitle) return;

    const newActivity: ActivityLogItem = {
      id: `act-${Date.now()}`,
      entityId: selectedProject.id,
      entityType: 'project',
      type: activityType,
      title: activityTitle,
      details: activityDetails || 'Logged in activity feed.',
      author: 'Marcus Kuhtze (LBP)',
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16)
    };

    const updatedProject: Project = {
      ...selectedProject,
      activityFeed: [newActivity, ...(selectedProject.activityFeed || [])]
    };

    onUpdateProject(updatedProject);
    setActivityTitle('');
    setActivityDetails('');
  };

  const handleAddPhoto = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject || !newPhotoCaption) return;

    const newPhoto = {
      id: `p-${Date.now()}`,
      url: newPhotoUrl || 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
      caption: newPhotoCaption,
      phase: selectedProject.profile,
      takenAt: new Date().toISOString().split('T')[0],
      uploadedBy: 'Marcus Kuhtze (LBP)'
    };

    const updatedProject: Project = {
      ...selectedProject,
      photos: [newPhoto, ...selectedProject.photos]
    };

    onUpdateProject(updatedProject);
    setNewPhotoCaption('');
    setNewPhotoUrl('');
    setIsAddPhotoOpen(false);
  };

  const handleUpdatePS3 = (status: Project['ps3Status']) => {
    if (!selectedProject) return;
    const updated: Project = {
      ...selectedProject,
      ps3Status: status
    };
    onUpdateProject(updated);
  };

  const filteredProjects = projects.filter(p => 
    p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.projectNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.clientName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const STAGES_LIST: { key: JobWorkflowStage; label: string }[] = [
    { key: 'enquiry_measure', label: '1. Measure' },
    { key: 'quoting', label: '2. Quoting' },
    { key: 'quote_sent', label: '3. Sent' },
    { key: 'pre_start', label: '4. Pre-Start' },
    { key: 'active_onsite', label: '5. On-Site' },
    { key: 'qa_snagging', label: '6. QA & PS3' },
    { key: 'completed', label: '7. Complete' }
  ];

  const currentStageIndex = STAGES_LIST.findIndex(s => s.key === (selectedProject?.jobStage || 'active_onsite'));

  // Default architectural drawings if none assigned yet
  const plansToDisplay: ArchitecturalPlan[] = selectedProject?.architecturalPlans || [
    {
      id: 'plan-01',
      title: 'Roof Layout & Tray Seam Alignment Plan (Rev D)',
      sheetNumber: 'A-201',
      category: 'Roof Plan',
      revision: 'Rev D',
      date: '2026-02-15',
      fileUrl: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=1600&q=90',
      notes: 'Check 450mm tray center alignments with skylight kerbs.'
    },
    {
      id: 'plan-02',
      title: 'Standard Ridge, Valley & Secret-Gutter Details',
      sheetNumber: 'D-501',
      category: 'Flashing Details',
      revision: 'Rev B',
      date: '2026-02-18',
      fileUrl: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1600&q=90',
      notes: 'Minimum 200mm vertical upstand on high-wind ridge roll.'
    },
    {
      id: 'plan-03',
      title: 'Parapet & Cantilever Barge Flashing Schedule',
      sheetNumber: 'D-502',
      category: 'Flashing Details',
      revision: 'Rev C',
      date: '2026-02-20',
      fileUrl: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1600&q=90',
      notes: 'Requires continuous 0.75mm hooked cleat along marine boundary.'
    }
  ];

  return (
    <div className="flex flex-col lg:flex-row gap-5 items-start">
      {/* Left Pane: Project Selector List */}
      <div className="w-full lg:w-80 shrink-0 bg-white rounded-lg border border-slate-200 shadow-2xs overflow-hidden flex flex-col">
        <div className="p-3 border-b border-slate-200 bg-slate-50 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-slate-900">Trade Jobs ({projects.length})</span>
            <span className="text-[11px] font-mono text-slate-500">Job Pipeline</span>
          </div>
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Filter jobs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-3 py-1 text-xs bg-white border border-slate-200 rounded text-slate-900 focus:outline-none focus:border-slate-800"
            />
          </div>
        </div>

        <div className="divide-y divide-slate-100 max-h-[calc(100vh-250px)] overflow-y-auto">
          {filteredProjects.map((proj) => {
            const isSelected = proj.id === selectedProject?.id;
            return (
              <div
                key={proj.id}
                onClick={() => setSelectedProjectId(proj.id)}
                className={`p-3 transition-colors cursor-pointer text-xs space-y-1 ${
                  isSelected ? 'bg-sky-50/80 border-l-4 border-l-sky-600' : 'hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between font-mono text-[11px]">
                  <span className="font-bold text-slate-700">{proj.projectNumber}</span>
                  <span className="font-semibold text-slate-900">{formatNZD(proj.contractValueNZD)}</span>
                </div>
                <h5 className="font-bold text-slate-900 truncate">{proj.title}</h5>
                <p className="text-slate-500 text-[11px] truncate">{proj.clientName} · {proj.architect}</p>
                <div className="flex items-center justify-between pt-1">
                  <div className="w-24 bg-slate-200 h-1 rounded-full overflow-hidden">
                    <div className="bg-slate-900 h-full rounded-full" style={{ width: `${proj.progressPercent}%` }} />
                  </div>
                  <span className="text-[10px] font-mono text-slate-500">{proj.progressPercent}%</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Right Pane: Comprehensive Job Hub */}
      {selectedProject ? (
        <div className="flex-1 w-full bg-white rounded-lg border border-slate-200 shadow-2xs overflow-hidden">
          {/* Main Job Header with complete spec details */}
          <div className="p-5 border-b border-slate-200 space-y-4">
            <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4">
              <div>
                <div className="flex flex-wrap items-center gap-2 text-xs font-mono text-slate-500">
                  <span className="font-bold text-sky-800 bg-sky-50 px-2 py-0.5 rounded border border-sky-100">
                    {selectedProject.projectNumber}
                  </span>
                  <span>·</span>
                  <span>Target: {formatDate(selectedProject.targetCompletionDate || selectedProject.startDate)}</span>
                  <span>·</span>
                  <span className="text-emerald-700 font-semibold flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" /> SiteWise Certified
                  </span>
                </div>
                
                <h3 className="text-xl font-bold text-slate-900 mt-1">{selectedProject.title}</h3>
                
                {/* Client, Architect, Contractor Details */}
                <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600">
                  <span className="font-semibold text-slate-900 flex items-center gap-1">
                    <User className="w-3.5 h-3.5 text-slate-400" />
                    {selectedProject.clientName}
                  </span>
                  {selectedProject.clientPhone && (
                    <a href={`tel:${selectedProject.clientPhone}`} className="text-sky-700 hover:underline flex items-center gap-1 font-mono">
                      <Phone className="w-3 h-3" />
                      {selectedProject.clientPhone}
                    </a>
                  )}
                  {selectedProject.clientEmail && (
                    <a href={`mailto:${selectedProject.clientEmail}`} className="text-sky-700 hover:underline flex items-center gap-1 font-mono">
                      <Mail className="w-3 h-3" />
                      {selectedProject.clientEmail}
                    </a>
                  )}
                  <span className="text-slate-400">|</span>
                  <span>Architect: <strong className="text-slate-800">{selectedProject.architect}</strong></span>
                  <span>Builder: <strong className="text-slate-800">{selectedProject.headContractor}</strong></span>
                </div>

                <p className="text-xs text-slate-500 mt-1 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>{selectedProject.siteAddress}</span>
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  onClick={() => setIsPopoutCardsOpen(true)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-sky-900 bg-sky-50 hover:bg-sky-100 border border-sky-300 rounded-md transition-colors cursor-pointer"
                >
                  <Maximize2 className="w-3.5 h-3.5 text-sky-600" />
                  <span>Inspection Card Mode</span>
                </button>

                <button
                  onClick={() => setIsAddVariationOpen(true)}
                  className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Variation</span>
                </button>

                <button
                  onClick={() => onOpenClientPortal(selectedProject.id)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-md transition-colors cursor-pointer shadow-2xs"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Client Portal</span>
                </button>
              </div>
            </div>

            {/* Pipeline Progress Chevrons */}
            <div className="pt-2 border-t border-slate-100">
              <span className="text-[10px] font-mono font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">
                Workflow Stage:
              </span>
              <div className="grid grid-cols-7 gap-1">
                {STAGES_LIST.map((stage, idx) => {
                  const isPassed = idx < currentStageIndex;
                  const isCurrent = idx === currentStageIndex;
                  return (
                    <div
                      key={stage.key}
                      className={`py-1.5 px-2 text-center text-[10px] font-medium rounded transition-all truncate ${
                        isCurrent
                          ? 'bg-slate-900 text-white font-bold shadow-2xs'
                          : isPassed
                          ? 'bg-sky-50 text-sky-900 font-semibold border border-sky-100'
                          : 'bg-slate-100 text-slate-400'
                      }`}
                    >
                      {stage.label}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Financial & Engineering Specs Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-2 bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs font-mono">
              <div>
                <span className="text-slate-400 block text-[10px]">Contract Value</span>
                <span className="text-sm font-bold text-slate-900">{formatNZD(selectedProject.contractValueNZD)}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Roof / Wall Area</span>
                <span className="text-sm font-bold text-slate-800">{selectedProject.roofAreaM2} m²</span>
              </div>
              <div className="col-span-2">
                <span className="text-slate-400 block text-[10px]">Profile & Coil</span>
                <span className="text-xs font-bold text-slate-800 truncate block">
                  {selectedProject.profile} · {selectedProject.material}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Wind Zone</span>
                <span className="text-xs font-semibold text-slate-700">{selectedProject.windZone}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Exposure Zone</span>
                <span className="text-xs font-semibold text-slate-700">{selectedProject.exposureZone}</span>
              </div>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="flex items-center gap-1 px-5 border-b border-slate-200 bg-slate-50/50 text-xs font-semibold overflow-x-auto">
            <button
              onClick={() => setActiveTab('checklist')}
              className={`py-2.5 px-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'checklist'
                  ? 'border-slate-900 text-slate-900 font-bold'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <ClipboardList className="w-3.5 h-3.5 text-sky-600" />
              <span>Job Checklist ({currentChecklist.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('plans')}
              className={`py-2.5 px-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'plans'
                  ? 'border-slate-900 text-slate-900 font-bold'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <FileCode className="w-3.5 h-3.5 text-indigo-600" />
              <span>Architectural Plans ({plansToDisplay.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('photos')}
              className={`py-2.5 px-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'photos'
                  ? 'border-slate-900 text-slate-900 font-bold'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Camera className="w-3.5 h-3.5 text-emerald-600" />
              <span>Site Photos ({selectedProject.photos.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('variations')}
              className={`py-2.5 px-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'variations'
                  ? 'border-slate-900 text-slate-900 font-bold'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <span>Variations ({selectedProject.variations.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('activity')}
              className={`py-2.5 px-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'activity'
                  ? 'border-slate-900 text-slate-900 font-bold'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5 text-amber-600" />
              <span>Site Diary & Activity ({(selectedProject.activityFeed || []).length})</span>
            </button>
            <button
              onClick={() => setActiveTab('compliance')}
              className={`py-2.5 px-3 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'compliance'
                  ? 'border-slate-900 text-slate-900 font-bold'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5 text-teal-600" />
              <span>PS3 Producer Statement</span>
            </button>
          </div>

          {/* TAB 1: CUSTOMIZABLE JOB CHECKLIST */}
          {activeTab === 'checklist' && (
            <div className="p-6 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Custom Job Inspection Checklist</h4>
                  <p className="text-xs text-slate-500">
                    Add custom checkpoints directly for this job, or open the pop-out inspection card mode.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsAddChecklistOpen(true)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded transition-colors shadow-2xs cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>+ Add Checklist Item</span>
                  </button>
                  <button
                    onClick={() => {
                      setActiveCardIndex(0);
                      setIsPopoutCardsOpen(true);
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-sky-800 bg-sky-50 hover:bg-sky-100 border border-sky-300 rounded transition-colors cursor-pointer"
                  >
                    <Maximize2 className="w-3.5 h-3.5 text-sky-600" />
                    <span>Pop-out Card View</span>
                  </button>
                </div>
              </div>

              {/* Checklist list */}
              <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg overflow-hidden bg-white text-xs">
                {currentChecklist.map((item, idx) => (
                  <div
                    key={item.id}
                    className="p-3.5 hover:bg-slate-50/70 transition-colors flex items-start justify-between gap-3 group"
                  >
                    <div className="flex items-start gap-3 flex-1 min-w-0">
                      <div className="pt-0.5 shrink-0">
                        {item.status === 'pass' ? (
                          <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                        ) : item.status === 'fail' ? (
                          <XCircle className="w-5 h-5 text-rose-600" />
                        ) : (
                          <Circle className="w-5 h-5 text-slate-300" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-baseline justify-between gap-2">
                          <span className="font-bold text-slate-900">
                            {idx + 1}. {item.label}
                          </span>
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-100 text-slate-600 shrink-0">
                            {item.category}
                          </span>
                        </div>
                        {item.notes && <p className="text-slate-600 text-xs mt-0.5">{item.notes}</p>}
                        {item.completedAt && (
                          <span className="text-[11px] text-emerald-800 font-mono mt-1 block">
                            ✓ Passed on {formatDate(item.completedAt)} by {item.inspectorName || 'Marcus Kuhtze'}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Quick Status Buttons */}
                    <div className="flex items-center gap-1 shrink-0 pt-0.5">
                      <button
                        onClick={() => handleUpdateChecklistItemStatus(item.id, 'pass')}
                        className={`px-2 py-1 text-[11px] font-semibold rounded cursor-pointer transition-colors ${
                          item.status === 'pass'
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-100 text-slate-700 hover:bg-emerald-50 hover:text-emerald-800'
                        }`}
                        title="Mark Pass"
                      >
                        Pass
                      </button>
                      <button
                        onClick={() => handleUpdateChecklistItemStatus(item.id, 'fail')}
                        className={`px-2 py-1 text-[11px] font-semibold rounded cursor-pointer transition-colors ${
                          item.status === 'fail'
                            ? 'bg-rose-600 text-white'
                            : 'bg-slate-100 text-slate-700 hover:bg-rose-50 hover:text-rose-800'
                        }`}
                        title="Mark Fail"
                      >
                        Fail
                      </button>
                      <button
                        onClick={() => handleUpdateChecklistItemStatus(item.id, 'na')}
                        className={`px-2 py-1 text-[11px] font-semibold rounded cursor-pointer transition-colors ${
                          item.status === 'na'
                            ? 'bg-slate-700 text-white'
                            : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                        }`}
                        title="Not Applicable"
                      >
                        N/A
                      </button>
                      <button
                        onClick={() => handleDeleteChecklistItem(item.id)}
                        className="p-1 text-slate-400 hover:text-rose-600 rounded transition-colors cursor-pointer"
                        title="Delete checkpoint"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Tucked away NZBC reference accordion */}
              <div className="mt-6 border border-slate-200 rounded-lg bg-slate-50/50 overflow-hidden text-xs">
                <button
                  type="button"
                  onClick={() => setIsNzbcExpanded(!isNzbcExpanded)}
                  className="w-full p-3 flex items-center justify-between text-left font-semibold text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-slate-500" />
                    <span>Technical Reference & NZBC E2/AS1 Standards (Archived Reference)</span>
                  </div>
                  {isNzbcExpanded ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
                </button>

                {isNzbcExpanded && (
                  <div className="p-4 border-t border-slate-200 bg-white space-y-3 text-slate-600">
                    <p>
                      <strong>NZBC E2/AS1 3rd Edition Compliance Notes:</strong> Archtech standing seam profiles must adhere to:
                    </p>
                    <ul className="list-disc pl-5 space-y-1 text-[11px]">
                      <li>Minimum 3° pitch for continuous standing seam trays without transverse laps.</li>
                      <li>Minimum 150mm turn-up for apron flashings into brick, weatherboard or plaster claddings.</li>
                      <li>Cleat spacing: maximum 400mm centers in Extra High wind zones (NZS 3604).</li>
                      <li>Underlay: The Roofing Store heavy-duty synthetic breather underlay, taped with approved butyl.</li>
                      <li>Fasteners: Marine grade 316 stainless steel or TRS Class 4 screws for all coastal locations.</li>
                    </ul>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: ARCHITECTURAL PLANS & SHOP DRAWINGS */}
          {activeTab === 'plans' && (
            <div className="p-6 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Architectural Plans & Shop Drawings</h4>
                  <p className="text-xs text-slate-500">Access construction blueprints, flashing schedules, and engineering details</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {plansToDisplay.map((plan) => (
                  <div
                    key={plan.id}
                    onClick={() => setSelectedPlanForZoom(plan)}
                    className="border border-slate-200 rounded-lg overflow-hidden bg-white hover:border-slate-400 hover:shadow-md transition-all cursor-pointer group flex flex-col"
                  >
                    <div className="relative h-44 bg-slate-900 overflow-hidden">
                      <img
                        src={plan.fileUrl}
                        alt={plan.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 opacity-90 group-hover:opacity-100"
                      />
                      <div className="absolute top-2 left-2 bg-slate-900/80 backdrop-blur-2xs text-white text-[10px] font-mono px-2 py-0.5 rounded">
                        Sheet {plan.sheetNumber} · {plan.revision}
                      </div>
                      <div className="absolute bottom-2 right-2 bg-white/90 text-slate-900 text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1 shadow-2xs">
                        <Maximize2 className="w-3 h-3" />
                        <span>Inspect Plan</span>
                      </div>
                    </div>
                    <div className="p-3.5 space-y-1.5 flex-1 flex flex-col justify-between text-xs">
                      <div>
                        <h5 className="font-bold text-slate-900 group-hover:text-sky-700 transition-colors line-clamp-1">
                          {plan.title}
                        </h5>
                        <p className="text-[11px] text-slate-500 mt-0.5 font-mono">
                          {plan.category} · {plan.date}
                        </p>
                      </div>
                      {plan.notes && (
                        <p className="text-[11px] text-slate-600 bg-slate-50 p-2 rounded border border-slate-100 italic">
                          "{plan.notes}"
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: PHOTOS */}
          {activeTab === 'photos' && (
            <div className="p-6 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Site QA Photo Documentation</h4>
                  <p className="text-xs text-slate-500">Photographic evidence for warranty and LBP Producer Statement</p>
                </div>
                <button
                  onClick={() => setIsAddPhotoOpen(true)}
                  className="px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 rounded hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  + Add Site Photo
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {selectedProject.photos.map((photo) => (
                  <div key={photo.id} className="rounded-lg border border-slate-200 overflow-hidden bg-slate-50 text-xs">
                    <img src={photo.url} alt={photo.caption} className="w-full h-44 object-cover" />
                    <div className="p-3 space-y-1">
                      <span className="font-semibold text-slate-900 block truncate">{photo.caption}</span>
                      <div className="flex items-center justify-between text-[11px] font-mono text-slate-500">
                        <span>{photo.phase}</span>
                        <span>{formatDate(photo.takenAt)}</span>
                      </div>
                    </div>
                  </div>
                ))}
                {selectedProject.photos.length === 0 && (
                  <div className="col-span-3 p-8 text-center border-2 border-dashed border-slate-200 rounded-lg text-slate-400 text-xs">
                    No site photos uploaded yet. Tap "+ Add Site Photo" to attach photos.
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 4: VARIATIONS */}
          {activeTab === 'variations' && (
            <div className="p-6 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Architectural Variations & Site Instructions</h4>
                  <p className="text-xs text-slate-500">Track scope additions and client approval status</p>
                </div>
                <button
                  onClick={() => setIsAddVariationOpen(true)}
                  className="px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 rounded hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  + Add Variation
                </button>
              </div>

              <div className="space-y-3">
                {selectedProject.variations.map((v) => (
                  <div key={v.id} className="p-4 bg-white rounded-lg border border-slate-200 space-y-2 text-xs">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h5 className="font-bold text-slate-900 text-sm">{v.title}</h5>
                        <p className="text-slate-600 mt-0.5">{v.description}</p>
                      </div>
                      <span className="font-mono font-bold text-slate-900 text-sm shrink-0">
                        +{formatNZD(v.amountNZD)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-[11px] font-mono">
                      <span className="text-slate-400">Requested {formatDate(v.requestedAt)}</span>
                      <span className={`px-2 py-0.5 rounded font-bold ${
                        v.status === 'approved' 
                          ? 'bg-emerald-50 text-emerald-800' 
                          : 'bg-amber-50 text-amber-800'
                      }`}>
                        {v.status === 'approved' ? '✓ Client Approved' : '⏳ Pending Client Approval'}
                      </span>
                    </div>
                  </div>
                ))}

                {selectedProject.variations.length === 0 && (
                  <div className="p-8 text-center border-2 border-dashed border-slate-200 rounded-lg text-slate-400 text-xs">
                    No variations on this project. Click "+ Add Variation" to record a scope change.
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 5: SITE DIARY & ACTIVITY FEED */}
          {activeTab === 'activity' && (
            <div className="p-6 space-y-6">
              <form onSubmit={handleAddActivity} className="p-4 bg-slate-50 rounded-lg border border-slate-200 space-y-3 text-xs">
                <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                  <span className="font-bold text-slate-900">Add to Job Activity Log:</span>
                  <div className="flex items-center gap-1 ml-auto">
                    {(['note', 'call', 'site_visit'] as const).map((type) => (
                      <button
                        key={type}
                        type="button"
                        onClick={() => setActivityType(type)}
                        className={`px-2.5 py-1 rounded text-[11px] font-semibold capitalize cursor-pointer transition-colors ${
                          activityType === type
                            ? 'bg-slate-900 text-white'
                            : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        {type === 'note' ? '📝 Note' : type === 'call' ? '📞 Call' : '🏗️ Site Visit'}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <input
                    type="text"
                    required
                    placeholder="Brief description..."
                    value={activityTitle}
                    onChange={(e) => setActivityTitle(e.target.value)}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded bg-white text-slate-900 font-medium"
                  />
                  <textarea
                    rows={2}
                    placeholder="Additional context or notes..."
                    value={activityDetails}
                    onChange={(e) => setActivityDetails(e.target.value)}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded bg-white text-slate-900"
                  />
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="px-4 py-1.5 font-bold text-white bg-slate-900 hover:bg-slate-800 rounded transition-colors shadow-2xs cursor-pointer"
                  >
                    Post to Activity Feed
                  </button>
                </div>
              </form>

              <div>
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-3">
                  Chronological Site Diary
                </h4>
                <div className="relative pl-6 space-y-4 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200 text-xs">
                  {(selectedProject.activityFeed || []).map((item) => (
                    <div key={item.id} className="relative">
                      <div className="absolute -left-6 top-1 w-3 h-3 rounded-full bg-white border-2 border-slate-900" />
                      <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-1">
                        <div className="flex items-baseline justify-between gap-2">
                          <span className="font-bold text-slate-900">{item.title}</span>
                          <span className="font-mono text-[10px] text-slate-400 shrink-0">{item.timestamp}</span>
                        </div>
                        <p className="text-slate-600 text-xs">{item.details}</p>
                        <span className="text-[10px] font-mono text-slate-500 block">Author: {item.author}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: PS3 PRODUCER STATEMENT */}
          {activeTab === 'compliance' && (
            <div className="p-6 space-y-4">
              <div className="p-5 bg-slate-50 rounded-lg border border-slate-200 space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-emerald-600" />
                    <h4 className="font-bold text-slate-900 text-sm">Producer Statement PS3 Construction Sign-off</h4>
                  </div>
                  <span className={`px-2.5 py-1 rounded font-bold uppercase text-[10px] ${
                    selectedProject.ps3Status === 'approved' 
                      ? 'bg-emerald-100 text-emerald-900' 
                      : 'bg-amber-100 text-amber-900'
                  }`}>
                    Status: {selectedProject.ps3Status.replace(/_/g, ' ')}
                  </span>
                </div>
                <p className="text-slate-600">
                  As Licensed Building Practitioners (BP 114820), Archtech confirms the installation of {selectedProject.profile} has been executed according to architectural specification and The Roofing Store technical requirements.
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 font-mono text-[11px]">
                  <div>
                    <span className="text-slate-400 block">LBP Licensee</span>
                    <span className="font-bold text-slate-800">Marcus Kuhtze</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">LBP Number</span>
                    <span className="font-bold text-slate-800">BP 114820</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Warranty Period</span>
                    <span className="font-bold text-slate-800">25 Years (TRS PVDF)</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Council CCC</span>
                    <span className="font-bold text-emerald-800">Ready to File</span>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-200 flex items-center gap-2">
                  <button
                    onClick={() => handleUpdatePS3('approved')}
                    className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded cursor-pointer"
                  >
                    ✓ Authorize PS3 Sign-off
                  </button>
                  <button
                    onClick={() => handleUpdatePS3('lodged_with_council')}
                    className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded cursor-pointer"
                  >
                    Lodge with Local Council
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="flex-1 bg-white p-12 text-center rounded-lg border border-slate-200 text-slate-400 text-xs">
          Select a job from the list to view project details.
        </div>
      )}

      {/* POP-OUT CARD STYLE INSPECTION MODAL */}
      {isPopoutCardsOpen && currentChecklist.length > 0 && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-xl border border-slate-300 shadow-2xl max-w-xl w-full overflow-hidden flex flex-col text-xs">
            {/* Pop-out Card Header */}
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono text-slate-400 block">
                  Card {activeCardIndex + 1} of {currentChecklist.length} · {selectedProject?.projectNumber}
                </span>
                <h3 className="font-bold text-base text-white">{currentChecklist[activeCardIndex].label}</h3>
              </div>
              <button
                onClick={() => setIsPopoutCardsOpen(false)}
                className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Pop-out Card Body */}
            <div className="p-6 space-y-4">
              <div className="inline-block px-2.5 py-1 rounded bg-slate-100 font-mono text-slate-700 text-xs font-semibold">
                Category: {currentChecklist[activeCardIndex].category}
              </div>

              {currentChecklist[activeCardIndex].notes && (
                <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 text-sm text-slate-800 leading-relaxed">
                  {currentChecklist[activeCardIndex].notes}
                </div>
              )}

              {/* Status display */}
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-500">Current Status:</span>
                <span className={`px-2.5 py-1 rounded font-bold uppercase text-[11px] ${
                  currentChecklist[activeCardIndex].status === 'pass'
                    ? 'bg-emerald-100 text-emerald-900'
                    : currentChecklist[activeCardIndex].status === 'fail'
                    ? 'bg-rose-100 text-rose-900'
                    : 'bg-slate-100 text-slate-700'
                }`}>
                  {currentChecklist[activeCardIndex].status}
                </span>
              </div>

              {/* Inspection Buttons on Card */}
              <div className="grid grid-cols-3 gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    handleUpdateChecklistItemStatus(currentChecklist[activeCardIndex].id, 'pass');
                    if (activeCardIndex < currentChecklist.length - 1) {
                      setActiveCardIndex(activeCardIndex + 1);
                    }
                  }}
                  className="py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <Check className="w-4 h-4" />
                  <span>Pass</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    handleUpdateChecklistItemStatus(currentChecklist[activeCardIndex].id, 'fail');
                    if (activeCardIndex < currentChecklist.length - 1) {
                      setActiveCardIndex(activeCardIndex + 1);
                    }
                  }}
                  className="py-3 px-4 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <X className="w-4 h-4" />
                  <span>Fail</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    handleUpdateChecklistItemStatus(currentChecklist[activeCardIndex].id, 'na');
                    if (activeCardIndex < currentChecklist.length - 1) {
                      setActiveCardIndex(activeCardIndex + 1);
                    }
                  }}
                  className="py-3 px-4 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold rounded-lg transition-colors flex items-center justify-center cursor-pointer"
                >
                  <span>N/A</span>
                </button>
              </div>
            </div>

            {/* Card Navigation Footer */}
            <div className="p-4 bg-slate-100 border-t border-slate-200 flex items-center justify-between text-xs">
              <button
                disabled={activeCardIndex === 0}
                onClick={() => setActiveCardIndex(prev => Math.max(0, prev - 1))}
                className="px-3 py-1.5 bg-white border border-slate-300 rounded text-slate-700 font-semibold disabled:opacity-40 cursor-pointer"
              >
                ← Previous Card
              </button>
              <span className="font-mono text-slate-500">
                {activeCardIndex + 1} / {currentChecklist.length}
              </span>
              <button
                disabled={activeCardIndex === currentChecklist.length - 1}
                onClick={() => setActiveCardIndex(prev => Math.min(currentChecklist.length - 1, prev + 1))}
                className="px-3 py-1.5 bg-white border border-slate-300 rounded text-slate-700 font-semibold disabled:opacity-40 cursor-pointer"
              >
                Next Card →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ADD CHECKLIST ITEM MODAL */}
      {isAddChecklistOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-2xs flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-md w-full p-5 space-y-4 shadow-xl border border-slate-200 text-xs">
            <div className="flex items-center justify-between border-b pb-2">
              <h4 className="font-bold text-slate-900 text-sm">Add Checkpoint to Job</h4>
              <button onClick={() => setIsAddChecklistOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleAddChecklistItem} className="space-y-3">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Checkpoint Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Verify Chimney Flashing Apron Upstand"
                  value={newChecklistLabel}
                  onChange={(e) => setNewChecklistLabel(e.target.value)}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded bg-white text-slate-900 font-medium"
                />
              </div>
              <div>
                <label className="block font-medium text-slate-700 mb-1">Category</label>
                <select
                  value={newChecklistCategory}
                  onChange={(e) => setNewChecklistCategory(e.target.value as any)}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded bg-white text-slate-900"
                >
                  <option value="Substrate & Framing">Substrate & Framing</option>
                  <option value="Underlay & Thermal">Underlay & Thermal</option>
                  <option value="Roll-forming & Trays">Roll-forming & Trays</option>
                  <option value="Clips & Seaming">Clips & Seaming</option>
                  <option value="Flashings & Penetrations">Flashings & Penetrations</option>
                  <option value="Safety & Edge Protection">Safety & Edge Protection</option>
                  <option value="Custom Site Check">Custom Site Check</option>
                </select>
              </div>
              <div>
                <label className="block font-medium text-slate-700 mb-1">Inspection Instructions / Acceptance Criteria</label>
                <textarea
                  rows={2}
                  placeholder="What must the site installer check or measure before passing..."
                  value={newChecklistNotes}
                  onChange={(e) => setNewChecklistNotes(e.target.value)}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded bg-white text-slate-900"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddChecklistOpen(false)}
                  className="px-3 py-1.5 text-slate-600 hover:text-slate-900 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 font-bold text-white bg-slate-900 rounded hover:bg-slate-800 cursor-pointer shadow-2xs"
                >
                  Add to Job
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PLAN DETAIL ZOOM MODAL */}
      {selectedPlanForZoom && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 text-white rounded-xl border border-slate-700 shadow-2xl max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden text-xs">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between">
              <div>
                <span className="font-mono text-sky-400 text-[11px] block">
                  Sheet {selectedPlanForZoom.sheetNumber} · {selectedPlanForZoom.category}
                </span>
                <h3 className="font-bold text-base text-white">{selectedPlanForZoom.title}</h3>
              </div>
              <button
                onClick={() => setSelectedPlanForZoom(null)}
                className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-auto bg-slate-950 p-4 flex items-center justify-center">
              <img
                src={selectedPlanForZoom.fileUrl}
                alt={selectedPlanForZoom.title}
                className="max-h-[70vh] w-auto object-contain rounded border border-slate-800 shadow-lg"
              />
            </div>

            <div className="p-4 border-t border-slate-800 bg-slate-900 flex items-center justify-between text-[11px]">
              <div>
                <span className="text-slate-400">Date: {selectedPlanForZoom.date} · Revision: {selectedPlanForZoom.revision}</span>
                {selectedPlanForZoom.notes && (
                  <p className="text-amber-300 mt-0.5">Note: {selectedPlanForZoom.notes}</p>
                )}
              </div>
              <button
                onClick={() => setSelectedPlanForZoom(null)}
                className="px-4 py-1.5 bg-white text-slate-950 font-bold rounded cursor-pointer"
              >
                Close Plan
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ADD PHOTO MODAL */}
      {isAddPhotoOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-2xs flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-md w-full p-5 space-y-4 shadow-xl border border-slate-200 text-xs">
            <div className="flex items-center justify-between border-b pb-2">
              <h4 className="font-bold text-slate-900 text-sm">Add Site Photo</h4>
              <button onClick={() => setIsAddPhotoOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleAddPhoto} className="space-y-3">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Photo Caption *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Ridge soft-edge hook detail at North Elevation"
                  value={newPhotoCaption}
                  onChange={(e) => setNewPhotoCaption(e.target.value)}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded bg-white text-slate-900 font-medium"
                />
              </div>
              <div>
                <label className="block font-medium text-slate-700 mb-1">Image URL (Optional)</label>
                <input
                  type="url"
                  placeholder="Leave empty for site camera default"
                  value={newPhotoUrl}
                  onChange={(e) => setNewPhotoUrl(e.target.value)}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded bg-white text-slate-900"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddPhotoOpen(false)}
                  className="px-3 py-1.5 text-slate-600 hover:text-slate-900 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 font-bold text-white bg-slate-900 rounded hover:bg-slate-800 cursor-pointer shadow-2xs"
                >
                  Save Photo
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD VARIATION MODAL */}
      {isAddVariationOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-2xs flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-md w-full p-5 space-y-4 shadow-xl border border-slate-200 text-xs">
            <h4 className="font-bold text-slate-900 text-sm">Add Scope Variation</h4>
            <form onSubmit={handleAddVariation} className="space-y-3">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Variation Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Additional Velux Skylight Trimming"
                  value={newVariationTitle}
                  onChange={(e) => setNewVariationTitle(e.target.value)}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded bg-white text-slate-900 font-medium"
                />
              </div>
              <div>
                <label className="block font-medium text-slate-700 mb-1">Scope Description</label>
                <textarea
                  rows={2}
                  placeholder="Details of architectural adjustment..."
                  value={newVariationDesc}
                  onChange={(e) => setNewVariationDesc(e.target.value)}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded bg-white text-slate-900"
                />
              </div>
              <div>
                <label className="block font-medium text-slate-700 mb-1">Variation Amount ($NZD) *</label>
                <input
                  type="number"
                  step="50"
                  required
                  value={newVariationCost}
                  onChange={(e) => setNewVariationCost(Number(e.target.value))}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded bg-white font-mono font-bold text-slate-900"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddVariationOpen(false)}
                  className="px-3 py-1.5 text-slate-600 hover:text-slate-900 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 font-bold text-white bg-slate-900 rounded hover:bg-slate-800 cursor-pointer shadow-2xs"
                >
                  Save Variation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useMemo, useState } from 'react';
import { ArrowLeft, Check, Circle, Eraser, Minus, MousePointer2, Pencil, Plus, Ruler, Save, Tag, Trash2, Type } from 'lucide-react';
import { ArchitecturalPlan, PlanMarkupAnnotation, Project } from '../types/crm';

type Tool = 'select' | 'line' | 'measure' | 'area' | 'arrow' | 'text' | 'count' | 'calibrate';
type Point = { x: number; y: number };

interface Props {
  project: Project;
  plan: ArchitecturalPlan;
  memberName: string;
  onUpdateProject: (project: Project) => void;
  onClose: () => void;
}

const tools: { id: Tool; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'select', label: 'Select', icon: MousePointer2 },
  { id: 'line', label: 'Line', icon: Minus },
  { id: 'measure', label: 'Measure', icon: Ruler },
  { id: 'calibrate', label: 'Set scale', icon: Plus },
  { id: 'area', label: 'Area', icon: Circle },
  { id: 'arrow', label: 'Arrow', icon: ArrowLeft },
  { id: 'text', label: 'Note', icon: Type },
  { id: 'count', label: 'Count', icon: Tag }
];

const annotationColor: Record<Tool, string> = {
  select: '#334155', line: '#0284c7', measure: '#ea580c', area: '#16a34a',
  arrow: '#7c3aed', text: '#be123c', count: '#0f766e', calibrate: '#b45309'
};

function makeId() {
  return `markup-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function pointsFrom(annotation: PlanMarkupAnnotation): Point[] {
  const value = annotation.payload.points;
  return Array.isArray(value) ? value as Point[] : [];
}

function polygonArea(points: Point[]): number {
  if (points.length < 3) return 0;
  return Math.abs(points.reduce((sum, point, index) => {
    const next = points[(index + 1) % points.length];
    return sum + point.x * next.y - next.x * point.y;
  }, 0)) / 2;
}

export const PlanMarkupTool: React.FC<Props> = ({ project, plan, memberName, onUpdateProject, onClose }) => {
  const [tool, setTool] = useState<Tool>('line');
  const [draft, setDraft] = useState<Point[]>([]);
  const [note, setNote] = useState('');
  const [label, setLabel] = useState('');
  const [message, setMessage] = useState('');
  const [knownDistance, setKnownDistance] = useState('5000');
  const currentPlan = project.architecturalPlans?.find((item) => item.id === plan.id) || project.plans?.find((item) => item.id === plan.id) || plan;
  const calibration = currentPlan.scaleCalibration;
  const allAnnotations = project.planMarkupAnnotations || [];
  const annotations = useMemo(() => allAnnotations.filter((item) => item.planId === plan.id), [allAnnotations, plan.id]);

  const saveAnnotation = (type: PlanMarkupAnnotation['type'], points: Point[], text?: string) => {
    const annotation: PlanMarkupAnnotation = {
      id: makeId(),
      planId: plan.id,
      projectId: project.id,
      type,
      payload: { points, label: label.trim() || undefined, text: text?.trim() || undefined, tool },
      createdAt: new Date().toISOString(),
      createdBy: memberName || 'User'
    };
    onUpdateProject({ ...project, planMarkupAnnotations: [...allAnnotations, annotation] });
    setDraft([]);
    setLabel('');
    setNote('');
    setMessage('Markup saved to this job.');
  };

  const handlePointerDown = (event: React.PointerEvent<SVGSVGElement>) => {
    if (tool === 'select') return;
    const rect = event.currentTarget.getBoundingClientRect();
    const point = { x: ((event.clientX - rect.left) / rect.width) * 1000, y: ((event.clientY - rect.top) / rect.height) * 700 };
    if (tool === 'calibrate') {
      setDraft((current) => current.length >= 2 ? [point] : [...current, point]);
      setMessage('Tap the two ends of a known dimension, then save the scale.');
      return;
    }
    if (tool === 'count') {
      saveAnnotation('pin', [point], label.trim() || 'Count 1');
      return;
    }
    if (tool === 'text') {
      setDraft([point]);
      return;
    }
    if ((tool === 'measure' || tool === 'arrow') && draft.length >= 2) {
      setDraft([point]);
      return;
    }
    setDraft((current) => [...current, point]);
  };

  const finishDraft = () => {
    if (tool === 'text') {
      if (!draft.length || !note.trim()) { setMessage('Add a note and tap the plan to place it.'); return; }
      saveAnnotation('text', draft, note);
      return;
    }
    const minimum = tool === 'area' ? 3 : 2;
    if (draft.length < minimum) { setMessage(tool === 'area' ? 'Tap at least three points to outline an area.' : 'Tap two points to finish this markup.'); return; }
    const type: PlanMarkupAnnotation['type'] = tool === 'measure' ? 'dimension' : tool === 'arrow' ? 'arrow' : tool === 'area' ? 'cloud' : 'freehand';
    saveAnnotation(type, draft);
  };

  const saveCalibration = () => {
    const realMm = Number(knownDistance);
    if (draft.length !== 2 || !Number.isFinite(realMm) || realMm <= 0) {
      setMessage('Tap two endpoints and enter a real distance greater than zero.');
      return;
    }
    const drawingUnits = Math.hypot(draft[1].x - draft[0].x, draft[1].y - draft[0].y);
    if (drawingUnits < 1) { setMessage('Those points are too close together. Please select the dimension endpoints again.'); return; }
    const updatedPlan = { ...currentPlan, scaleCalibration: { knownDistanceMm: realMm, drawingUnits, mmPerDrawingUnit: realMm / drawingUnits, calibratedAt: new Date().toISOString(), calibratedBy: memberName || 'User' } };
    const updatePlans = (plans?: ArchitecturalPlan[]) => plans?.map((item) => item.id === plan.id ? updatedPlan : item);
    onUpdateProject({ ...project, architecturalPlans: updatePlans(project.architecturalPlans), plans: updatePlans(project.plans) });
    setDraft([]);
    setMessage(`Scale saved: ${realMm.toLocaleString()} mm across the selected points. Measurements now use this calibration.`);
  };

  const removeAnnotation = (id: string) => {
    onUpdateProject({ ...project, planMarkupAnnotations: allAnnotations.filter((item) => item.id !== id) });
    setMessage('Markup removed.');
  };

  const renderShape = (annotation: PlanMarkupAnnotation, isDraft = false) => {
    const points = isDraft ? draft : pointsFrom(annotation);
    if (!points.length) return null;
    const selectedTool = isDraft ? tool : ((annotation.payload.tool as Tool) || 'line');
    const color = annotationColor[selectedTool] || '#0284c7';
    const coords = points.map((point) => `${point.x},${point.y}`).join(' ');
    const first = points[0];
    const last = points[points.length - 1];
    const centre = points.reduce((sum, point) => ({ x: sum.x + point.x / points.length, y: sum.y + point.y / points.length }), { x: 0, y: 0 });
    const areaM2 = calibration ? polygonArea(points) * calibration.mmPerDrawingUnit * calibration.mmPerDrawingUnit / 1000000 : null;
    return (
      <g key={isDraft ? 'draft' : annotation.id}>
        {points.length > 1 && (selectedTool === 'area' || (annotation.type === 'cloud' && selectedTool !== 'area')) ? (
          <polygon points={coords} fill={color} fillOpacity="0.12" stroke={color} strokeWidth="3" strokeDasharray="8 5" />
        ) : points.length > 1 ? (
          <polyline points={coords} fill="none" stroke={color} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
        ) : null}
        {points.map((point, index) => <circle key={index} cx={point.x} cy={point.y} r="5" fill="white" stroke={color} strokeWidth="3" />)}
        {!isDraft && annotation.type === 'text' && <text x={first.x + 12} y={first.y - 12} fontSize="18" fontWeight="700" fill={color} stroke="white" strokeWidth="4" paintOrder="stroke">{String(annotation.payload.text || 'Note')}</text>}
        {!isDraft && annotation.type === 'pin' && <g><circle cx={first.x} cy={first.y} r="17" fill={color} /><text x={first.x} y={first.y + 6} textAnchor="middle" fontSize="16" fontWeight="700" fill="white">{String(annotation.payload.label || '1').slice(0, 3)}</text></g>}
        {!isDraft && annotation.type === 'cloud' && selectedTool === 'area' && points.length >= 3 && <text x={centre.x} y={centre.y} textAnchor="middle" fontSize="18" fontWeight="700" fill={color} stroke="white" strokeWidth="4" paintOrder="stroke">{areaM2 === null ? 'Area · unscaled' : `${areaM2.toFixed(2)} m²`}</text>}
        {!isDraft && annotation.type === 'dimension' && points.length >= 2 && <text x={(first.x + last.x) / 2} y={(first.y + last.y) / 2 - 10} fontSize="17" fontWeight="700" fill={color} stroke="white" strokeWidth="4" paintOrder="stroke">{calibration ? (Math.hypot(last.x - first.x, last.y - first.y) * calibration.mmPerDrawingUnit >= 1000 ? `${(Math.hypot(last.x - first.x, last.y - first.y) * calibration.mmPerDrawingUnit / 1000).toFixed(2)} m` : `${Math.round(Math.hypot(last.x - first.x, last.y - first.y) * calibration.mmPerDrawingUnit)} mm`) : `${(Math.hypot(last.x - first.x, last.y - first.y) / 100).toFixed(2)} units*`}</text>}
        {!isDraft && annotation.payload.label && <text x={first.x + 8} y={first.y + 24} fontSize="16" fontWeight="700" fill={color} stroke="white" strokeWidth="4" paintOrder="stroke">{String(annotation.payload.label)}</text>}
      </g>
    );
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-3 rounded-xl border border-slate-200 bg-white p-3">
        <button type="button" onClick={onClose} className="rounded-lg border border-slate-200 p-2" aria-label="Back to plans"><ArrowLeft className="h-4 w-4" /></button>
        <div className="min-w-0 flex-1"><p className="text-[10px] font-bold uppercase tracking-wide text-slate-500">Quantity surveying · Plan markup</p><h2 className="truncate text-sm font-bold text-slate-900">{plan.title}</h2><p className="text-[11px] text-slate-500">{plan.sheetNumber} · Rev {plan.revision}</p></div>
        <span className="rounded-lg bg-sky-50 px-2 py-1 text-xs font-bold text-sky-800">{annotations.length} markups</span>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white p-3">
        <p className="mb-2 text-xs font-bold text-slate-700">Choose a drawing tool</p>
        <div className="grid grid-cols-4 gap-2 sm:grid-cols-7">
          {tools.map((item) => { const Icon = item.icon; return <button key={item.id} type="button" onClick={() => { setTool(item.id); setDraft([]); setMessage(''); }} aria-pressed={tool === item.id} className={`flex min-h-12 flex-col items-center justify-center gap-1 rounded-lg border px-1 py-2 text-[10px] font-bold ${tool === item.id ? 'border-sky-500 bg-sky-50 text-sky-900' : 'border-slate-200 text-slate-600'}`}><Icon className="h-4 w-4" />{item.label}</button>; })}
        </div>
        <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
          <label className="text-[11px] font-semibold text-slate-600">Label / takeoff reference<input value={label} onChange={(event) => setLabel(event.target.value)} placeholder="e.g. R1, Roof A, North elevation" className="mt-1 min-h-10 w-full rounded-lg border border-slate-200 px-3 text-sm" /></label>
          {tool === 'calibrate' && <label className="text-[11px] font-semibold text-slate-600">Known distance (mm)<input type="number" min="1" step="1" value={knownDistance} onChange={(event) => setKnownDistance(event.target.value)} placeholder="e.g. 5000" className="mt-1 min-h-10 w-full rounded-lg border border-slate-200 px-3 text-sm" /></label>}
          {tool === 'text' && <label className="text-[11px] font-semibold text-slate-600">Note text<input value={note} onChange={(event) => setNote(event.target.value)} placeholder="Add site / QS note" className="mt-1 min-h-10 w-full rounded-lg border border-slate-200 px-3 text-sm" /></label>}
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          {tool === 'calibrate' && <button type="button" onClick={saveCalibration} className="inline-flex min-h-10 items-center gap-2 rounded-lg bg-amber-700 px-3 text-xs font-bold text-white"><Check className="h-4 w-4" /> Save scale</button>}
          {tool !== 'calibrate' && <button type="button" onClick={finishDraft} className="inline-flex min-h-10 items-center gap-2 rounded-lg bg-slate-900 px-3 text-xs font-bold text-white"><Check className="h-4 w-4" /> Finish & save</button>}
          <button type="button" onClick={() => setDraft((current) => current.slice(0, -1))} className="inline-flex min-h-10 items-center gap-2 rounded-lg border border-slate-200 px-3 text-xs font-bold text-slate-700"><Eraser className="h-4 w-4" /> Undo point</button>
          <button type="button" onClick={() => { setDraft([]); setMessage(''); }} className="inline-flex min-h-10 items-center gap-2 rounded-lg border border-slate-200 px-3 text-xs font-bold text-slate-700"><Trash2 className="h-4 w-4" /> Cancel drawing</button>
        </div>
        <p className="mt-2 text-[11px] text-slate-500">Point-to-point workflow: tap each corner or end point, then finish. To calibrate, choose Set scale, tap both ends of a known dimension, enter its real length in mm, and save. {calibration ? `Scale calibrated from ${calibration.knownDistanceMm.toLocaleString()} mm by ${calibration.calibratedBy}.` : 'Measurements remain approximate screen units until calibrated.'}</p>
        {message && <p role="status" className="mt-2 text-xs font-semibold text-sky-800">{message}</p>}
      </div>

      <div className="overflow-hidden rounded-xl border border-slate-300 bg-slate-100">
        <div className="flex items-center justify-between gap-2 border-b border-slate-200 bg-white px-3 py-2"><span className="text-xs font-bold text-slate-800">Drawing canvas</span><span className="text-[10px] text-slate-500">PDF underlay · tap to mark up</span></div>
        <div className="relative aspect-[10/7] w-full touch-none bg-white">
          {plan.fileUrl.toLowerCase().includes('.pdf') ? <iframe title={plan.title} src={`${plan.fileUrl}#toolbar=0&navpanes=0&view=FitH`} className="pointer-events-none absolute inset-0 h-full w-full border-0" /> : <img src={plan.fileUrl} alt={plan.title} className="pointer-events-none absolute inset-0 h-full w-full object-contain" />}
          <svg viewBox="0 0 1000 700" preserveAspectRatio="none" className="absolute inset-0 h-full w-full" onPointerDown={handlePointerDown} style={{ touchAction: 'none', cursor: tool === 'select' ? 'default' : 'crosshair' }}>
            {annotations.map((annotation) => renderShape(annotation))}
            {draft.length > 0 && renderShape({ id: 'draft', planId: plan.id, projectId: project.id, type: 'freehand', payload: { points: draft, tool }, createdAt: '', createdBy: '' }, true)}
          </svg>
        </div>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white">
        <div className="flex items-center justify-between border-b border-slate-100 px-3 py-3"><div><h3 className="text-sm font-bold text-slate-900">Markup register</h3><p className="text-[11px] text-slate-500">Saved to this job record</p></div><span className="text-xs font-bold text-slate-500">{annotations.length} items</span></div>
        {annotations.length === 0 ? <p className="p-4 text-xs text-slate-500">No annotations yet. Select a tool and tap the drawing.</p> : <ul className="divide-y divide-slate-100">{annotations.map((annotation, index) => <li key={annotation.id} className="flex items-center justify-between gap-3 p-3"><div className="min-w-0"><p className="text-xs font-bold text-slate-900">{String(annotation.payload.label || annotation.payload.text || `Markup ${index + 1}`)}</p><p className="text-[10px] text-slate-500">{annotation.type} · {annotation.createdBy} · {new Date(annotation.createdAt).toLocaleDateString('en-NZ')}</p></div><button type="button" onClick={() => removeAnnotation(annotation.id)} aria-label="Delete markup" className="rounded-lg border border-slate-200 p-2 text-slate-500 hover:text-rose-700"><Trash2 className="h-4 w-4" /></button></li>)}</ul>}
      </div>
    </div>
  );
};

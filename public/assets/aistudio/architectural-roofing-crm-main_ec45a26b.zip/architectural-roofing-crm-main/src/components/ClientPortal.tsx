import React, { useState } from 'react';
import { Project, ProjectVariation } from '../types/crm';
import { formatNZD, formatDate } from '../utils/formatters';
import { ArchitecturalSvgDiagram } from './ArchitecturalSvgDiagram';
import { 
  CheckCircle2, 
  Circle, 
  Clock, 
  FileCheck, 
  ShieldCheck, 
  Download, 
  Phone, 
  Mail, 
  Check, 
  X,
  ExternalLink,
  Camera
} from 'lucide-react';

interface Props {
  projects: Project[];
  activeProjectId?: string;
  onUpdateProject: (updated: Project) => void;
  onReturnToStaff: () => void;
}

export const ClientPortal: React.FC<Props> = ({
  projects,
  activeProjectId,
  onUpdateProject,
  onReturnToStaff,
}) => {
  const [selectedProjectId, setSelectedProjectId] = useState<string>(activeProjectId || projects[0]?.id || '');
  const [approvalFeedback, setApprovalFeedback] = useState<string | null>(null);

  const project = projects.find((p) => p.id === selectedProjectId) || projects[0];

  const handleApproveVariation = (variationId: string) => {
    if (!project) return;
    const updatedVars = project.variations.map((v) => {
      if (v.id === variationId) {
        return {
          ...v,
          status: 'approved' as const,
          approvedAt: new Date().toISOString().split('T')[0]
        };
      }
      return v;
    });

    // Calculate added amount to contract value
    const approvedVar = project.variations.find((v) => v.id === variationId);
    const addedAmount = approvedVar ? approvedVar.amountNZD : 0;

    const updated: Project = {
      ...project,
      variations: updatedVars,
      contractValueNZD: project.contractValueNZD + addedAmount
    };

    onUpdateProject(updated);
    setApprovalFeedback('Variation approved and authorized for fabrication!');
    setTimeout(() => setApprovalFeedback(null), 3500);
  };

  const handleDeclineVariation = (variationId: string) => {
    if (!project) return;
    const updatedVars = project.variations.map((v) => {
      if (v.id === variationId) {
        return {
          ...v,
          status: 'declined' as const
        };
      }
      return v;
    });

    const updated: Project = {
      ...project,
      variations: updatedVars
    };

    onUpdateProject(updated);
  };

  if (!project) {
    return (
      <div className="p-12 text-center text-slate-500">
        No active project found for client portal.
      </div>
    );
  }

  const completedMilestones = project.milestones.filter((m) => m.completed).length;
  const pendingVariations = project.variations.filter((v) => v.status === 'pending_client');

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-12">
      {/* Top Welcome Bar & Project Switcher */}
      <div className="bg-slate-900 text-white p-6 rounded-xl shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
            <span>Archtech Architectural Roofing (www.archtech.co.nz) · Client Access Portal</span>
            <span>·</span>
            <span>Ref: {project.projectNumber}</span>
          </div>
          <h1 className="text-2xl font-bold mt-1 text-white">{project.title}</h1>
          <p className="text-xs text-slate-300 mt-0.5">
            Client: {project.clientName} · Architect: {project.architect} · {project.siteAddress}
          </p>
        </div>

        {/* Switch project preview */}
        <div className="flex items-center gap-3">
          <div className="text-right">
            <span className="text-[11px] text-slate-400 block">Switch Project View:</span>
            <select
              value={selectedProjectId}
              onChange={(e) => setSelectedProjectId(e.target.value)}
              className="bg-slate-800 text-white text-xs border border-slate-700 rounded px-2.5 py-1.5 focus:outline-none"
            >
              {projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.title} ({p.region})
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={onReturnToStaff}
            className="px-3.5 py-1.5 text-xs font-semibold text-slate-900 bg-white rounded hover:bg-slate-100 transition-colors cursor-pointer"
          >
            Staff CRM
          </button>
        </div>
      </div>

      {approvalFeedback && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-lg flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span className="font-medium">{approvalFeedback}</span>
        </div>
      )}

      {/* Progress & Specifications Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Progress Card */}
        <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-xs md:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Overall Installation Progress
              </span>
              <h3 className="text-lg font-bold text-slate-900 mt-0.5">
                {project.progressPercent}% Completed
              </h3>
            </div>
            <span className="text-xs font-mono text-slate-500">
              Target Handover: {formatDate(project.targetCompletionDate)}
            </span>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden">
            <div
              className="bg-slate-900 h-full rounded-full transition-all duration-500"
              style={{ width: `${project.progressPercent}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-xs text-slate-600 pt-1">
            <span>{completedMilestones} of {project.milestones.length} milestones signed off</span>
            <span className="font-semibold text-slate-900 capitalize">Current Phase: {project.status.replace('_', ' ')}</span>
          </div>

          {/* Architectural Diagram */}
          <div className="pt-3 border-t border-slate-100">
            <div className="text-xs font-medium text-slate-700 mb-1">
              Your Architectural Profile Specification:
            </div>
            <ArchitecturalSvgDiagram profile={project.profile} />
          </div>
        </div>

        {/* Project Snapshot Card */}
        <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-xs space-y-4">
          <h3 className="text-xs font-semibold text-slate-900 uppercase tracking-wider">
            Specification Details
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <span className="text-slate-500 block">Roof Profile:</span>
              <span className="font-bold text-slate-900">{project.profile}</span>
            </div>
            <div>
              <span className="text-slate-500 block">Material & Color:</span>
              <span className="font-bold text-slate-900">{project.material} ({project.colorName})</span>
            </div>
            <div>
              <span className="text-slate-500 block">Wind Exposure Rating:</span>
              <span className="font-bold text-slate-900">{project.windZone} Wind (NZS 3604)</span>
            </div>
            <div>
              <span className="text-slate-500 block">Total Roof Area:</span>
              <span className="font-mono font-bold text-slate-900">{project.roofAreaM2} m²</span>
            </div>
            <div>
              <span className="text-slate-500 block">Contract Investment:</span>
              <span className="font-mono font-bold text-slate-900 text-sm">{formatNZD(project.contractValueNZD)}</span>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center gap-2 text-xs text-slate-600">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>25-Year Coastal Manufacturer Warranty</span>
          </div>
        </div>
      </div>

      {/* Pending Approvals & Variations Hub */}
      <div className="bg-white rounded-lg border border-slate-200 p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              Pending Variations & Approvals ({pendingVariations.length})
            </h3>
            <p className="text-xs text-slate-500">
              Review architectural site variations submitted by the project team for your approval
            </p>
          </div>
        </div>

        <div className="space-y-3">
          {project.variations.map((variation: ProjectVariation) => {
            const isPending = variation.status === 'pending_client';
            return (
              <div
                key={variation.id}
                className={`p-4 rounded-lg border flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                  isPending ? 'bg-amber-50/60 border-amber-300' : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-xs font-bold text-slate-900">{variation.title}</h4>
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded capitalize font-semibold ${
                      variation.status === 'approved'
                        ? 'bg-emerald-100 text-emerald-800'
                        : variation.status === 'declined'
                        ? 'bg-rose-100 text-rose-800'
                        : 'bg-amber-100 text-amber-900'
                    }`}>
                      {variation.status === 'pending_client' ? 'Action Required' : variation.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1 max-w-xl">{variation.description}</p>
                  <span className="text-[11px] font-mono text-slate-500 mt-1 block">
                    Requested on {formatDate(variation.requestedAt)}
                  </span>
                </div>

                <div className="flex flex-col sm:items-end gap-2 shrink-0">
                  <div className="text-right">
                    <span className="text-base font-bold font-mono text-slate-900 tabular-nums">
                      +{formatNZD(variation.amountNZD)}
                    </span>
                    <span className="block text-[10px] text-slate-500">+ 15% GST</span>
                  </div>

                  {isPending && (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleDeclineVariation(variation.id)}
                        className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded hover:bg-slate-50 transition-colors cursor-pointer"
                      >
                        Decline
                      </button>
                      <button
                        onClick={() => handleApproveVariation(variation.id)}
                        className="px-3.5 py-1.5 text-xs font-bold text-white bg-emerald-700 rounded hover:bg-emerald-800 transition-colors cursor-pointer"
                      >
                        Approve Variation
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          {project.variations.length === 0 && (
            <div className="p-6 text-center text-xs text-slate-500 border border-dashed border-slate-200 rounded-lg">
              No variations recorded. All works are proceeding in accordance with the base contract.
            </div>
          )}
        </div>
      </div>

      {/* Project Milestones Timeline */}
      <div className="bg-white rounded-lg border border-slate-200 p-6 space-y-4">
        <h3 className="text-base font-bold text-slate-900">
          NZBC E2/AS1 Milestone Checklist & Quality Verification
        </h3>

        <div className="space-y-3">
          {project.milestones.map((milestone, idx) => (
            <div
              key={milestone.id}
              className={`p-4 rounded-lg border flex items-start gap-3 ${
                milestone.completed ? 'bg-slate-50/70 border-slate-200' : 'bg-white border-slate-200'
              }`}
            >
              <div className="mt-0.5">
                {milestone.completed ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                ) : (
                  <Circle className="w-5 h-5 text-slate-300" />
                )}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-mono text-slate-400">Phase 0{idx + 1}</span>
                  <h4 className="text-xs font-bold text-slate-900">{milestone.title}</h4>
                </div>
                <p className="text-xs text-slate-600 mt-0.5">{milestone.description}</p>
                {milestone.completed && milestone.completedAt && (
                  <div className="mt-1 text-[11px] font-mono text-slate-500">
                    Inspected & signed off on {formatDate(milestone.completedAt)} by {milestone.inspectorName || 'Senior LBP Roofer'}
                  </div>
                )}
              </div>
              <div className="shrink-0 text-right">
                <span className={`text-xs font-medium ${milestone.completed ? 'text-emerald-700' : 'text-slate-400'}`}>
                  {milestone.completed ? 'Completed' : 'Upcoming'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Site Photos Gallery */}
      {project.photos.length > 0 && (
        <div className="bg-white rounded-lg border border-slate-200 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900">Site Photo Stream</h3>
              <p className="text-xs text-slate-500">
                Direct progress imagery captured by our roofing crew on site
              </p>
            </div>
            <span className="text-xs font-mono text-slate-500">{project.photos.length} photos</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {project.photos.map((photo) => (
              <div key={photo.id} className="rounded-lg border border-slate-200 overflow-hidden bg-slate-50">
                <div className="aspect-video bg-slate-200 overflow-hidden">
                  <img
                    src={photo.url}
                    alt={photo.caption}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                  />
                </div>
                <div className="p-3">
                  <p className="text-xs font-medium text-slate-900">{photo.caption}</p>
                  <span className="text-[11px] font-mono text-slate-500 mt-1 block">
                    {formatDate(photo.takenAt)} · {photo.phase}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Compliance & Document Center */}
      <div className="bg-white rounded-lg border border-slate-200 p-6 space-y-4">
        <h3 className="text-base font-bold text-slate-900">Documentation & Council Compliance</h3>
        <p className="text-xs text-slate-500">
          Official Producer Statements and manufacturer warranties for your local council Code Compliance Certificate (CCC)
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 flex items-start justify-between">
            <div>
              <h4 className="font-bold text-slate-900">Producer Statement PS3</h4>
              <p className="text-slate-600 mt-0.5">Roofing & Cladding Installation</p>
              <span className="text-[10px] font-mono text-slate-500 mt-2 block">
                Council Status: {project.ps3Status.replace('_', ' ')}
              </span>
            </div>
            <Download className="w-4 h-4 text-slate-600 shrink-0 cursor-pointer" />
          </div>

          <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 flex items-start justify-between">
            <div>
              <h4 className="font-bold text-slate-900">The Roofing Store & Kiwicolour®</h4>
              <p className="text-slate-600 mt-0.5">25-Year Marine Warranty Card</p>
              <span className="text-[10px] font-mono text-slate-500 mt-2 block">
                Certificate # TRS-ARCH-2026-992
              </span>
            </div>
            <Download className="w-4 h-4 text-slate-600 shrink-0 cursor-pointer" />
          </div>

          <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 flex items-start justify-between">
            <div>
              <h4 className="font-bold text-slate-900">Care & Maintenance Guide</h4>
              <p className="text-slate-600 mt-0.5">Washing guidelines for coastal zones</p>
              <span className="text-[10px] font-mono text-slate-500 mt-2 block">
                Annual wash-down specs
              </span>
            </div>
            <Download className="w-4 h-4 text-slate-600 shrink-0 cursor-pointer" />
          </div>
        </div>
      </div>
    </div>
  );
};

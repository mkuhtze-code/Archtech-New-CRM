import React, { useState } from 'react';
import { Project, JobWorkflowStage } from '../types/crm';
import { formatNZD, formatDate } from '../utils/formatters';
import { 
  ArrowRight, 
  MapPin, 
  Clock, 
  FileText, 
  CheckCircle2, 
  Plus, 
  Search, 
  ShieldCheck, 
  Layers, 
  Building2,
  Calendar,
  AlertCircle
} from 'lucide-react';

interface Props {
  projects: Project[];
  onUpdateProject: (updated: Project) => void;
  onOpenProjectDetails: (projectId: string) => void;
  onCreateQuoteForProject?: (project: Project) => void;
  onAddNewProject: () => void;
}

interface ColumnDef {
  key: JobWorkflowStage;
  label: string;
  sublabel: string;
  accentColor: string;
  badgeBg: string;
  badgeText: string;
}

const COLUMNS: ColumnDef[] = [
  {
    key: 'enquiry_measure',
    label: '1. Enquiry & Measure',
    sublabel: 'Architectural drawings & site laser scan',
    accentColor: 'border-sky-500',
    badgeBg: 'bg-sky-50',
    badgeText: 'text-sky-800'
  },
  {
    key: 'quoting',
    label: '2. Quoting & Scope',
    sublabel: 'Girth tiers, fixings & TRS pricing',
    accentColor: 'border-amber-500',
    badgeBg: 'bg-amber-50',
    badgeText: 'text-amber-800'
  },
  {
    key: 'quote_sent',
    label: '3. Quote Sent / Review',
    sublabel: 'Client review & electronic signoff',
    accentColor: 'border-purple-500',
    badgeBg: 'bg-purple-50',
    badgeText: 'text-purple-800'
  },
  {
    key: 'pre_start',
    label: '4. Pre-Start & Material',
    sublabel: 'Coil allocation & plywood inspection',
    accentColor: 'border-indigo-500',
    badgeBg: 'bg-indigo-50',
    badgeText: 'text-indigo-800'
  },
  {
    key: 'active_onsite',
    label: '5. Active On-Site',
    sublabel: 'Rollforming, tray fixing & seaming',
    accentColor: 'border-emerald-600',
    badgeBg: 'bg-emerald-50',
    badgeText: 'text-emerald-800'
  },
  {
    key: 'qa_snagging',
    label: '6. QA & PS3 Sign-off',
    sublabel: 'Punch list, moisture audit & CCC',
    accentColor: 'border-teal-600',
    badgeBg: 'bg-teal-50',
    badgeText: 'text-teal-800'
  },
  {
    key: 'completed',
    label: '7. Invoiced & Complete',
    sublabel: 'Handover & 25-yr warranty issued',
    accentColor: 'border-slate-400',
    badgeBg: 'bg-slate-100',
    badgeText: 'text-slate-800'
  }
];

export const JobStatusBoard: React.FC<Props> = ({
  projects,
  onUpdateProject,
  onOpenProjectDetails,
  onAddNewProject
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [profileFilter, setProfileFilter] = useState('all');
  const [regionFilter, setRegionFilter] = useState('all');

  // Helper to determine stage
  const getJobStage = (proj: Project): JobWorkflowStage => {
    if (proj.jobStage) return proj.jobStage;
    if (proj.status === 'completed') return 'completed';
    if (proj.status === 'snagging') return 'qa_snagging';
    if (proj.status === 'in_progress') return 'active_onsite';
    if (proj.progressPercent > 20) return 'pre_start';
    return 'enquiry_measure';
  };

  const handleAdvanceStage = (e: React.MouseEvent, project: Project) => {
    e.stopPropagation();
    const stageOrder: JobWorkflowStage[] = [
      'enquiry_measure',
      'quoting',
      'quote_sent',
      'pre_start',
      'active_onsite',
      'qa_snagging',
      'completed'
    ];
    const current = getJobStage(project);
    const currentIndex = stageOrder.indexOf(current);
    if (currentIndex >= 0 && currentIndex < stageOrder.length - 1) {
      const nextStage = stageOrder[currentIndex + 1];
      const updatedProject: Project = {
        ...project,
        jobStage: nextStage,
        status: nextStage === 'completed' 
          ? 'completed' 
          : nextStage === 'qa_snagging' 
          ? 'snagging' 
          : nextStage === 'active_onsite' 
          ? 'in_progress' 
          : 'pre_construction',
        progressPercent: nextStage === 'completed' ? 100 : Math.max(project.progressPercent, (currentIndex + 1) * 15),
        activityFeed: [
          {
            id: `act-${Date.now()}`,
            entityId: project.id,
            entityType: 'project',
            type: 'milestone',
            title: `Job Advanced to ${COLUMNS.find(c => c.key === nextStage)?.label}`,
            details: `Moved along the Job Status Board by Marcus Kuhtze (LBP).`,
            author: 'Marcus Kuhtze (LBP)',
            timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16)
          },
          ...(project.activityFeed || [])
        ]
      };
      onUpdateProject(updatedProject);
    }
  };

  const filteredProjects = projects.filter((p) => {
    const matchesSearch = 
      p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.projectNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.architect.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.siteAddress.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesProfile = profileFilter === 'all' || p.profile === profileFilter;
    const matchesRegion = regionFilter === 'all' || p.region.toLowerCase().includes(regionFilter.toLowerCase());

    return matchesSearch && matchesProfile && matchesRegion;
  });

  const totalContractValue = filteredProjects.reduce((acc, p) => acc + (p.contractValueNZD || 0), 0);
  const totalM2 = filteredProjects.reduce((acc, p) => acc + (p.roofAreaM2 || 0), 0);

  return (
    <div className="space-y-5">
      {/* Top Control Banner */}
      <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-2xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-slate-500">
              <span className="font-semibold text-slate-900">Archtech Trade Operations</span>
              <span>·</span>
              <span>Job Status Pipeline</span>
              <span>·</span>
              <span className="text-emerald-700 font-semibold flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" /> SiteWise Green Certified
              </span>
            </div>
            <h2 className="text-xl font-bold text-slate-900 mt-1 flex items-center gap-2">
              Job Status Board
              <span className="text-xs font-normal text-slate-500 font-mono">
                ({filteredProjects.length} Trade Jobs · {formatNZD(totalContractValue)} Total Pipeline)
              </span>
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {/* Search Input */}
            <div className="relative min-w-[220px]">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search job #, client, address..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-md focus:bg-white focus:outline-none focus:ring-1 focus:ring-slate-900 font-medium"
              />
            </div>

            {/* Profile Filter */}
            <select
              value={profileFilter}
              onChange={(e) => setProfileFilter(e.target.value)}
              className="text-xs bg-white border border-slate-300 rounded-md px-2.5 py-1.5 text-slate-700 focus:outline-none"
            >
              <option value="all">All Roofing Profiles</option>
              <option value="Archtech Super Seam 38mm">Archtech Super Seam 38mm</option>
              <option value="Archtech Angle Seam">Archtech Angle Seam</option>
              <option value="Archtech Double Angle Seam">Archtech Double Angle Seam</option>
              <option value="Archtech Interlocking Panels">Archtech Interlocking Panels</option>
            </select>

            {/* Region Filter */}
            <select
              value={regionFilter}
              onChange={(e) => setRegionFilter(e.target.value)}
              className="text-xs bg-white border border-slate-300 rounded-md px-2.5 py-1.5 text-slate-700 focus:outline-none"
            >
              <option value="all">All NZ Regions</option>
              <option value="Auckland">Auckland Region</option>
              <option value="Wanaka">Wanaka / Central Otago</option>
              <option value="Waiheke">Waiheke Island</option>
              <option value="Omaha">Omaha / Northland</option>
            </select>

            {/* New Job Button */}
            <button
              onClick={onAddNewProject}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 rounded-md hover:bg-slate-800 transition-colors shadow-2xs cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              + New Trade Job
            </button>
          </div>
        </div>

        {/* Quick Metrics Ribbon */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 pt-3 border-t border-slate-100 text-xs">
          <div className="flex items-center justify-between p-2 rounded bg-slate-50">
            <span className="text-slate-500">Active Jobs:</span>
            <span className="font-mono font-bold text-slate-900">{filteredProjects.length}</span>
          </div>
          <div className="flex items-center justify-between p-2 rounded bg-slate-50">
            <span className="text-slate-500">Contract Value:</span>
            <span className="font-mono font-bold text-slate-900">{formatNZD(totalContractValue)}</span>
          </div>
          <div className="flex items-center justify-between p-2 rounded bg-slate-50">
            <span className="text-slate-500">Surface Area:</span>
            <span className="font-mono font-bold text-slate-900">{totalM2.toLocaleString()} m²</span>
          </div>
          <div className="flex items-center justify-between p-2 rounded bg-slate-50">
            <span className="text-slate-500">Site Compliance:</span>
            <span className="font-mono font-bold text-emerald-800">100% Certified</span>
          </div>
        </div>
      </div>

      {/* Kanban Horizontal Status Columns */}
      <div className="flex gap-4 overflow-x-auto pb-6 pt-1">
        {COLUMNS.map((column) => {
          const colProjects = filteredProjects.filter((p) => getJobStage(p) === column.key);
          const colValue = colProjects.reduce((acc, p) => acc + (p.contractValueNZD || 0), 0);

          return (
            <div
              key={column.key}
              className="flex-shrink-0 w-80 bg-slate-100/70 rounded-lg p-3 flex flex-col max-h-[calc(100vh-250px)] border border-slate-200/80 shadow-2xs"
            >
              {/* Column Header */}
              <div className={`border-t-3 ${column.accentColor} bg-white p-3 rounded-md shadow-2xs mb-3`}>
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                    {column.label}
                  </h4>
                  <span className={`text-[11px] font-mono font-bold px-2 py-0.5 rounded ${column.badgeBg} ${column.badgeText}`}>
                    {colProjects.length}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-1">{column.sublabel}</p>
                <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-100 text-[11px] font-mono">
                  <span className="text-slate-400">Total Value:</span>
                  <span className="font-bold text-slate-800">{formatNZD(colValue)}</span>
                </div>
              </div>

              {/* Cards Container */}
              <div className="flex-1 overflow-y-auto space-y-3 pr-1">
                {colProjects.map((project) => {
                  const pendingVariations = (project.variations || []).filter(v => v.status === 'pending_client');
                  const nextMilestone = (project.milestones || []).find(m => !m.completed);

                  return (
                    <div
                      key={project.id}
                      onClick={() => onOpenProjectDetails(project.id)}
                      className="bg-white rounded-lg p-3.5 border border-slate-200 hover:border-slate-400 transition-all hover:shadow-sm cursor-pointer group space-y-2.5"
                    >
                      {/* Job Number & Progress */}
                      <div className="flex items-center justify-between text-[11px] font-mono">
                        <span className="font-bold text-sky-800 bg-sky-50 px-1.5 py-0.5 rounded border border-sky-100">
                          {project.projectNumber}
                        </span>
                        <span className="text-slate-500 font-medium">
                          {project.progressPercent}% Complete
                        </span>
                      </div>

                      {/* Job Title & Client */}
                      <div>
                        <h5 className="text-sm font-bold text-slate-900 group-hover:text-sky-700 transition-colors line-clamp-1">
                          {project.title}
                        </h5>
                        <p className="text-xs text-slate-600 mt-0.5 flex items-center gap-1.5">
                          <Building2 className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span className="font-medium text-slate-800 truncate">{project.clientName}</span>
                          <span className="text-slate-300">·</span>
                          <span className="text-slate-500 truncate">{project.architect}</span>
                        </p>
                      </div>

                      {/* Address */}
                      <div className="flex items-start gap-1.5 text-xs text-slate-500">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                        <span className="line-clamp-1 text-[11px]">{project.siteAddress}</span>
                      </div>

                      {/* Profile & Material Specs */}
                      <div className="bg-slate-50 p-2 rounded border border-slate-100 text-[11px] space-y-1">
                        <div className="flex items-center justify-between text-slate-700">
                          <span className="font-medium truncate max-w-[170px]">{project.profile}</span>
                          <span className="font-mono font-semibold">{project.roofAreaM2}m²</span>
                        </div>
                        <span className="text-slate-500 block truncate text-[10px]">
                          {project.material} ({project.colorName})
                        </span>
                      </div>

                      {/* Next Action / Milestone */}
                      {nextMilestone && (
                        <div className="text-[11px] text-slate-600 flex items-start gap-1.5">
                          <Clock className="w-3 h-3 text-amber-600 shrink-0 mt-0.5" />
                          <span className="line-clamp-1 text-slate-700 font-medium">
                            Next: {nextMilestone.title}
                          </span>
                        </div>
                      )}

                      {/* Pending Variations Alert */}
                      {pendingVariations.length > 0 && (
                        <div className="flex items-center gap-1.5 text-[10px] text-amber-800 bg-amber-50 p-1.5 rounded border border-amber-200">
                          <AlertCircle className="w-3 h-3 text-amber-600 shrink-0" />
                          <span>
                            {pendingVariations.length} Variation{pendingVariations.length > 1 ? 's' : ''} Awaiting Approval ({formatNZD(pendingVariations.reduce((a, v) => a + v.amountNZD, 0))})
                          </span>
                        </div>
                      )}

                      {/* Progress bar */}
                      <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="bg-slate-900 h-full rounded-full transition-all"
                          style={{ width: `${project.progressPercent}%` }}
                        />
                      </div>

                      {/* Bottom Footer Actions */}
                      <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                        <div>
                          <span className="text-[10px] text-slate-400 block font-mono">Contract Value</span>
                          <span className="font-mono font-bold text-slate-900 text-xs">
                            {formatNZD(project.contractValueNZD)}
                          </span>
                        </div>

                        <div className="flex items-center gap-1">
                          {column.key !== 'completed' && (
                            <button
                              type="button"
                              onClick={(e) => handleAdvanceStage(e, project)}
                              className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded transition-colors cursor-pointer"
                              title="Advance to next workflow stage"
                            >
                              <span>Next Stage</span>
                              <ArrowRight className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}

                {colProjects.length === 0 && (
                  <div className="h-32 flex flex-col items-center justify-center border-2 border-dashed border-slate-200 rounded-lg text-center p-3 text-xs text-slate-400">
                    <span>No jobs currently in this stage</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

import React, { useState, useEffect, useRef } from 'react';
import { 
  Quote, 
  SpreadsheetSection, 
  SpreadsheetRow, 
  Lead, 
  MasterPricingCatalogue,
  RoofingProfile,
  CoilMaterial
} from '../types/crm';
import { formatNZD, formatNZDWithDecimals, calculateGST, formatDate } from '../utils/formatters';
import { evaluateFormula, exportToCSV, copyTableForExcel } from '../utils/excelExporter';
import { OneDriveSyncModal } from './OneDriveSyncModal';
import { 
  Plus, 
  Trash2, 
  Eye, 
  Printer, 
  ShieldCheck, 
  X, 
  Check, 
  ChevronDown, 
  ChevronUp, 
  Layers, 
  FileSpreadsheet, 
  Calculator, 
  Download, 
  Copy, 
  Cloud, 
  ExternalLink, 
  Sparkles, 
  Percent, 
  Sliders, 
  FileText, 
  Settings2, 
  CheckCircle2, 
  AlertCircle, 
  RotateCcw, 
  FolderSync, 
  HelpCircle,
  Building,
  UserCheck,
  Search,
  UploadCloud,
  FileUp,
  Table
} from 'lucide-react';

interface Props {
  quotes: Quote[];
  leads: Lead[];
  catalogue: MasterPricingCatalogue;
  onUpdateQuote: (quote: Quote) => void;
  onAddQuote: (quote: Quote) => void;
  prefillLead?: Lead | null;
  onNavigateToCatalogue?: () => void;
}

export const QuoteBuilder: React.FC<Props> = ({
  quotes,
  leads,
  catalogue,
  onUpdateQuote,
  onAddQuote,
  prefillLead,
  onNavigateToCatalogue
}) => {
  const [selectedQuoteId, setSelectedQuoteId] = useState<string>(quotes[0]?.id || '');
  const activeQuote = quotes.find(q => q.id === selectedQuoteId) || quotes[0];

  // Primary View Mode: Excel Spreadsheet Estimator vs Client Interactive Proposal Portal
  const [viewMode, setViewMode] = useState<'spreadsheet' | 'client_portal'>('spreadsheet');

  // OneDrive modal state
  const [isOneDriveModalOpen, setIsOneDriveModalOpen] = useState(false);

  // Excel Paste Modal
  const [isPasteModalOpen, setIsPasteModalOpen] = useState(false);
  const [pastedText, setPastedText] = useState('');

  // Column visibility toggles for Excel mode
  const [showCostColumns, setShowCostColumns] = useState(true);
  const [showWastageColumn, setShowWastageColumn] = useState(true);
  const [showFormulaColumn, setShowFormulaColumn] = useState(true);
  const [showSupplierColumn, setShowSupplierColumn] = useState(false);

  // Active cell in formula bar
  const [selectedCellInfo, setSelectedCellInfo] = useState<{ rowId: string; colKey: string; cellLabel: string; value: string }>({
    rowId: '',
    colKey: '',
    cellLabel: 'A1',
    value: ''
  });

  // Client Portal State
  const [clientSignerName, setClientSignerName] = useState('');
  const [clientAgreedTerms, setClientAgreedTerms] = useState(false);
  const [isSignedSuccess, setIsSignedSuccess] = useState(false);
  const [copiedToast, setCopiedToast] = useState(false);

  // Copy of spreadsheet sections & rows for the active quote
  const defaultSections: SpreadsheetSection[] = [
    { id: 'sec-1', title: '1. Roll-Formed Roofing & Wall Cladding Trays', colorTag: 'border-l-sky-500' },
    { id: 'sec-2', title: '2. Custom Folded Architectural Flashings (Girth Matrix)', colorTag: 'border-l-amber-500' },
    { id: 'sec-3', title: '3. Fixing Hardware, Thermal Clips & Screws', colorTag: 'border-l-purple-500' },
    { id: 'sec-4', title: '4. Synthetic Breather Underlay & Vapour Control', colorTag: 'border-l-indigo-500' },
    { id: 'sec-5', title: '5. Skylights, Penetrations & Flashings', colorTag: 'border-l-teal-500' },
    { id: 'sec-6', title: '6. Architectural Labour & Mechanical Seaming', colorTag: 'border-l-emerald-600' },
    { id: 'sec-7', title: '7. HIAB Crane Delivery, Scaffolding & Cartage', colorTag: 'border-l-orange-500' },
    { id: 'sec-8', title: '8. Producer Statement PS3 Compliance & CCC Sign-off', colorTag: 'border-l-slate-600' }
  ];

  const defaultRows: SpreadsheetRow[] = [
    // Section 1: Roll-formed Trays
    {
      id: 'row-1',
      sectionId: 'sec-1',
      itemCode: 'SS-38-FLAX',
      description: 'Archtech Super Seam 38mm Tray Pans (450mm centers, 0.55mm Vitor+ PVDF)',
      category: 'Roofing Trays',
      quantity: 633.3,
      unit: 'lm',
      wastagePercent: 5,
      unitCostNZD: 28.50,
      markupPercent: 21,
      unitSellNZD: 34.50,
      totalNZD: 21848.85,
      formula: '=633.3 * 34.50',
      notes: 'Main Gable Roof. Continuous roll-formed pans up to 14.2m with thermal slide clips.',
      supplier: 'The Roofing Store (Albany)'
    },
    {
      id: 'row-2',
      sectionId: 'sec-1',
      itemCode: 'IP-300-MAGNA',
      description: 'Archtech Interlocking Wall Panels (300mm reveal, MagnaFlow® Extreme)',
      category: 'Wall Cladding',
      quantity: 266.7,
      unit: 'lm',
      wastagePercent: 8,
      unitCostNZD: 29.80,
      markupPercent: 22.5,
      unitSellNZD: 36.50,
      totalNZD: 9734.55,
      formula: '=266.7 * 36.50',
      notes: 'North & West Coastal Elevation. 25mm shadow reveal joint.',
      supplier: 'The Roofing Store (Albany)'
    },
    // Section 2: Flashings
    {
      id: 'row-3',
      sectionId: 'sec-2',
      itemCode: 'FL-RIDGE-300',
      description: 'Ventilated Ridge Cap Flashing (Girth 301-450mm, 3 Folds, PVDF)',
      category: 'Flashings',
      quantity: 34,
      unit: 'lm',
      wastagePercent: 5,
      unitCostNZD: 31.00,
      markupPercent: 25.8,
      unitSellNZD: 39.00,
      totalNZD: 1326.00,
      formula: '=34 * 39.00',
      notes: 'Baffled ridge with breathable mesh insert.',
      supplier: 'Archtech Workshop'
    },
    {
      id: 'row-4',
      sectionId: 'sec-2',
      itemCode: 'FL-BARGE-150',
      description: 'Concealed Barge Drip Flashing (Girth 151-300mm, 4 Folds)',
      category: 'Flashings',
      quantity: 48,
      unit: 'lm',
      wastagePercent: 5,
      unitCostNZD: 24.50,
      markupPercent: 28.5,
      unitSellNZD: 31.50,
      totalNZD: 1512.00,
      formula: '=48 * 31.50',
      notes: 'Hemmed onto continuous hooked cleat.',
      supplier: 'Archtech Workshop'
    },
    {
      id: 'row-5',
      sectionId: 'sec-2',
      itemCode: 'FL-APRON-300',
      description: 'Apron Wall Abutment Flashing with 150mm turn-up (Girth 301-450mm)',
      category: 'Flashings',
      quantity: 22,
      unit: 'lm',
      wastagePercent: 5,
      unitCostNZD: 29.00,
      markupPercent: 24.1,
      unitSellNZD: 36.00,
      totalNZD: 792.00,
      formula: '=22 * 36.00',
      notes: 'Chased into weatherboard reglet.',
      supplier: 'Archtech Workshop'
    },
    // Section 3: Hardware
    {
      id: 'row-6',
      sectionId: 'sec-3',
      itemCode: 'CLIP-SS-SLIDE',
      description: 'TRS 316 Stainless Steel Sliding Thermal Movement Clips',
      category: 'Hardware',
      quantity: 1600,
      unit: 'ea',
      wastagePercent: 0,
      unitCostNZD: 0.85,
      markupPercent: 35.3,
      unitSellNZD: 1.15,
      totalNZD: 1840.00,
      formula: '=1600 * 1.15',
      notes: 'Installed at 400mm centers along tray seam.',
      supplier: 'The Roofing Store'
    },
    {
      id: 'row-7',
      sectionId: 'sec-3',
      itemCode: 'FAST-CL4-SS',
      description: 'Class 4 Galvanised / Marine 316 Low-Profile Fixing Screws',
      category: 'Hardware',
      quantity: 3200,
      unit: 'ea',
      wastagePercent: 5,
      unitCostNZD: 0.16,
      markupPercent: 37.5,
      unitSellNZD: 0.22,
      totalNZD: 704.00,
      formula: '=3200 * 0.22',
      notes: 'Wafer head for concealed clip fixing.',
      supplier: 'The Roofing Store'
    },
    // Section 4: Underlay
    {
      id: 'row-8',
      sectionId: 'sec-4',
      itemCode: 'UND-SYN-TRS',
      description: 'The Roofing Store Heavy-Duty Synthetic Breather Membrane Underlay',
      category: 'Underlay',
      quantity: 320,
      unit: 'm2',
      wastagePercent: 12,
      unitCostNZD: 4.80,
      markupPercent: 30.2,
      unitSellNZD: 6.25,
      totalNZD: 2000.00,
      formula: '=320 * 6.25',
      notes: '150mm laps taped with approved butyl tape.',
      supplier: 'The Roofing Store'
    },
    // Section 5: Labour
    {
      id: 'row-9',
      sectionId: 'sec-6',
      itemCode: 'LAB-SEAM-INSTALL',
      description: 'Archtech Certified LBP Standing Seam Installation & Mechanical Double Seaming',
      category: 'Labour',
      quantity: 285,
      unit: 'm2',
      wastagePercent: 0,
      unitCostNZD: 68.00,
      markupPercent: 25.0,
      unitSellNZD: 85.00,
      totalNZD: 24225.00,
      formula: '=285 * 85.00',
      notes: 'Marcus Kuhtze (LBP) site supervision & double mechanical seaming.',
      supplier: 'Archtech Internal Labour'
    },
    // Section 6: Freight
    {
      id: 'row-10',
      sectionId: 'sec-7',
      itemCode: 'FRT-TRS-HIAB',
      description: 'The Roofing Store Dedicated HIAB Crane Truck Delivery (Direct to Roof Level)',
      category: 'Freight',
      quantity: 2,
      unit: 'trip',
      wastagePercent: 0,
      unitCostNZD: 650.00,
      markupPercent: 15.4,
      unitSellNZD: 750.00,
      totalNZD: 1500.00,
      formula: '=2 * 750.00',
      notes: 'Matakana Coast delivery including specialized crane lift.',
      supplier: 'The Roofing Store Logistics'
    },
    // Section 7: Compliance
    {
      id: 'row-11',
      sectionId: 'sec-8',
      itemCode: 'COMP-PS3-CCC',
      description: 'Archtech Producer Statement PS3 Construction Sign-off for Council CCC',
      category: 'Compliance',
      quantity: 1,
      unit: 'sum',
      wastagePercent: 0,
      unitCostNZD: 650.00,
      markupPercent: 30.7,
      unitSellNZD: 850.00,
      totalNZD: 850.00,
      formula: '=1 * 850.00',
      notes: 'Official LBP record of work lodged for Auckland Council code compliance.',
      supplier: 'Archtech LBP'
    }
  ];

  const sections: SpreadsheetSection[] = activeQuote.spreadsheetSections || defaultSections;
  const rows: SpreadsheetRow[] = activeQuote.spreadsheetRows || defaultRows;

  // Calculate live totals from spreadsheet rows
  const subtotalNZD = rows.reduce((acc, r) => acc + (r.totalNZD || 0), 0);
  const costTotalNZD = rows.reduce((acc, r) => acc + ((r.unitCostNZD || 0) * (r.quantity || 0) * (1 + (r.wastagePercent || 0) / 100)), 0);
  const gstNZD = calculateGST(subtotalNZD).gst;
  const totalNZD = subtotalNZD + gstNZD;
  const grossMarginPercent = subtotalNZD > 0 ? Math.round(((subtotalNZD - costTotalNZD) / subtotalNZD) * 1000) / 10 : 0;
  const overallMarkupPercent = costTotalNZD > 0 ? Math.round(((subtotalNZD - costTotalNZD) / costTotalNZD) * 1000) / 10 : 0;

  // Synchronize spreadsheet rows back to quote state
  const syncQuoteSpreadsheet = (newSections: SpreadsheetSection[], newRows: SpreadsheetRow[]) => {
    const newSubtotal = newRows.reduce((acc, r) => acc + (r.totalNZD || 0), 0);
    const newCost = newRows.reduce((acc, r) => acc + ((r.unitCostNZD || 0) * (r.quantity || 0) * (1 + (r.wastagePercent || 0) / 100)), 0);
    const newGst = calculateGST(newSubtotal).gst;
    const newTotal = newSubtotal + newGst;

    const updated: Quote = {
      ...activeQuote,
      spreadsheetSections: newSections,
      spreadsheetRows: newRows,
      subtotalNZD: newSubtotal,
      costTotalNZD: newCost,
      gstNZD: newGst,
      totalNZD: newTotal,
      markupPercent: newCost > 0 ? Math.round(((newSubtotal - newCost) / newCost) * 100) : 18,
      marginPercent: newSubtotal > 0 ? Math.round(((newSubtotal - newCost) / newSubtotal) * 100) : 15
    };
    onUpdateQuote(updated);
  };

  // Cell Edit Handler (Real Excel inline editing)
  const handleCellChange = (rowId: string, field: keyof SpreadsheetRow, value: any) => {
    const updatedRows = rows.map(r => {
      if (r.id !== rowId) return r;

      const updatedRow = { ...r, [field]: value };

      // Recalculate if quantity, unitSellNZD, unitCostNZD, or wastage changed
      if (field === 'quantity' || field === 'unitSellNZD' || field === 'unitCostNZD' || field === 'markupPercent' || field === 'wastagePercent') {
        const qty = Number(field === 'quantity' ? value : r.quantity) || 0;
        let cost = Number(field === 'unitCostNZD' ? value : r.unitCostNZD) || 0;
        let markup = Number(field === 'markupPercent' ? value : r.markupPercent) || 0;
        let sell = Number(field === 'unitSellNZD' ? value : r.unitSellNZD) || 0;

        if (field === 'unitCostNZD' || field === 'markupPercent') {
          sell = Math.round(cost * (1 + markup / 100) * 100) / 100;
          updatedRow.unitSellNZD = sell;
        } else if (field === 'unitSellNZD' && cost > 0) {
          markup = Math.round(((sell - cost) / cost) * 1000) / 10;
          updatedRow.markupPercent = markup;
        }

        updatedRow.totalNZD = Math.round(qty * sell * 100) / 100;
        updatedRow.formula = `=${qty} * ${sell}`;
      }

      // If user typed directly into the formula
      if (field === 'formula' && typeof value === 'string' && value.startsWith('=')) {
        const calculated = evaluateFormula(value, r.totalNZD);
        updatedRow.totalNZD = calculated;
        if (r.quantity > 0) {
          updatedRow.unitSellNZD = Math.round((calculated / r.quantity) * 100) / 100;
        }
      }

      return updatedRow;
    });

    syncQuoteSpreadsheet(sections, updatedRows);
  };

  // Add a new row to a specific section
  const handleAddRowToSection = (sectionId: string) => {
    const newRow: SpreadsheetRow = {
      id: `row-${Date.now()}`,
      sectionId,
      itemCode: 'CUSTOM',
      description: 'New Architectural Scope Item (Custom Line)',
      category: 'General',
      quantity: 1,
      unit: 'sum',
      wastagePercent: 0,
      unitCostNZD: 250.00,
      markupPercent: 20,
      unitSellNZD: 300.00,
      totalNZD: 300.00,
      formula: '=1 * 300',
      notes: 'Custom line item entered directly into takeoff spreadsheet.',
      supplier: 'The Roofing Store'
    };
    syncQuoteSpreadsheet(sections, [...rows, newRow]);
  };

  // Delete a row
  const handleDeleteRow = (rowId: string) => {
    syncQuoteSpreadsheet(sections, rows.filter(r => r.id !== rowId));
  };

  // Add a brand new custom section
  const handleAddSection = () => {
    const sectionNum = sections.length + 1;
    const colors = ['border-l-sky-500', 'border-l-indigo-500', 'border-l-teal-500', 'border-l-emerald-500', 'border-l-amber-500', 'border-l-rose-500'];
    const newSection: SpreadsheetSection = {
      id: `sec-${Date.now()}`,
      title: `${sectionNum}. Custom Architectural Package (Section ${sectionNum})`,
      colorTag: colors[sectionNum % colors.length]
    };
    syncQuoteSpreadsheet([...sections, newSection], rows);
  };

  // Batch Markup Adjustment
  const handleApplyGlobalMarkup = (newMarkup: number) => {
    const updatedRows = rows.map(r => {
      const sell = Math.round(r.unitCostNZD * (1 + newMarkup / 100) * 100) / 100;
      return {
        ...r,
        markupPercent: newMarkup,
        unitSellNZD: sell,
        totalNZD: Math.round(r.quantity * sell * 100) / 100,
        formula: `=${r.quantity} * ${sell}`
      };
    });
    syncQuoteSpreadsheet(sections, updatedRows);
  };

  // Export to CSV / Excel
  const handleExportExcel = () => {
    exportToCSV(
      activeQuote.quoteNumber,
      activeQuote.clientName,
      sections,
      rows,
      subtotalNZD,
      gstNZD,
      totalNZD
    );
  };

  // Copy to Clipboard
  const handleCopyClipboard = async () => {
    const success = await copyTableForExcel(sections, rows);
    if (success) {
      setCopiedToast(true);
      setTimeout(() => setCopiedToast(false), 2500);
    }
  };

  // Paste from TSV / Excel
  const handleProcessPastedText = () => {
    if (!pastedText.trim()) return;
    const lines = pastedText.trim().split('\n');
    const newRowsToAdd: SpreadsheetRow[] = [];
    const targetSectionId = sections[0]?.id || 'sec-1';

    lines.forEach((line, idx) => {
      const parts = line.split('\t');
      if (parts.length >= 2) {
        const desc = parts[1] || parts[0] || 'Imported Line';
        const qty = Number(parts[2]) || Number(parts[1]) || 1;
        const unit = parts[3] || 'ea';
        const cost = Number(parts[4]) || 50;
        const sell = Number(parts[5]) || cost * 1.25;

        newRowsToAdd.push({
          id: `pasted-${Date.now()}-${idx}`,
          sectionId: targetSectionId,
          itemCode: parts[0] && parts[0].length < 15 ? parts[0] : 'IMP',
          description: desc,
          category: 'Pasted Items',
          quantity: qty,
          unit,
          wastagePercent: 0,
          unitCostNZD: cost,
          markupPercent: 25,
          unitSellNZD: sell,
          totalNZD: Math.round(qty * sell * 100) / 100,
          formula: `=${qty} * ${sell}`,
          notes: 'Pasted from external Excel / clipboard.'
        });
      }
    });

    if (newRowsToAdd.length > 0) {
      syncQuoteSpreadsheet(sections, [...rows, ...newRowsToAdd]);
      setIsPasteModalOpen(false);
      setPastedText('');
    }
  };

  // Client Portal interactive options
  const [selectedOptionalUpgrades, setSelectedOptionalUpgrades] = useState<{ [id: string]: boolean }>({
    'opt-1': false,
    'opt-2': true,
    'opt-3': false
  });

  const optionalUpgradesList = [
    {
      id: 'opt-1',
      title: 'Kiwicolour® Zenex+ Extreme Coastal Heavy Coating Upgrade',
      description: 'Increases marine warranty from 20 to 25 years with upgraded 200g/m² zinc-aluminium substrate.',
      additionalCostNZD: 4200.00
    },
    {
      id: 'opt-2',
      title: 'Integrated Velux Skylight Custom Flashing & Trimming Package',
      description: 'Custom folded saddle and side soaker aprons factory hemmed to Super Seam 38mm pans.',
      additionalCostNZD: 1850.00
    },
    {
      id: 'opt-3',
      title: 'Architectural Snow & Ice Retention Cleats (Central Otago Prep)',
      description: 'Extruded dual-bar powdercoated snow guards mechanically clamped to standing seams.',
      additionalCostNZD: 3100.00
    }
  ];

  const upgradesTotal = optionalUpgradesList
    .filter(u => selectedOptionalUpgrades[u.id])
    .reduce((sum, u) => sum + u.additionalCostNZD, 0);

  const clientPortalSubtotal = subtotalNZD + upgradesTotal;
  const clientPortalGst = calculateGST(clientPortalSubtotal).gst;
  const clientPortalGrandTotal = clientPortalSubtotal + clientPortalGst;

  // Handle Client Acceptance
  const handleClientAcceptQuote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientSignerName.trim() || !clientAgreedTerms) return;

    setIsSignedSuccess(true);
    const updated: Quote = {
      ...activeQuote,
      status: 'accepted',
      clientSignature: clientSignerName,
      signedAt: new Date().toISOString()
    };
    onUpdateQuote(updated);
  };

  return (
    <div className="space-y-4">
      {/* Top Banner & Mode Switcher */}
      <div className="bg-white rounded-lg border border-slate-200 p-4 shadow-2xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-slate-500">
              <span className="font-semibold text-slate-900">Archtech Estimating Engine</span>
              <span>·</span>
              <span className="text-sky-700 font-semibold flex items-center gap-1">
                <FileSpreadsheet className="w-3.5 h-3.5 text-sky-600" /> Excel-Grade Takeoff Matrix
              </span>
              <span>·</span>
              <span className="text-emerald-700 font-semibold flex items-center gap-1">
                <Cloud className="w-3.5 h-3.5 text-sky-500" /> OneDrive Sync Ready
              </span>
            </div>
            
            <div className="flex items-baseline gap-3 mt-1">
              <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                Quoting Suite & Matrix
                <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-bold border border-slate-200">
                  {activeQuote.quoteNumber} ({activeQuote.revision || 'Rev A'})
                </span>
              </h2>
              <span className="text-xs text-slate-500">
                {activeQuote.clientName} · {activeQuote.siteAddress}
              </span>
            </div>
          </div>

          {/* Mode Switcher Tabs */}
          <div className="flex items-center gap-2">
            <div className="bg-slate-100 p-1 rounded-lg border border-slate-200 flex items-center gap-1">
              <button
                type="button"
                onClick={() => setViewMode('spreadsheet')}
                className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  viewMode === 'spreadsheet'
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Table className="w-3.5 h-3.5 text-sky-600" />
                <span>Estimator Spreadsheet (Excel)</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('client_portal')}
                className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                  viewMode === 'client_portal'
                    ? 'bg-slate-900 text-white shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Eye className="w-3.5 h-3.5 text-emerald-400" />
                <span>Client & Architect Portal View</span>
              </button>
            </div>

            {/* OneDrive Sync Cloud Button */}
            <button
              type="button"
              onClick={() => setIsOneDriveModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-sky-900 bg-sky-50 hover:bg-sky-100 border border-sky-300 rounded-md transition-colors cursor-pointer"
              title="Open OneDrive Folder Sync & Cloud Settings"
            >
              <Cloud className="w-4 h-4 text-sky-600" />
              <span className="hidden sm:inline">OneDrive Folders</span>
            </button>
          </div>
        </div>

        {/* Financial KPI Summary Ribbon */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mt-4 pt-3 border-t border-slate-100 text-xs">
          <div className="p-2.5 rounded bg-slate-50 border border-slate-100">
            <span className="text-slate-400 block text-[10px] font-mono">Wholesale Cost (TRS & Labour)</span>
            <span className="font-mono font-bold text-slate-900 text-sm">{formatNZD(costTotalNZD)}</span>
          </div>
          <div className="p-2.5 rounded bg-slate-50 border border-slate-100">
            <span className="text-slate-400 block text-[10px] font-mono">Sell Subtotal (Excl. GST)</span>
            <span className="font-mono font-bold text-slate-900 text-sm">{formatNZD(subtotalNZD)}</span>
          </div>
          <div className="p-2.5 rounded bg-slate-50 border border-slate-100">
            <span className="text-slate-400 block text-[10px] font-mono">Gross Margin</span>
            <span className="font-mono font-bold text-emerald-700 text-sm">{grossMarginPercent}%</span>
            <span className="text-[10px] text-slate-500 font-mono block">Markup: {overallMarkupPercent}%</span>
          </div>
          <div className="p-2.5 rounded bg-slate-50 border border-slate-100">
            <span className="text-slate-400 block text-[10px] font-mono">GST (15% NZ)</span>
            <span className="font-mono font-bold text-slate-700 text-sm">{formatNZD(gstNZD)}</span>
          </div>
          <div className="p-2.5 rounded bg-slate-900 text-white border border-slate-800">
            <span className="text-slate-300 block text-[10px] font-mono">Total Incl. GST</span>
            <span className="font-mono font-bold text-emerald-400 text-base">{formatNZD(totalNZD)}</span>
          </div>
        </div>
      </div>

      {copiedToast && (
        <div className="p-2 bg-emerald-50 border border-emerald-300 rounded text-xs text-emerald-900 font-medium flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>Copied complete spreadsheet matrix to clipboard! You can now paste directly into Microsoft Excel or Google Sheets.</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODE 1: EXCEL-GRADE SPREADSHEET MATRIX VIEW */}
      {/* ========================================================================= */}
      {viewMode === 'spreadsheet' && (
        <div className="space-y-3">
          {/* Spreadsheet Controls & Formula Bar */}
          <div className="bg-white rounded-lg border border-slate-200 p-3 shadow-2xs space-y-2.5">
            {/* Top Toolbar */}
            <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex flex-wrap items-center gap-1.5">
                <button
                  type="button"
                  onClick={handleAddSection}
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5 text-sky-600" />
                  <span>+ New Scope Section</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsPasteModalOpen(true)}
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded transition-colors cursor-pointer"
                  title="Paste tab-separated rows from Excel directly into this quote"
                >
                  <FileUp className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Paste from Excel</span>
                </button>

                <button
                  type="button"
                  onClick={handleCopyClipboard}
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded transition-colors cursor-pointer"
                  title="Copy formatted table to paste into Excel"
                >
                  <Copy className="w-3.5 h-3.5 text-slate-500" />
                  <span>Copy for Excel</span>
                </button>

                <button
                  type="button"
                  onClick={handleExportExcel}
                  className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded transition-colors cursor-pointer shadow-2xs"
                  title="Download .CSV spreadsheet matrix for Microsoft Excel"
                >
                  <Download className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Export to Excel (.CSV)</span>
                </button>
              </div>

              {/* Column Visibility Toggles & Batch Markup */}
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 border-r border-slate-200 pr-3">
                  <span className="text-[11px] text-slate-500 font-medium">Columns:</span>
                  <label className="flex items-center gap-1 text-[11px] cursor-pointer text-slate-700">
                    <input
                      type="checkbox"
                      checked={showCostColumns}
                      onChange={(e) => setShowCostColumns(e.target.checked)}
                      className="rounded border-slate-300 text-sky-600"
                    />
                    <span>Cost & Markup</span>
                  </label>
                  <label className="flex items-center gap-1 text-[11px] cursor-pointer text-slate-700">
                    <input
                      type="checkbox"
                      checked={showWastageColumn}
                      onChange={(e) => setShowWastageColumn(e.target.checked)}
                      className="rounded border-slate-300 text-sky-600"
                    />
                    <span>Wastage %</span>
                  </label>
                  <label className="flex items-center gap-1 text-[11px] cursor-pointer text-slate-700">
                    <input
                      type="checkbox"
                      checked={showFormulaColumn}
                      onChange={(e) => setShowFormulaColumn(e.target.checked)}
                      className="rounded border-slate-300 text-sky-600"
                    />
                    <span>Formulas</span>
                  </label>
                </div>

                {/* Quick Markup Preset */}
                <div className="flex items-center gap-1 text-[11px]">
                  <span className="text-slate-500 font-mono">Batch Markup:</span>
                  {[15, 20, 25].map(pct => (
                    <button
                      key={pct}
                      type="button"
                      onClick={() => handleApplyGlobalMarkup(pct)}
                      className="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-mono cursor-pointer"
                    >
                      {pct}%
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Formula Bar (Excel fx bar) */}
            <div className="flex items-center gap-2 bg-slate-50 p-2 rounded border border-slate-200 text-xs">
              <div className="w-16 px-2 py-1 bg-white border border-slate-300 rounded font-mono font-bold text-slate-700 text-center shrink-0">
                {selectedCellInfo.cellLabel}
              </div>
              <div className="px-2 font-mono font-bold text-slate-400 italic shrink-0">fx</div>
              <input
                type="text"
                placeholder="Enter mathematical formula (e.g. =285 * 34.50) or type cell value directly..."
                value={selectedCellInfo.value}
                onChange={(e) => {
                  setSelectedCellInfo(prev => ({ ...prev, value: e.target.value }));
                  if (selectedCellInfo.rowId && selectedCellInfo.colKey) {
                    handleCellChange(selectedCellInfo.rowId, selectedCellInfo.colKey as any, e.target.value);
                  }
                }}
                className="flex-1 px-3 py-1 bg-white border border-slate-300 rounded font-mono text-slate-900 focus:outline-none focus:ring-1 focus:ring-sky-600"
              />
            </div>
          </div>

          {/* Excel Spreadsheet Table Sections */}
          <div className="space-y-4">
            {sections.map((section, sIdx) => {
              const sectionRows = rows.filter(r => r.sectionId === section.id);
              const sectionCost = sectionRows.reduce((sum, r) => sum + ((r.unitCostNZD || 0) * (r.quantity || 0) * (1 + (r.wastagePercent || 0) / 100)), 0);
              const sectionSell = sectionRows.reduce((sum, r) => sum + (r.totalNZD || 0), 0);
              const sectionMargin = sectionSell > 0 ? Math.round(((sectionSell - sectionCost) / sectionSell) * 1000) / 10 : 0;

              return (
                <div key={section.id} className={`bg-white rounded-lg border border-slate-200 shadow-2xs overflow-hidden border-l-4 ${section.colorTag}`}>
                  {/* Section Header */}
                  <div className="p-3 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-slate-400 text-xs">#{sIdx + 1}</span>
                      <input
                        type="text"
                        value={section.title}
                        onChange={(e) => {
                          const updated = sections.map(s => s.id === section.id ? { ...s, title: e.target.value } : s);
                          syncQuoteSpreadsheet(updated, rows);
                        }}
                        className="font-bold text-slate-900 text-xs bg-transparent hover:bg-white px-2 py-0.5 rounded border border-transparent hover:border-slate-300 focus:bg-white focus:border-slate-800 focus:outline-none w-72 sm:w-96"
                      />
                      <span className="text-[11px] font-mono text-slate-400">({sectionRows.length} lines)</span>
                    </div>

                    <div className="flex items-center gap-3 text-xs">
                      <div className="flex items-center gap-2 font-mono">
                        {showCostColumns && (
                          <span className="text-slate-400 text-[11px]">Cost: {formatNZD(sectionCost)}</span>
                        )}
                        <span className="font-bold text-slate-900">Subtotal: {formatNZD(sectionSell)}</span>
                        {showCostColumns && (
                          <span className="text-emerald-700 font-bold bg-emerald-50 px-1.5 py-0.5 rounded text-[10px]">
                            {sectionMargin}% Margin
                          </span>
                        )}
                      </div>

                      <button
                        type="button"
                        onClick={() => handleAddRowToSection(section.id)}
                        className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded transition-colors cursor-pointer"
                      >
                        <Plus className="w-3 h-3" />
                        <span>Add Row</span>
                      </button>
                    </div>
                  </div>

                  {/* Matrix Spreadsheet Table */}
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-slate-200 text-left text-xs font-mono">
                      <thead className="bg-slate-100/70 text-slate-600 font-bold uppercase text-[10px]">
                        <tr>
                          <th className="py-2 px-2.5 w-10 text-center">#</th>
                          <th className="py-2 px-2 w-24">Item Code</th>
                          <th className="py-2 px-3 min-w-[260px] font-sans">Scope Description / Spec</th>
                          <th className="py-2 px-2.5 w-24">Category</th>
                          <th className="py-2 px-2 w-20 text-right">Qty</th>
                          <th className="py-2 px-2 w-16">Unit</th>
                          {showWastageColumn && <th className="py-2 px-2 w-16 text-right">Waste %</th>}
                          {showCostColumns && <th className="py-2 px-2 w-24 text-right">Unit Cost</th>}
                          {showCostColumns && <th className="py-2 px-2 w-20 text-right">Markup %</th>}
                          <th className="py-2 px-2 w-24 text-right">Sell Rate</th>
                          <th className="py-2 px-3 w-28 text-right bg-slate-100 font-bold">Line Total</th>
                          {showFormulaColumn && <th className="py-2 px-3 min-w-[200px]">Formula / Calc</th>}
                          <th className="py-2 px-2 w-10 text-center"></th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 bg-white">
                        {sectionRows.map((row, rIdx) => (
                          <tr key={row.id} className="hover:bg-sky-50/50 transition-colors group">
                            {/* Row Index */}
                            <td className="py-1 px-2.5 text-center text-slate-400 text-[10px]">
                              {rIdx + 1}
                            </td>

                            {/* Item Code */}
                            <td className="py-1 px-2">
                              <input
                                type="text"
                                value={row.itemCode || ''}
                                onFocus={() => setSelectedCellInfo({ rowId: row.id, colKey: 'itemCode', cellLabel: `B${rIdx+1}`, value: row.itemCode || '' })}
                                onChange={(e) => handleCellChange(row.id, 'itemCode', e.target.value)}
                                className="w-full bg-transparent px-1.5 py-1 rounded hover:bg-slate-100 focus:bg-white focus:ring-1 focus:ring-sky-600 focus:outline-none text-slate-700 font-semibold text-[11px]"
                              />
                            </td>

                            {/* Description */}
                            <td className="py-1 px-3 font-sans">
                              <input
                                type="text"
                                value={row.description}
                                onFocus={() => setSelectedCellInfo({ rowId: row.id, colKey: 'description', cellLabel: `C${rIdx+1}`, value: row.description })}
                                onChange={(e) => handleCellChange(row.id, 'description', e.target.value)}
                                className="w-full bg-transparent px-1.5 py-1 rounded hover:bg-slate-100 focus:bg-white focus:ring-1 focus:ring-sky-600 focus:outline-none text-slate-900 font-medium text-xs"
                              />
                            </td>

                            {/* Category */}
                            <td className="py-1 px-2">
                              <input
                                type="text"
                                value={row.category || ''}
                                onFocus={() => setSelectedCellInfo({ rowId: row.id, colKey: 'category', cellLabel: `D${rIdx+1}`, value: row.category || '' })}
                                onChange={(e) => handleCellChange(row.id, 'category', e.target.value)}
                                className="w-full bg-transparent px-1.5 py-1 rounded hover:bg-slate-100 focus:bg-white focus:ring-1 focus:ring-sky-600 focus:outline-none text-slate-500 text-[11px]"
                              />
                            </td>

                            {/* Quantity */}
                            <td className="py-1 px-2">
                              <input
                                type="number"
                                step="any"
                                value={row.quantity}
                                onFocus={() => setSelectedCellInfo({ rowId: row.id, colKey: 'quantity', cellLabel: `E${rIdx+1}`, value: String(row.quantity) })}
                                onChange={(e) => handleCellChange(row.id, 'quantity', e.target.value)}
                                className="w-full bg-transparent px-1.5 py-1 rounded hover:bg-slate-100 focus:bg-white focus:ring-1 focus:ring-sky-600 focus:outline-none text-right font-bold text-slate-900 text-xs"
                              />
                            </td>

                            {/* Unit */}
                            <td className="py-1 px-2">
                              <select
                                value={row.unit}
                                onChange={(e) => handleCellChange(row.id, 'unit', e.target.value)}
                                className="w-full bg-transparent px-1 py-1 rounded hover:bg-slate-100 focus:bg-white focus:ring-1 focus:ring-sky-600 focus:outline-none text-slate-700 text-xs"
                              >
                                <option value="lm">lm</option>
                                <option value="m2">m²</option>
                                <option value="ea">ea</option>
                                <option value="hrs">hrs</option>
                                <option value="rolls">rolls</option>
                                <option value="trip">trip</option>
                                <option value="sum">sum</option>
                                <option value="pack">pack</option>
                                <option value="kg">kg</option>
                              </select>
                            </td>

                            {/* Wastage % */}
                            {showWastageColumn && (
                              <td className="py-1 px-2 text-right">
                                <input
                                  type="number"
                                  min="0"
                                  max="50"
                                  value={row.wastagePercent || 0}
                                  onFocus={() => setSelectedCellInfo({ rowId: row.id, colKey: 'wastagePercent', cellLabel: `G${rIdx+1}`, value: String(row.wastagePercent || 0) })}
                                  onChange={(e) => handleCellChange(row.id, 'wastagePercent', e.target.value)}
                                  className="w-full bg-transparent px-1 py-1 rounded hover:bg-slate-100 focus:bg-white focus:ring-1 focus:ring-sky-600 focus:outline-none text-right text-slate-500 text-xs"
                                />
                              </td>
                            )}

                            {/* Unit Cost */}
                            {showCostColumns && (
                              <td className="py-1 px-2 text-right">
                                <input
                                  type="number"
                                  step="0.01"
                                  value={row.unitCostNZD || 0}
                                  onFocus={() => setSelectedCellInfo({ rowId: row.id, colKey: 'unitCostNZD', cellLabel: `H${rIdx+1}`, value: String(row.unitCostNZD || 0) })}
                                  onChange={(e) => handleCellChange(row.id, 'unitCostNZD', e.target.value)}
                                  className="w-full bg-transparent px-1.5 py-1 rounded hover:bg-slate-100 focus:bg-white focus:ring-1 focus:ring-sky-600 focus:outline-none text-right text-slate-600 text-xs"
                                />
                              </td>
                            )}

                            {/* Markup % */}
                            {showCostColumns && (
                              <td className="py-1 px-2 text-right">
                                <input
                                  type="number"
                                  step="0.5"
                                  value={row.markupPercent || 0}
                                  onFocus={() => setSelectedCellInfo({ rowId: row.id, colKey: 'markupPercent', cellLabel: `I${rIdx+1}`, value: String(row.markupPercent || 0) })}
                                  onChange={(e) => handleCellChange(row.id, 'markupPercent', e.target.value)}
                                  className="w-full bg-transparent px-1.5 py-1 rounded hover:bg-slate-100 focus:bg-white focus:ring-1 focus:ring-sky-600 focus:outline-none text-right text-slate-700 font-semibold text-xs"
                                />
                              </td>
                            )}

                            {/* Sell Rate */}
                            <td className="py-1 px-2 text-right">
                              <input
                                type="number"
                                step="0.01"
                                value={row.unitSellNZD || 0}
                                onFocus={() => setSelectedCellInfo({ rowId: row.id, colKey: 'unitSellNZD', cellLabel: `J${rIdx+1}`, value: String(row.unitSellNZD || 0) })}
                                onChange={(e) => handleCellChange(row.id, 'unitSellNZD', e.target.value)}
                                className="w-full bg-transparent px-1.5 py-1 rounded hover:bg-slate-100 focus:bg-white focus:ring-1 focus:ring-sky-600 focus:outline-none text-right font-bold text-slate-900 text-xs"
                              />
                            </td>

                            {/* Line Total */}
                            <td className="py-1 px-3 text-right bg-slate-50 font-bold text-slate-900 text-xs">
                              {formatNZD(row.totalNZD)}
                            </td>

                            {/* Formula / Calc Notes */}
                            {showFormulaColumn && (
                              <td className="py-1 px-3">
                                <input
                                  type="text"
                                  placeholder="=Qty * Rate"
                                  value={row.formula || ''}
                                  onFocus={() => setSelectedCellInfo({ rowId: row.id, colKey: 'formula', cellLabel: `L${rIdx+1}`, value: row.formula || '' })}
                                  onChange={(e) => handleCellChange(row.id, 'formula', e.target.value)}
                                  className="w-full bg-transparent px-1.5 py-1 rounded hover:bg-slate-100 focus:bg-white focus:ring-1 focus:ring-sky-600 focus:outline-none text-slate-500 font-mono text-[11px]"
                                />
                              </td>
                            )}

                            {/* Delete Action */}
                            <td className="py-1 px-2 text-center">
                              <button
                                type="button"
                                onClick={() => handleDeleteRow(row.id)}
                                className="p-1 text-slate-300 hover:text-rose-600 rounded cursor-pointer transition-colors"
                                title="Delete line row"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          </tr>
                        ))}

                        {sectionRows.length === 0 && (
                          <tr>
                            <td colSpan={13} className="py-4 text-center text-slate-400 text-xs font-sans">
                              No line items in this section. Click "+ Add Row" above to insert.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODE 2: CLIENT & ARCHITECT INTERACTIVE PROPOSAL PORTAL */}
      {/* ========================================================================= */}
      {viewMode === 'client_portal' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xl overflow-hidden max-w-5xl mx-auto space-y-6 p-6 sm:p-8 text-xs">
          {/* Proposal Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-6">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-sky-800 bg-sky-50 px-2 py-0.5 rounded border border-sky-100">
                  {activeQuote.quoteNumber}
                </span>
                <span className="text-slate-400">·</span>
                <span className="text-emerald-700 font-semibold flex items-center gap-1 font-mono">
                  <ShieldCheck className="w-3.5 h-3.5" /> NZBC E2/AS1 Approved
                </span>
              </div>
              <h1 className="text-2xl font-bold text-slate-900 mt-1">Architectural Roofing & Cladding Proposal</h1>
              <p className="text-xs text-slate-600 mt-1">
                Prepared by <strong className="text-slate-900">Archtech (Preferred Installer for The Roofing Store)</strong>
              </p>
            </div>

            <div className="text-right font-mono text-xs space-y-0.5">
              <span className="text-slate-400 block text-[10px]">Date Issued</span>
              <span className="font-bold text-slate-900">{formatDate(activeQuote.createdAt)}</span>
              <span className="text-slate-400 block text-[10px] mt-1">Valid Until</span>
              <span className="font-semibold text-amber-700">{formatDate(activeQuote.expiresAt)}</span>
            </div>
          </div>

          {/* Client & Project Specification Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-lg border border-slate-200">
            <div>
              <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Client & Site</span>
              <h4 className="font-bold text-sm text-slate-900 mt-0.5">{activeQuote.clientName}</h4>
              <p className="text-slate-600 mt-0.5">{activeQuote.siteAddress}</p>
              <p className="text-slate-500 font-mono text-[11px] mt-0.5">{activeQuote.clientEmail} · {activeQuote.clientPhone}</p>
            </div>

            <div>
              <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">Architectural Specification</span>
              <p className="font-bold text-slate-900 mt-0.5">Architect: {activeQuote.architect}</p>
              <p className="text-slate-600 font-mono text-[11px] mt-0.5">
                Profile: <strong>{activeQuote.profile}</strong> ({activeQuote.material})
              </p>
              <div className="flex items-center gap-3 font-mono text-[11px] text-slate-500 mt-1">
                <span>Wind: {activeQuote.windZone}</span>
                <span>·</span>
                <span>Exposure: {activeQuote.exposureZone}</span>
              </div>
            </div>
          </div>

          {/* Clean Categorized Scope Breakdown for Client (Costs hidden, clean sell prices shown) */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide border-b pb-2">
              Scope of Works Breakdown
            </h3>

            <div className="space-y-3">
              {sections.map(sec => {
                const secRows = rows.filter(r => r.sectionId === sec.id);
                if (secRows.length === 0) return null;
                const secSubtotal = secRows.reduce((a, b) => a + b.totalNZD, 0);

                return (
                  <div key={sec.id} className="border border-slate-200 rounded-lg overflow-hidden">
                    <div className="p-3 bg-slate-50 flex items-center justify-between font-semibold text-slate-900">
                      <span>{sec.title}</span>
                      <span className="font-mono font-bold">{formatNZD(secSubtotal)}</span>
                    </div>
                    <div className="divide-y divide-slate-100 p-3 space-y-2">
                      {secRows.map(r => (
                        <div key={r.id} className="flex items-start justify-between text-xs pt-2 first:pt-0">
                          <div className="pr-4">
                            <span className="font-medium text-slate-900 block">{r.description}</span>
                            {r.notes && <span className="text-slate-500 text-[11px] block">{r.notes}</span>}
                          </div>
                          <div className="text-right font-mono shrink-0">
                            <span className="text-slate-500 text-[11px] block">{r.quantity} {r.unit} @ {formatNZD(r.unitSellNZD)}</span>
                            <span className="font-bold text-slate-900">{formatNZD(r.totalNZD)}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Interactive Optional Scope Upgrades for Client / Architect */}
          <div className="p-5 bg-gradient-to-br from-sky-50/70 to-indigo-50/70 rounded-xl border border-sky-200 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-bold text-sky-950 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-sky-600" />
                  Optional Architectural Scope Enhancements
                </h4>
                <p className="text-xs text-sky-800">
                  Select optional upgrades to include in this contract. Total recalculates dynamically.
                </p>
              </div>
              <span className="font-mono font-bold text-sky-900 text-xs">
                +{formatNZD(upgradesTotal)} Selected
              </span>
            </div>

            <div className="space-y-2 pt-1">
              {optionalUpgradesList.map(opt => {
                const isSelected = !!selectedOptionalUpgrades[opt.id];
                return (
                  <div
                    key={opt.id}
                    onClick={() => setSelectedOptionalUpgrades(prev => ({ ...prev, [opt.id]: !prev[opt.id] }))}
                    className={`p-3 rounded-lg border transition-all cursor-pointer flex items-start justify-between gap-3 ${
                      isSelected
                        ? 'bg-white border-sky-500 shadow-2xs'
                        : 'bg-white/60 border-slate-200 hover:bg-white'
                    }`}
                  >
                    <div className="flex items-start gap-2.5">
                      <div className={`w-4 h-4 rounded mt-0.5 flex items-center justify-center border transition-colors ${
                        isSelected ? 'bg-sky-600 border-sky-600 text-white' : 'border-slate-300'
                      }`}>
                        {isSelected && <Check className="w-3 h-3" />}
                      </div>
                      <div>
                        <span className="font-bold text-slate-900 text-xs block">{opt.title}</span>
                        <span className="text-slate-600 text-[11px] block mt-0.5">{opt.description}</span>
                      </div>
                    </div>
                    <span className="font-mono font-bold text-sky-900 shrink-0 text-xs">
                      +{formatNZD(opt.additionalCostNZD)}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Payment Schedule & Milestones */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
              Contract Payment Milestones (NZ Construction Contracts Act)
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
              <div className="p-2.5 rounded bg-slate-50 border border-slate-200">
                <span className="text-slate-400 block text-[10px]">1. Deposit & Coil Order (20%)</span>
                <span className="font-bold text-slate-900">{formatNZD(clientPortalGrandTotal * 0.20)}</span>
              </div>
              <div className="p-2.5 rounded bg-slate-50 border border-slate-200">
                <span className="text-slate-400 block text-[10px]">2. Trays Delivered to Site (30%)</span>
                <span className="font-bold text-slate-900">{formatNZD(clientPortalGrandTotal * 0.30)}</span>
              </div>
              <div className="p-2.5 rounded bg-slate-50 border border-slate-200">
                <span className="text-slate-400 block text-[10px]">3. Dry-in & Seaming (35%)</span>
                <span className="font-bold text-slate-900">{formatNZD(clientPortalGrandTotal * 0.35)}</span>
              </div>
              <div className="p-2.5 rounded bg-slate-50 border border-slate-200">
                <span className="text-slate-400 block text-[10px]">4. PS3 & CCC Sign-off (15%)</span>
                <span className="font-bold text-slate-900">{formatNZD(clientPortalGrandTotal * 0.15)}</span>
              </div>
            </div>
          </div>

          {/* Final Financial Totals */}
          <div className="bg-slate-900 text-white rounded-xl p-5 space-y-3 font-mono">
            <div className="flex items-center justify-between text-xs text-slate-300">
              <span>Base Contract Subtotal:</span>
              <span>{formatNZD(subtotalNZD)}</span>
            </div>
            {upgradesTotal > 0 && (
              <div className="flex items-center justify-between text-xs text-sky-400">
                <span>Selected Architectural Upgrades:</span>
                <span>+{formatNZD(upgradesTotal)}</span>
              </div>
            )}
            <div className="flex items-center justify-between text-xs text-slate-300 pt-2 border-t border-slate-800">
              <span>Total Excl. GST:</span>
              <span className="font-bold">{formatNZD(clientPortalSubtotal)}</span>
            </div>
            <div className="flex items-center justify-between text-xs text-slate-300">
              <span>GST (15% NZ):</span>
              <span>{formatNZD(clientPortalGst)}</span>
            </div>
            <div className="flex items-center justify-between text-lg font-bold text-emerald-400 pt-3 border-t border-slate-700">
              <span>Total Contract Value (Incl. GST):</span>
              <span>{formatNZD(clientPortalGrandTotal)}</span>
            </div>
          </div>

          {/* Interactive Electronic Acceptance & Signature Pad */}
          <div className="p-5 bg-slate-50 rounded-xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <h4 className="font-bold text-sm text-slate-900">Digital Acceptance & Electronic Sign-off</h4>
              <span className="text-[10px] font-mono text-slate-500">Legal Agreement</span>
            </div>

            {isSignedSuccess || activeQuote.status === 'accepted' ? (
              <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-lg text-emerald-900 space-y-1">
                <div className="flex items-center gap-2 font-bold text-sm">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  <span>Proposal Accepted & Signed!</span>
                </div>
                <p className="text-xs">
                  Digitally signed by <strong>{activeQuote.clientSignature || clientSignerName}</strong> on {formatDate(activeQuote.signedAt || new Date().toISOString())}.
                </p>
                <p className="text-[11px] text-emerald-700 font-mono mt-1">
                  Coil reservation submitted to The Roofing Store. Production slot secured.
                </p>
              </div>
            ) : (
              <form onSubmit={handleClientAcceptQuote} className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">Authorised Signer Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Julian Vance"
                      value={clientSignerName}
                      onChange={(e) => setClientSignerName(e.target.value)}
                      className="w-full px-3 py-1.5 border border-slate-300 rounded bg-white font-bold text-slate-900"
                    />
                  </div>
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">Date</label>
                    <input
                      type="text"
                      readOnly
                      value={new Date().toLocaleDateString('en-NZ', { dateStyle: 'full' })}
                      className="w-full px-3 py-1.5 border border-slate-200 rounded bg-slate-100 text-slate-700 font-mono"
                    />
                  </div>
                </div>

                <div className="flex items-start gap-2 pt-1">
                  <input
                    type="checkbox"
                    id="clientAgreed"
                    checked={clientAgreedTerms}
                    onChange={(e) => setClientAgreedTerms(e.target.checked)}
                    className="mt-0.5 rounded border-slate-300 text-slate-900 cursor-pointer"
                  />
                  <label htmlFor="clientAgreed" className="text-slate-700 text-xs cursor-pointer">
                    I confirm acceptance of Archtech Architectural Roofing terms of trade, substrate inspection requirements, and payment schedule for Quote {activeQuote.quoteNumber}.
                  </label>
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="submit"
                    disabled={!clientSignerName.trim() || !clientAgreedTerms}
                    className="px-5 py-2.5 font-bold text-white bg-slate-900 hover:bg-slate-800 disabled:opacity-40 rounded-lg transition-colors cursor-pointer shadow-sm text-xs flex items-center gap-2"
                  >
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>Approve & Electronically Sign Quote</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* PASTE FROM EXCEL MODAL */}
      {isPasteModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-2xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl border border-slate-200 shadow-2xl max-w-lg w-full p-5 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b pb-2">
              <div className="flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-sky-600" />
                <h4 className="font-bold text-slate-900 text-sm">Paste Rows from Excel / CSV</h4>
              </div>
              <button onClick={() => setIsPasteModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-slate-600">
              Copy rows directly from your Microsoft Excel or Google Sheets workbook and paste them below:
            </p>

            <textarea
              rows={6}
              placeholder="e.g. Code [TAB] Description [TAB] Quantity [TAB] Unit [TAB] Cost [TAB] Sell"
              value={pastedText}
              onChange={(e) => setPastedText(e.target.value)}
              className="w-full p-2.5 font-mono text-xs border border-slate-300 rounded bg-slate-50 text-slate-900 focus:bg-white focus:outline-none"
            />

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsPasteModalOpen(false)}
                className="px-3 py-1.5 text-slate-600 hover:text-slate-900 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleProcessPastedText}
                className="px-4 py-1.5 font-bold text-white bg-slate-900 hover:bg-slate-800 rounded cursor-pointer transition-colors shadow-2xs"
              >
                Insert Rows into Matrix
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ONEDRIVE SYNC & CLOUD SETTINGS MODAL */}
      <OneDriveSyncModal
        isOpen={isOneDriveModalOpen}
        onClose={() => setIsOneDriveModalOpen(false)}
        activeQuote={activeQuote}
        onSyncQuote={(updated) => onUpdateQuote(updated)}
      />
    </div>
  );
};

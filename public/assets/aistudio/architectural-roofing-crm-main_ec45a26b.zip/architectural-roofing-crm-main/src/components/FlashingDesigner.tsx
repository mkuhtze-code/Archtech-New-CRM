import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Project,
  FlashingProfile,
  FlashingSegment,
  PaintSide
} from '../types/crm';
import {
  X,
  Plus,
  Trash2,
  Undo2,
  Check,
  Layers,
  ChevronLeft
} from 'lucide-react';

interface Props {
  project: Project;
  activeMemberName: string;
  onUpdateProject: (project: Project) => void;
  onClose: () => void;
  initialProfileId?: string | null;
  onSaveToLibrary?: (profile: FlashingProfile) => 'saved' | 'duplicate' | 'storage-error';
}

type Mode = 'draw' | 'edit';
type ViewMode = 'profile' | '3d';
type EditTarget = { kind: 'length' | 'angle'; index: number } | null;
const SEGMENT_KINDS: { value: FlashingSegment['kind']; label: string; defaultMm: number }[] = [
  { value: 'leg', label: 'Leg', defaultMm: 100 },
  { value: 'open_hem', label: 'Open hem', defaultMm: 12 },
  { value: 'closed_hem', label: 'Closed hem', defaultMm: 12 },
  { value: 'crush_fold', label: 'Crush fold / safety edge', defaultMm: 6 },
  { value: 'drip', label: 'Drip edge', defaultMm: 20 },
  { value: 'return', label: 'Return', defaultMm: 15 }
];

interface Pt {
  x: number;
  y: number;
}

function uid(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

function dist(a: Pt, b: Pt) {
  return Math.hypot(b.x - a.x, b.y - a.y);
}

function angleBetween(a: Pt, b: Pt, c: Pt): number {
  // Interior angle at b, in degrees (0–180-ish bend convention)
  const v1 = { x: a.x - b.x, y: a.y - b.y };
  const v2 = { x: c.x - b.x, y: c.y - b.y };
  const dot = v1.x * v2.x + v1.y * v2.y;
  const cross = v1.x * v2.y - v1.y * v2.x;
  let ang = (Math.atan2(cross, dot) * 180) / Math.PI;
  ang = Math.abs(ang);
  if (ang > 180) ang = 360 - ang;
  // Convert turn angle to "bend" (how much from straight): straight = 180 interior → 0 bend for display
  // We store the interior corner angle users expect on folders (often 90, 135, etc.)
  return Math.round(ang);
}

function pointsToSegments(points: Pt[], pxPerMm: number): FlashingSegment[] {
  if (points.length < 2) return [];
  const segs: FlashingSegment[] = [];
  for (let i = 0; i < points.length - 1; i++) {
    const lengthMm = Math.round(dist(points[i], points[i + 1]) / pxPerMm);
    let angleDeg = 0;
    let turnDirection: -1 | 1 = 1;
    if (i < points.length - 2) {
      const a = points[i];
      const b = points[i + 1];
      const c = points[i + 2];
      angleDeg = angleBetween(a, b, c);
      // Preserve which way the profile turns. The interior angle alone loses
      // this information and caused the outline to rotate/mirror when Done was pressed.
      const headingIn = Math.atan2(-(b.y - a.y), b.x - a.x);
      const headingOut = Math.atan2(-(c.y - b.y), c.x - b.x);
      let delta = (headingOut - headingIn) * 180 / Math.PI;
      while (delta > 180) delta -= 360;
      while (delta < -180) delta += 360;
      turnDirection = delta < 0 ? -1 : 1;
    }
    segs.push({
      id: uid('seg'),
      lengthMm: Math.max(1, lengthMm),
      angleDeg,
      turnDirection,
      kind: 'leg'
    });
  }
  return segs;
}

function segmentsToPoints(
  segments: FlashingSegment[],
  origin: Pt,
  pxPerMm: number,
  startHeadingDeg = 0
): Pt[] {
  const pts: Pt[] = [{ ...origin }];
  let x = origin.x;
  let y = origin.y;
  let heading = startHeadingDeg; // 0 = right, degrees CCW
  segments.forEach((seg, i) => {
    const len = Math.max(1, seg.lengthMm) * pxPerMm;
    const rad = (heading * Math.PI) / 180;
    x = x + Math.cos(rad) * len;
    y = y - Math.sin(rad) * len;
    pts.push({ x, y });
    if (i < segments.length - 1) {
      // bend: interior angle → turn amount from straight
      const interior = seg.angleDeg || 90;
      const turn = 180 - interior;
      // Profiles saved before turnDirection existed default to the historic
      // positive direction; newly drawn profiles retain their actual direction.
      heading = heading + turn * (seg.turnDirection === -1 ? -1 : 1);
    }
  });
  return pts;
}

function pointsToGeometryMm(points: Pt[], pxPerMm: number): { x: number; y: number }[] {
  if (!points.length) return [];
  const origin = points[0];
  return points.map((point) => ({
    x: (point.x - origin.x) / pxPerMm,
    y: -(point.y - origin.y) / pxPerMm
  }));
}

function geometryMmToPoints(
  geometry: { x: number; y: number }[],
  origin: Pt,
  pxPerMm: number
): Pt[] {
  return geometry.map((point) => ({
    x: origin.x + point.x * pxPerMm,
    y: origin.y - point.y * pxPerMm
  }));
}

function developedMm(segments: FlashingSegment[]) {
  return segments.reduce((s, seg) => s + (Number(seg.lengthMm) || 0), 0);
}

export const FlashingDesigner: React.FC<Props> = ({
  project,
  onUpdateProject,
  onClose,
  initialProfileId = null,
  onSaveToLibrary
}) => {
  const anyProj = project as Project & { flashingProfiles?: FlashingProfile[] };
  const profiles = anyProj.flashingProfiles || [];
  
  const [selectedId, setSelectedId] = useState<string | null>(initialProfileId);
  const selected = profiles.find((p) => p.id === selectedId) || null;

  const [mode, setMode] = useState<Mode>(initialProfileId ? 'edit' : 'draw');
  const [viewMode, setViewMode] = useState<ViewMode>('profile');
  const [editTarget, setEditTarget] = useState<EditTarget>(null);
  const [editValue, setEditValue] = useState('');
  const [points, setPoints] = useState<Pt[]>([]);
  const [cursor, setCursor] = useState<Pt | null>(null);
  const [pxPerMm] = useState(0.4); // canvas units per millimetre
  const [selectedSegIndex, setSelectedSegIndex] = useState<number | null>(null);
  const [paintSide, setPaintSide] = useState<PaintSide>(
    selected?.paintSide === 'inside' ? 'inside' : 'outside'
  );
  const [rotation, setRotation] = useState({ yaw: -0.55, pitch: 0.45 });
  const [zoom3d, setZoom3d] = useState(1);
  const [profileName, setProfileName] = useState(selected?.name || '');
    const [showSheet, setShowSheet] = useState(false); // list of profiles
    const [notice, setNotice] = useState<string | null>(null);

  const svgRef = useRef<SVGSVGElement>(null);
  const rotateStart = useRef<{ pointerId: number; x: number; y: number } | null>(null);
  const rotatePointers = useRef(new Map<number, { x: number; y: number }>());
  const pinchStart = useRef<{ distance: number; zoom: number } | null>(null);
  const lastDrawTap = useRef<{ at: number; x: number; y: number } | null>(null);
  const pendingDrawTap = useRef<{ pointerId: number; point: Pt } | null>(null);
  const suppressPointerUp = useRef(false);
  const activePointers = useRef(new Map<number, { x: number; y: number }>());
  const gestureStart = useRef<{
    distance: number;
    midpoint: Pt;
    viewBox: { x: number; y: number; w: number; h: number };
  } | null>(null);
  const draggedVertex = useRef<number | null>(null);

  const [snapAngles, setSnapAngles] = useState(true);
  const [snapToGrid, setSnapToGrid] = useState(true);
  const [viewBox, setViewBox] = useState({ x: 0, y: 0, w: 360, h: 520 });
  // A 1/2/5 × 10ⁿ millimetre grid interval stays readable as the user zooms.
  const gridStep = useMemo(() => {
    const canvasWidth = Math.max(1, svgRef.current?.clientWidth || Math.min(window.innerWidth, 480));
    const targetMm = (viewBox.w / pxPerMm / canvasWidth) * 26;
    const magnitude = Math.pow(10, Math.floor(Math.log10(Math.max(1, targetMm))));
    const normalized = targetMm / magnitude;
    const niceMm = (normalized < 1.5 ? 1 : normalized < 3.5 ? 2 : normalized < 7.5 ? 5 : 10) * magnitude;
    return Math.max(pxPerMm, niceMm * pxPerMm);
  }, [viewBox.w, pxPerMm]);
  const snapPointToGrid = (point: Pt): Pt => snapToGrid
    ? { x: Math.round(point.x / gridStep) * gridStep, y: Math.round(point.y / gridStep) * gridStep }
    : point;

  const toast = (msg: string) => {
    setNotice(msg);
    setTimeout(() => setNotice(null), 2500);
  };

  const persistProfiles = (next: FlashingProfile[]) => {
    onUpdateProject({ ...project, flashingProfiles: next } as Project);
  };
  
  // Load selected profile into canvas points
  useEffect(() => {
    if (!selected) {
      setPoints([]);
      setProfileName('');
      setPaintSide('outside');
      return;
    }
    setProfileName(selected.name);
    setPaintSide(selected.paintSide === 'inside' ? 'inside' : 'outside');
    setEditTarget(null);
    setEditValue('');
    const origin = { x: 40, y: viewBox.h * 0.55 };
    // Preserve the exact drawn polyline on save/reopen. Reconstructing only from
    // rounded millimetre lengths and integer bend angles can subtly change its shape.
    const pts = selected.geometryPointsMm?.length === selected.segments.length + 1
      ? geometryMmToPoints(selected.geometryPointsMm, origin, pxPerMm)
      : segmentsToPoints(selected.segments, origin, pxPerMm, selected.startHeadingDeg ?? 0);
    setPoints(pts);
    setSelectedSegIndex(null);
  }, [selectedId]); // eslint-disable-line — intentional: load when selection changes

  const clientToSvg = useCallback(
    (clientX: number, clientY: number): Pt | null => {
      const svg = svgRef.current;
      if (!svg) return null;
      const pt = svg.createSVGPoint();
      pt.x = clientX;
      pt.y = clientY;
      const ctm = svg.getScreenCTM();
      if (!ctm) return null;
      const sp = pt.matrixTransform(ctm.inverse());
      return { x: sp.x, y: sp.y };
    },
    []
  );

  const commitPointsAsProfile = (pts: Pt[]) => {
    if (pts.length < 2) return;
    const segs = pointsToSegments(pts, pxPerMm).map((segment, index) => ({
      ...segment,
      // Reshaping an existing profile should not reset custom hems/folds to plain legs.
      id: selected?.segments[index]?.id || segment.id,
      kind: selected?.segments[index]?.kind || segment.kind
    }));
    if (selected) {
      const next = profiles.map((p) =>
        p.id === selected.id
          ? {
              ...p,
              name: profileName || p.name,
              segments: segs,
              geometryPointsMm: pointsToGeometryMm(pts, pxPerMm),
              startHeadingDeg: pts.length >= 2 ? Math.atan2(-(pts[1].y - pts[0].y), pts[1].x - pts[0].x) * 180 / Math.PI : (p.startHeadingDeg ?? 0),
              paintSide,
              developedLengthMm: developedMm(segs),
              updatedAt: new Date().toISOString()
            }
          : p
      );
      persistProfiles(next);
      toast('Profile updated');
    } else {
      const profile: FlashingProfile = {
        id: uid('fp'),
        name: profileName || `Profile ${profiles.length + 1}`,
        segments: segs,
        geometryPointsMm: pointsToGeometryMm(pts, pxPerMm),
        startHeadingDeg: pts.length >= 2 ? Math.atan2(-(pts[1].y - pts[0].y), pts[1].x - pts[0].x) * 180 / Math.PI : 0,
        material: project.material,
        colorName: project.colorName,
        thicknessMm: 0.55,
        paintSide,
        developedLengthMm: developedMm(segs),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      persistProfiles([profile, ...profiles]);
      setSelectedId(profile.id);
      toast('Profile saved');
    }
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    e.preventDefault();
    const svg = svgRef.current;
    if (svg) {
      try { svg.setPointerCapture(e.pointerId); } catch { /* pointer may already be captured */ }
    }
    activePointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (activePointers.current.size >= 2) {
      pendingDrawTap.current = null;
      lastDrawTap.current = null;
      suppressPointerUp.current = true;
      const pair = Array.from(activePointers.current.values()).slice(0, 2);
      gestureStart.current = {
        distance: Math.max(1, dist(pair[0], pair[1])),
        midpoint: { x: (pair[0].x + pair[1].x) / 2, y: (pair[0].y + pair[1].y) / 2 },
        viewBox: { ...viewBox }
      };
      draggedVertex.current = null;
      return;
    }
    const p = clientToSvg(e.clientX, e.clientY);
    if (!p) return;

    if (mode === 'draw') {
      // Every deliberate tap adds exactly one vertex. Finish is an explicit
      // toolbar action so a second tap can never accidentally switch gestures.
      pendingDrawTap.current = { pointerId: e.pointerId, point: snapPointToGrid(p) };
      return;
    }

    if (mode === 'edit' && selected) {
      const dimensionTarget = (e.target as Element).closest?.('[data-edit-type][data-edit-index]') as Element | null;
      if (dimensionTarget) {
        const kind = dimensionTarget.getAttribute('data-edit-type');
        const index = Number(dimensionTarget.getAttribute('data-edit-index'));
        if ((kind === 'length' || kind === 'angle') && Number.isInteger(index)) {
          selectDimension(kind, index);
          return;
        }
      }
      // Hit-test vertices invisibly; no fold-point handles are drawn.
      const hitR = 18;
      for (let i = 0; i < points.length; i++) {
        if (dist(points[i], p) < hitR) {
          draggedVertex.current = i;
          setSelectedSegIndex(Math.min(i, Math.max(0, points.length - 2)));
          return;
        }
      }
      // click near segment
      for (let i = 0; i < points.length - 1; i++) {
        const a = points[i];
        const b = points[i + 1];
        const mid = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
        if (dist(mid, p) < hitR + 4) {
          setSelectedSegIndex(i);
          return;
        }
      }
    }

  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (activePointers.current.has(e.pointerId)) {
      activePointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    }
    const svg = svgRef.current;
    const gesture = gestureStart.current;
    if (svg && gesture && activePointers.current.size >= 2) {
      const pair = Array.from(activePointers.current.values()).slice(0, 2);
      const currentDistance = Math.max(1, dist(pair[0], pair[1]));
      const midpoint = { x: (pair[0].x + pair[1].x) / 2, y: (pair[0].y + pair[1].y) / 2 };
      const rect = svg.getBoundingClientRect();
      const scale = gesture.distance / currentDistance;
      const w = Math.max(120, Math.min(2400, gesture.viewBox.w * scale));
      const h = Math.max(180, Math.min(3000, gesture.viewBox.h * scale));
      const nx = Math.min(1, Math.max(0, (gesture.midpoint.x - rect.left) / Math.max(1, rect.width)));
      const ny = Math.min(1, Math.max(0, (gesture.midpoint.y - rect.top) / Math.max(1, rect.height)));
      const anchorX = gesture.viewBox.x + nx * gesture.viewBox.w;
      const anchorY = gesture.viewBox.y + ny * gesture.viewBox.h;
      const dx = (midpoint.x - gesture.midpoint.x) * gesture.viewBox.w / Math.max(1, rect.width);
      const dy = (midpoint.y - gesture.midpoint.y) * gesture.viewBox.h / Math.max(1, rect.height);
      setViewBox({
        x: anchorX - nx * w - dx,
        y: anchorY - ny * h - dy,
        w,
        h
      });
      return;
    }

    const p = clientToSvg(e.clientX, e.clientY);
    if (!p) return;
    if (mode === 'edit' && draggedVertex.current !== null) {
      const vertexIndex = draggedVertex.current;
      const nextPoint = snapPointToGrid(p);
      setPoints((previous) => previous.map((point, index) => index === vertexIndex ? nextPoint : point));
      return;
    }
    setCursor(p);
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    const wasGesture = !!gestureStart.current || suppressPointerUp.current;
    activePointers.current.delete(e.pointerId);
    if (activePointers.current.size < 2) gestureStart.current = null;
    if (draggedVertex.current !== null) {
      draggedVertex.current = null;
      if (points.length >= 2) commitPointsAsProfile(points);
    }
    const pending = pendingDrawTap.current;
    if (pending && pending.pointerId === e.pointerId) {
      pendingDrawTap.current = null;
      if (!wasGesture && activePointers.current.size === 0 && mode === 'draw') {
        let nextPoint = pending.point;
        if (snapAngles && points.length) {
          const previous = points[points.length - 1];
          const angle = Math.atan2(-(nextPoint.y - previous.y), nextPoint.x - previous.x) * 180 / Math.PI;
          const nearest = Math.round(angle / 45) * 45;
          const delta = Math.abs((((angle - nearest) % 360) + 540) % 360 - 180);
          if (delta <= 7) {
            const length = dist(previous, nextPoint);
            const rad = nearest * Math.PI / 180;
            nextPoint = { x: previous.x + Math.cos(rad) * length, y: previous.y - Math.sin(rad) * length };
          }
        }
        setPoints((prev) => [...prev, nextPoint]);
        setSelectedSegIndex(null);
        lastDrawTap.current = { at: Date.now(), x: pending.point.x, y: pending.point.y };
      }
    }
    if (activePointers.current.size === 0) suppressPointerUp.current = false;
  };

  const undoPoint = () => {
    pendingDrawTap.current = null;
    lastDrawTap.current = null;
    setPoints((prev) => prev.slice(0, -1));
  };

  const deleteLastEdge = () => {
    if (mode === 'draw') {
      undoPoint();
      return;
    }
    if (!selected) return;
    const nextSegments = selected.segments.slice(0, -1);
    if (nextSegments.length === 0) {
      persistProfiles(profiles.filter((profile) => profile.id !== selected.id));
      setSelectedId(null);
      setPoints([]);
      setMode('draw');
      toast('Last edge removed; profile is empty');
      return;
    }
    const origin = points[0] || { x: 40, y: viewBox.h * 0.55 };
    const nextPoints = selected.geometryPointsMm?.length === selected.segments.length + 1
      ? geometryMmToPoints(selected.geometryPointsMm.slice(0, -1), origin, pxPerMm)
      : segmentsToPoints(nextSegments, origin, pxPerMm, selected.startHeadingDeg ?? 0);
    setPoints(nextPoints);
    const updated = {
      ...selected,
      segments: nextSegments,
      geometryPointsMm: pointsToGeometryMm(nextPoints, pxPerMm),
      developedLengthMm: developedMm(nextSegments),
      updatedAt: new Date().toISOString()
    };
    persistProfiles(profiles.map((profile) => profile.id === selected.id ? updated : profile));
    setSelectedSegIndex(Math.max(0, nextSegments.length - 1));
    toast('Last edge deleted');
  };

  const flipProfile = () => {
    if (!selected || points.length < 2) {
      toast('Draw or select a profile first');
      return;
    }
    // Mirror the profile across its own vertical centreline; do not reorder its edges.
    const xs = points.map((point) => point.x);
    const centreX = (Math.min(...xs) + Math.max(...xs)) / 2;
    const flippedPoints = points.map((point) => ({ x: 2 * centreX - point.x, y: point.y }));
    setPoints(flippedPoints);
    commitPointsAsProfile(flippedPoints);
    setSelectedSegIndex(null);
    toast('Profile flipped left-to-right');
  };

  const clearDrawing = () => {
    pendingDrawTap.current = null;
    lastDrawTap.current = null;
    setPoints([]);
    setSelectedSegIndex(null);
  };

  const finishDrawing = () => {
    if (points.length < 2) {
      toast('Tap at least two points');
      return;
    }
    commitPointsAsProfile(points);
    setMode('edit');
  };

  const newProfile = () => {
    setSelectedId(null);
    setPoints([]);
    setEditTarget(null);
    setEditValue('');
    setProfileName(`Profile ${profiles.length + 1}`);
    setPaintSide('outside');
    setMode('draw');
    setSelectedSegIndex(null);
    setShowSheet(false);
  };

  const updateSegmentAt = (index: number, patch: Partial<FlashingSegment>) => {
    if (!selected || index < 0 || index >= selected.segments.length) return;
    const safePatch = { ...patch };
    if (typeof safePatch.lengthMm === 'number') safePatch.lengthMm = Math.max(1, Math.min(10000, safePatch.lengthMm));
    if (typeof safePatch.angleDeg === 'number') safePatch.angleDeg = Math.max(1, Math.min(179, safePatch.angleDeg));
    const segs = selected.segments.map((s, i) =>
      i === index ? { ...s, ...safePatch } : s
    );
    // rebuild points from segments
    const origin = points[0] || { x: 40, y: viewBox.h * 0.55 };
    const startHeadingDeg = points.length >= 2 ? Math.atan2(-(points[1].y - points[0].y), points[1].x - points[0].x) * 180 / Math.PI : (selected.startHeadingDeg ?? 0);
    const geometryChanged = selected.segments.some((segment, segmentIndex) =>
      segment.lengthMm !== segs[segmentIndex]?.lengthMm ||
      segment.angleDeg !== segs[segmentIndex]?.angleDeg ||
      segment.turnDirection !== segs[segmentIndex]?.turnDirection
    );
    const newPts = geometryChanged
      ? segmentsToPoints(segs, origin, pxPerMm, startHeadingDeg)
      : points;
    setPoints(newPts);
    const next = profiles.map((p) =>
      p.id === selected.id
        ? {
            ...p,
            segments: segs,
            geometryPointsMm: pointsToGeometryMm(newPts, pxPerMm),
            startHeadingDeg,
            developedLengthMm: developedMm(segs),
            paintSide,
            updatedAt: new Date().toISOString()
          }
        : p
    );
    persistProfiles(next);
  };

  const selectDimension = (kind: 'length' | 'angle', index: number) => {
    const segment = selected?.segments[index];
    if (!segment || (kind === 'angle' && index >= selected.segments.length - 1)) return;
    setSelectedSegIndex(index);
    setEditTarget({ kind, index });
    setEditValue(String(kind === 'length' ? segment.lengthMm : segment.angleDeg));
  };

  const commitDimensionEdit = () => {
    if (!editTarget || !selected) return;
    const value = Number(editValue);
    if (!Number.isFinite(value) || editValue.trim() === '') {
      const segment = selected.segments[editTarget.index];
      setEditValue(String(editTarget.kind === 'length' ? segment.lengthMm : segment.angleDeg));
      return;
    }
    updateSegmentAt(editTarget.index, editTarget.kind === 'length'
      ? { lengthMm: Math.max(1, Math.min(10000, Math.round(value))) }
      : { angleDeg: Math.max(1, Math.min(179, Math.round(value))) });
  };

  const saveCurrentToLibrary = () => {
    if (!selected || !onSaveToLibrary) {
      toast('Finish drawing before saving to the library');
      return;
    }
    const libraryCopy: FlashingProfile = {
      ...selected,
      id: uid('lib-flashing'),
      name: profileName.trim() || selected.name,
      segments: selected.segments.map((segment) => ({ ...segment, id: uid('seg') })),
      isTemplate: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    const result = onSaveToLibrary(libraryCopy);
    if (result === 'saved') toast('Saved as a new library profile');
    else if (result === 'duplicate') toast('A profile with that name already exists — rename it first');
    else toast('Could not save to browser storage. Check storage permissions and available space.');
  };

  const applyPaintSide = (side: PaintSide) => {
    setPaintSide(side);
    if (selected) {
      persistProfiles(
        profiles.map((p) =>
          p.id === selected.id
            ? { ...p, paintSide: side, updatedAt: new Date().toISOString() }
            : p
        )
      );
    }
  };

  const handle3dPointerDown = (event: React.PointerEvent<SVGSVGElement>) => {
    event.preventDefault();
    event.currentTarget.setPointerCapture(event.pointerId);
    rotatePointers.current.set(event.pointerId, { x: event.clientX, y: event.clientY });
    if (rotatePointers.current.size >= 2) {
      const pair = Array.from(rotatePointers.current.values()).slice(0, 2);
      pinchStart.current = { distance: Math.max(1, dist(pair[0], pair[1])), zoom: zoom3d };
      rotateStart.current = null;
    } else {
      rotateStart.current = { pointerId: event.pointerId, x: event.clientX, y: event.clientY };
    }
  };
  const handle3dPointerMove = (event: React.PointerEvent<SVGSVGElement>) => {
    if (!rotatePointers.current.has(event.pointerId)) return;
    rotatePointers.current.set(event.pointerId, { x: event.clientX, y: event.clientY });
    if (rotatePointers.current.size >= 2 && pinchStart.current) {
      const pair = Array.from(rotatePointers.current.values()).slice(0, 2);
      const distance = Math.max(1, dist(pair[0], pair[1]));
      setZoom3d(Math.max(0.4, Math.min(3.5, pinchStart.current.zoom * distance / pinchStart.current.distance)));
      return;
    }
    const start = rotateStart.current;
    if (!start || start.pointerId !== event.pointerId) return;
    const dx = event.clientX - start.x, dy = event.clientY - start.y;
    rotateStart.current = { ...start, x: event.clientX, y: event.clientY };
    // Match the intuitive trackball direction: dragging right turns the model toward the right.
    setRotation((previous) => ({ yaw: previous.yaw - dx * 0.012, pitch: Math.max(-1.35, Math.min(1.35, previous.pitch + dy * 0.01)) }));
  };
  const handle3dPointerUp = (event: React.PointerEvent<SVGSVGElement>) => {
    rotatePointers.current.delete(event.pointerId);
    if (rotatePointers.current.size < 2) pinchStart.current = null;
    if (rotateStart.current?.pointerId === event.pointerId) rotateStart.current = null;
    if (rotatePointers.current.size === 1) {
      const [pointerId, point] = Array.from(rotatePointers.current.entries())[0];
      rotateStart.current = { pointerId, x: point.x, y: point.y };
    }
  };

  const livePath = useMemo(() => {
    const pts = [...points];
    if (mode === 'draw' && cursor && pts.length > 0) pts.push(cursor);
    if (pts.length < 2) return '';
    return pts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');
  }, [points, cursor, mode]);

    const developed = selected
    ? selected.developedLengthMm || developedMm(selected.segments)
    : points.length >= 2
      ? developedMm(pointsToSegments(points, pxPerMm))
      : 0;

  const paintFaceColor = '#ef4444';
  const oppositeFaceColor = '#9ca3af';
  // SVG viewBox units per CSS pixel; labels use this to remain a fixed screen size.
  const labelScale = viewBox.w / Math.max(1, svgRef.current?.clientWidth || 360);
  const polygonPoints = (items: Pt[]) => items.map((point) => String(point.x) + ',' + String(point.y)).join(' ');
  const modelFaces = useMemo(() => {
    if (points.length < 2) return [];
    const xs = points.map((p) => p.x), ys = points.map((p) => p.y);
    const cx = (Math.min(...xs) + Math.max(...xs)) / 2, cy = (Math.min(...ys) + Math.max(...ys)) / 2;
    const width = Math.max(90, Math.min(220, (Math.max(...xs) - Math.min(...xs)) * 0.45));
    const cosY = Math.cos(rotation.yaw), sinY = Math.sin(rotation.yaw), cosP = Math.cos(rotation.pitch), sinP = Math.sin(rotation.pitch);
    const normals = points.map((p, i) => {
      const previous = points[Math.max(0, i - 1)], next = points[Math.min(points.length - 1, i + 1)];
      const dx = next.x - previous.x, dy = next.y - previous.y, length = Math.max(0.001, Math.hypot(dx, dy));
      return { x: -dy / length * 2.2, y: dx / length * 2.2 };
    });
    const vertices = points.flatMap((p, i) => [
      { x: p.x - cx, y: -(p.y - cy), z: -width / 2 },
      { x: p.x - cx, y: -(p.y - cy), z: width / 2 },
      { x: p.x + normals[i].x - cx, y: -(p.y + normals[i].y - cy), z: -width / 2 },
      { x: p.x + normals[i].x - cx, y: -(p.y + normals[i].y - cy), z: width / 2 }
    ]);
    const transformed = vertices.map((v) => { const x1 = v.x * cosY - v.z * sinY, z1 = v.x * sinY + v.z * cosY; return { x: x1, y: v.y * cosP - z1 * sinP, z: v.y * sinP + z1 * cosP }; });
    const minX = Math.min(...transformed.map((v) => v.x)), maxX = Math.max(...transformed.map((v) => v.x));
    const minY = Math.min(...transformed.map((v) => v.y)), maxY = Math.max(...transformed.map((v) => v.y));
    const scale = Math.min(viewBox.w / Math.max(1, maxX - minX), viewBox.h / Math.max(1, maxY - minY)) * 0.7 * zoom3d;
    const project = (index: number) => { const v = transformed[index]; return { x: viewBox.x + viewBox.w / 2 + v.x * scale, y: viewBox.y + viewBox.h / 2 - v.y * scale, z: v.z }; };
    const faces: { key: string; points: Pt[]; depth: number; fill: string; stroke: string }[] = [];
    for (let i = 0; i < points.length - 1; i++) {
      const baseA = project(i * 4), baseB = project((i + 1) * 4);
      const baseFrontA = project(i * 4 + 1), baseFrontB = project((i + 1) * 4 + 1);
      const reverseA = project(i * 4 + 2), reverseB = project((i + 1) * 4 + 2);
      const reverseFrontA = project(i * 4 + 3), reverseFrontB = project((i + 1) * 4 + 3);
      // The two broad faces are opposite sides of the folded sheet. Keep the
      // selected face colour aligned with the user's Inside/Outside choice.
      const painted = paintSide === 'outside' ? oppositeFaceColor : paintFaceColor;
      const unpainted = paintSide === 'outside' ? paintFaceColor : oppositeFaceColor;
      faces.push({ key: 'paint-' + i, points: [baseFrontA, baseFrontB, baseB, baseA], depth: (baseFrontA.z + baseFrontB.z + baseB.z + baseA.z) / 4, fill: painted, stroke: '#f3f4f6' });
      faces.push({ key: 'reverse-' + i, points: [reverseFrontA, reverseFrontB, reverseB, reverseA], depth: (reverseFrontA.z + reverseFrontB.z + reverseB.z + reverseA.z) / 4, fill: unpainted, stroke: '#6b7280' });
      faces.push({ key: 'edge-' + i, points: [baseFrontB, reverseFrontB, reverseB, baseB], depth: (baseFrontB.z + reverseFrontB.z + reverseB.z + baseB.z) / 4, fill: '#737b86', stroke: '#d1d5db' });
    }
    return faces.sort((a, b) => a.depth - b.depth);
  }, [points, rotation, viewBox.x, viewBox.y, viewBox.w, viewBox.h, zoom3d, paintSide]);

  // Responsive full-viewport drawing area
  useEffect(() => {
    const update = () => {
      const w = Math.max(320, window.innerWidth);
      const h = Math.max(360, window.innerHeight - 185);
      setViewBox((previous) => ({ ...previous, w, h }));
    };
    update();
    window.addEventListener('resize', update);
    return () => window.removeEventListener('resize', update);
  }, []);

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 text-white flex flex-col safe-area">
      {/* Top bar */}
      <header className="flex items-center gap-2 px-3 pt-[max(0.75rem,env(safe-area-inset-top))] pb-2 border-b border-slate-800 bg-slate-950/95">
        <button
          onClick={onClose}
          className="p-2 -ml-1 rounded-lg hover:bg-slate-800 cursor-pointer"
          aria-label="Close"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="min-w-0 flex-1">
          <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
            Flashings · {project.projectNumber}
          </div>
          <input
            value={profileName}
            onChange={(e) => setProfileName(e.target.value)}
            onBlur={() => {
              if (selected && profileName.trim()) {
                persistProfiles(
                  profiles.map((p) =>
                    p.id === selected.id
                      ? { ...p, name: profileName.trim() }
                      : p
                  )
                );
              }
            }}
            placeholder="Profile name"
            className="w-full bg-transparent text-sm font-bold text-white outline-none truncate"
          />
        </div>
        <button
          onClick={() => setShowSheet(true)}
          className="px-2.5 py-1.5 rounded-lg bg-slate-800 text-xs font-semibold cursor-pointer"
        >
          {profiles.length} saved
        </button>
      </header>

      {notice && (
        <div className="absolute top-16 left-1/2 -translate-x-1/2 z-50 bg-emerald-600 text-white text-xs font-semibold px-3 py-1.5 rounded-full shadow-lg">
          {notice}
        </div>
      )}

      {/* Compact mode and view switcher */}
      <div className="flex items-center gap-2 px-3 py-1.5 border-b border-slate-800 bg-slate-950">
        {viewMode === 'profile' && <div className="flex gap-1 rounded-lg bg-slate-900 p-1">
          <button onClick={() => setMode('draw')} className={`rounded-md px-3 py-1.5 text-xs font-bold ${mode === 'draw' ? 'bg-white text-slate-950' : 'text-slate-400'}`}>Draw</button>
          <button onClick={() => setMode('edit')} className={`rounded-md px-3 py-1.5 text-xs font-bold ${mode === 'edit' ? 'bg-white text-slate-950' : 'text-slate-400'}`}>Edit</button>
        </div>}
        <div className="ml-auto flex gap-1 rounded-lg bg-slate-900 p-1">
          <button onClick={() => setViewMode('profile')} aria-pressed={viewMode === 'profile'} className={`rounded-md px-3 py-1.5 text-xs font-bold ${viewMode === 'profile' ? 'bg-sky-500 text-slate-950' : 'text-slate-400'}`}>2D grid</button>
          <button onClick={() => {
            setViewMode('3d');
            if (points.length >= 2) {
              const xs = points.map((point) => point.x), ys = points.map((point) => point.y);
              const pad = 90;
              const minX = Math.min(...xs), maxX = Math.max(...xs), minY = Math.min(...ys), maxY = Math.max(...ys);
              setViewBox({ x: minX - pad, y: minY - pad - 90, w: maxX - minX + pad * 2, h: maxY - minY + pad * 2 });
            }
          }} aria-pressed={viewMode === '3d'} className={`rounded-md px-3 py-1.5 text-xs font-bold ${viewMode === '3d' ? 'bg-sky-500 text-slate-950' : 'text-slate-400'}`}>3D view</button>
        </div>
      </div>

      {viewMode === 'profile' ? (
        <div className="flex items-center justify-between px-3 py-1.5 bg-slate-950 text-[11px] text-slate-400 border-b border-slate-800">
          <div className="flex items-center gap-3 min-w-0"><label className="inline-flex items-center gap-2 min-h-9 whitespace-nowrap"><input type="checkbox" checked={snapToGrid} onChange={(e) => setSnapToGrid(e.target.checked)} className="accent-sky-500 w-4 h-4" /> Snap to grid</label><label className="inline-flex items-center gap-2 min-h-9 whitespace-nowrap text-slate-500"><input type="checkbox" checked={snapAngles} onChange={(e) => setSnapAngles(e.target.checked)} className="accent-sky-500 w-4 h-4" /> Snap 45°</label></div>
          <div className="flex items-center gap-2"><span className="text-[10px] text-slate-500 font-mono whitespace-nowrap">Grid {Math.round(gridStep / pxPerMm)} mm</span><button onClick={() => { if (points.length >= 2) { const xs = points.map((point) => point.x), ys = points.map((point) => point.y); const minX = Math.min(...xs), maxX = Math.max(...xs), minY = Math.min(...ys), maxY = Math.max(...ys); const pad = 70; setViewBox({ x: minX - pad, y: minY - pad, w: Math.max(180, maxX - minX + pad * 2), h: Math.max(220, maxY - minY + pad * 2) }); } else { setViewBox({ x: 0, y: 0, w: Math.max(320, window.innerWidth), h: Math.max(360, window.innerHeight - 185) }); } }} className="px-3 py-2 rounded-lg bg-slate-800 text-slate-200">Fit drawing</button></div>
        </div>
      ) : (
        <div className="flex items-center gap-2 px-3 py-2 border-b border-slate-800 bg-slate-950"><span className="text-[11px] text-slate-400 mr-1">Painted face</span><button onClick={() => applyPaintSide('outside')} aria-pressed={paintSide === 'outside'} className={paintSide === 'outside' ? 'rounded-lg px-3 py-2 text-xs font-bold bg-red-500 text-white' : 'rounded-lg px-3 py-2 text-xs font-bold bg-slate-800 text-slate-300'}>Outside</button><button onClick={() => applyPaintSide('inside')} aria-pressed={paintSide === 'inside'} className={paintSide === 'inside' ? 'rounded-lg px-3 py-2 text-xs font-bold bg-red-500 text-white' : 'rounded-lg px-3 py-2 text-xs font-bold bg-slate-800 text-slate-300'}>Inside</button><div className="ml-auto flex items-center gap-1"><button onClick={() => setZoom3d((z) => Math.max(0.4, z / 1.2))} className="px-3 py-2 rounded-lg bg-slate-800 text-sm" aria-label="Zoom out">−</button><button onClick={() => setZoom3d((z) => Math.min(3.5, z * 1.2))} className="px-3 py-2 rounded-lg bg-slate-800 text-sm" aria-label="Zoom in">+</button><button onClick={() => { setRotation({ yaw: -0.55, pitch: 0.45 }); setZoom3d(1); }} className="px-3 py-2 rounded-lg bg-slate-800 text-xs">Reset view</button></div></div>
      )}

      {/* Canvas */}
      <div className="flex-1 min-h-0 relative touch-none overflow-hidden bg-slate-900">
        <svg
          ref={svgRef}
          viewBox={`${viewBox.x} ${viewBox.y} ${viewBox.w} ${viewBox.h}`}
          className="w-full h-full touch-none"
          onPointerDown={viewMode === '3d' ? handle3dPointerDown : handlePointerDown}
          onPointerMove={viewMode === '3d' ? handle3dPointerMove : handlePointerMove}
          onPointerUp={viewMode === '3d' ? handle3dPointerUp : handlePointerUp}
          onPointerCancel={viewMode === '3d' ? handle3dPointerUp : handlePointerUp}
          onWheel={(e) => {
            if (viewMode === '3d') { e.preventDefault(); setZoom3d((z) => Math.max(0.4, Math.min(3.5, z * (e.deltaY < 0 ? 1.12 : 0.89)))); return; }
            e.preventDefault();
            const p = clientToSvg(e.clientX, e.clientY);
            if (!p) return;
            const factor = e.deltaY < 0 ? 0.88 : 1.14;
            setViewBox((v) => {
              const w = Math.max(120, Math.min(2400, v.w * factor));
              const h = Math.max(180, Math.min(3000, v.h * factor));
              const rx = (p.x - v.x) / v.w, ry = (p.y - v.y) / v.h;
              return { x: p.x - rx * w, y: p.y - ry * h, w, h };
            });
          }}
          onPointerLeave={() => setCursor(null)}
        >
          {/* Grid belongs only to the 2D drawing surface. */}
          {viewMode === 'profile' && <defs>
            <pattern id="grid-minor" width={gridStep} height={gridStep} patternUnits="userSpaceOnUse">
              <path d={`M ${gridStep} 0 L 0 0 0 ${gridStep}`} fill="none" stroke="#334155" strokeWidth={Math.max(0.25, gridStep * 0.012)} />
            </pattern>
            <pattern id="grid-major" width={gridStep * 5} height={gridStep * 5} patternUnits="userSpaceOnUse">
              <path d={`M ${gridStep * 5} 0 L 0 0 0 ${gridStep * 5}`} fill="none" stroke="#475569" strokeWidth={Math.max(0.5, gridStep * 0.025)} />
            </pattern>
            <marker id="leading-edge-arrow" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
              <path d="M0,0 L6,3 L0,6 Z" fill="#38bdf8" />
            </marker>
          </defs>}
          <rect x={viewBox.x} y={viewBox.y} width={viewBox.w} height={viewBox.h} fill={viewMode === '3d' ? '#e5e7eb' : '#0f172a'} />
          {viewMode === 'profile' && <><rect x={viewBox.x} y={viewBox.y} width={viewBox.w} height={viewBox.h} fill="url(#grid-minor)" /><rect x={viewBox.x} y={viewBox.y} width={viewBox.w} height={viewBox.h} fill="url(#grid-major)" /></>}

          {viewMode === 'profile' && livePath && (
            <path d={livePath} fill="none" stroke="#f8fafc" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
          )}
          {viewMode === 'profile' && points.length > 0 && (
            <g pointerEvents="none">
              {points.length > 1 && <>
                <path d={`M ${points[0].x} ${points[0].y} L ${points[1].x} ${points[1].y}`} fill="none" stroke="#38bdf8" strokeWidth={5 * labelScale} strokeLinecap="round" opacity="0.9" />
                <g transform={`translate(${(points[0].x + points[1].x) / 2} ${(points[0].y + points[1].y) / 2}) scale(${labelScale})`}>
                  <rect x="-52" y="-30" width="104" height="20" rx="6" fill="#082f49" stroke="#38bdf8" />
                  <text x="0" y="-16" textAnchor="middle" fill="#bae6fd" fontSize="10" fontWeight="800">LEADING EDGE</text>
                </g>
              </>}
              <g transform={`translate(${points[0].x} ${points[0].y}) scale(${labelScale})`}>
                <circle r="9" fill="#16a34a" stroke="#dcfce7" strokeWidth="2" />
                <text y="3.5" textAnchor="middle" fill="#ffffff" fontSize="9" fontWeight="900">S</text>
              </g>
              {points.length > 1 && <g transform={`translate(${points[points.length - 1].x} ${points[points.length - 1].y}) scale(${labelScale})`}>
                <circle r="8" fill="#f59e0b" stroke="#fef3c7" strokeWidth="2" />
                <text y="3.5" textAnchor="middle" fill="#111827" fontSize="9" fontWeight="900">E</text>
              </g>}
            </g>
          )}
{viewMode === 'profile' && points.length >= 2 && points.slice(0, -1).map((a, i) => {
            const b = points[i + 1];
            const mid = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
            const mm = Math.round(dist(a, b) / pxPerMm);
            const active = selectedSegIndex === i;
            return (
              <g key={'lbl-' + i} data-edit-type="length" data-edit-index={i} style={{ cursor: mode === 'edit' ? 'pointer' : 'default' }}>
                <g transform={`translate(${mid.x} ${mid.y}) scale(${labelScale})`}>
                  <rect x="-38" y="-22" width="76" height="24" rx="6" fill={active ? '#0369a1' : '#111827'} stroke={active ? '#7dd3fc' : '#64748b'} strokeWidth="1" fillOpacity="0.98" />
                  <text x="0" y="-7" textAnchor="middle" className="select-none" fill="#f8fafc" fontSize="11" fontWeight="700" fontFamily="ui-monospace, monospace" pointerEvents="none">{i + 1} · {mm} mm</text>
                </g>
              </g>
            );
          })}

          {viewMode === 'profile' && points.length > 2 && points.slice(1, -1).map((pt, index) => {
            const pointIndex = index + 1;
            const angle = selected?.segments[pointIndex - 1]?.angleDeg ?? angleBetween(points[pointIndex - 1], pt, points[pointIndex + 1]);
            const active = selectedSegIndex === pointIndex - 1;
            return (
              <g key={'angle-' + pointIndex} data-edit-type="angle" data-edit-index={pointIndex - 1} style={{ cursor: mode === 'edit' ? 'pointer' : 'default' }}>
                <g transform={`translate(${pt.x + 10} ${pt.y + 10}) scale(${labelScale})`}>
                  <rect width="66" height="24" rx="6" fill={active ? '#0369a1' : '#1e293b'} stroke={active ? '#7dd3fc' : '#64748b'} strokeWidth="1" />
                  <text x="33" y="16" textAnchor="middle" fill="#f8fafc" fontSize="11" fontWeight="700" pointerEvents="none">B{pointIndex} · {angle}°</text>
                </g>
              </g>
            );
          })}

          

          {viewMode === '3d' && points.length >= 2 && (
            <g>
              {modelFaces.map((face) => <polygon key={face.key} points={polygonPoints(face.points)} fill={face.fill} stroke={face.stroke} strokeWidth="1.1" strokeLinejoin="round" />)}
              <text x={viewBox.x + 18} y={viewBox.y + 28} fill="#dc2626" fontSize="13" fontWeight="800">PAINTED FACE · {paintSide.toUpperCase()} (RED)</text>
              <text x={viewBox.x + 18} y={viewBox.y + 47} fill="#4b5563" fontSize="11" fontWeight="700">UNPAINTED FACE · GREY</text>
              <text x={viewBox.x + viewBox.w - 18} y={viewBox.y + viewBox.h - 18} textAnchor="end" fill="#4b5563" fontSize="11">Drag to rotate · Scroll or pinch to zoom</text>
            </g>
          )}
{/* hint */}
          {viewMode === 'profile' && points.length === 0 && mode === 'draw' && (
            <text
              x={viewBox.w / 2}
              y={viewBox.h / 2}
              textAnchor="middle"
              fill="#64748b"
              fontSize="13"
            >
              Tap to add each point. Use Done when the outline is complete.
            </text>
          )}
        </svg>
      </div>

      {/* One contextual input edits whichever dimension is selected in the drawing. */}
      {viewMode === 'profile' && <div className="shrink-0 border-t border-slate-800 bg-slate-950 px-3 py-2 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
        <div className="flex items-center gap-2">
          <div className="min-w-0 flex-1">
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
              {editTarget ? (editTarget.kind === 'length' ? 'Length ' + (editTarget.index + 1) + ' · mm' : 'Bend B' + (editTarget.index + 1) + ' · degrees') : 'Dimension editor'}
            </div>
            <input aria-label="Selected dimension value" type="number" inputMode="decimal" min="1" max={editTarget?.kind === 'angle' ? 179 : 10000}
              disabled={!editTarget || mode !== 'edit'} value={editValue} onChange={(event) => setEditValue(event.target.value)}
              onBlur={commitDimensionEdit}
              onKeyDown={(event) => { if (event.key === 'Enter') { commitDimensionEdit(); (event.currentTarget as HTMLInputElement).blur(); } }}
              placeholder={mode === 'edit' ? 'Select a length or bend on the drawing' : 'Finish drawing to edit dimensions'}
              className="mt-1 w-full min-h-11 rounded-xl border border-slate-700 bg-slate-900 px-3 text-base font-mono font-bold text-white outline-none focus:border-sky-400 disabled:opacity-60" />
          </div>
        </div>
        <div className="mt-2 flex items-center justify-between gap-2">
          <div className="text-[11px] text-slate-400 font-mono">Blank <span className="text-white font-bold">{developed}</span> mm <span className="text-slate-600">·</span> {points.length} points</div>
          <div className="flex gap-1.5">
            {mode === 'draw' ? <>
              <button onClick={undoPoint} className="p-2 rounded-lg bg-slate-800" aria-label="Undo last point"><Undo2 className="w-4 h-4" /></button>
              <button onClick={clearDrawing} className="p-2 rounded-lg bg-slate-800" aria-label="Clear drawing"><X className="w-4 h-4" /></button>
              <button onClick={finishDrawing} className="flex items-center gap-1 px-3 py-2 rounded-lg bg-white text-slate-900 text-xs font-bold"><Check className="w-4 h-4" />Done</button>
            </> : <>
              {editTarget && <button onClick={commitDimensionEdit} className="px-3 py-2 rounded-lg bg-sky-500 text-slate-950 text-xs font-bold">Apply</button>}
              <button onClick={deleteLastEdge} className="p-2 rounded-lg bg-slate-800 text-rose-300" aria-label="Delete last edge"><Trash2 className="w-4 h-4" /></button>
              <button onClick={flipProfile} className="p-2 rounded-lg bg-slate-800" aria-label="Flip profile"><Undo2 className="w-4 h-4" /></button>
              <button onClick={newProfile} className="flex items-center gap-1 px-3 py-2 rounded-lg bg-white text-slate-900 text-xs font-bold"><Plus className="w-4 h-4" />New</button>
            </>}
          </div>
        </div>
        {mode === 'edit' && selected && selected.segments.length > 0 && (
          <div className="mt-2 flex items-center gap-2">
            <span className="text-[10px] text-slate-400 whitespace-nowrap">Change edge</span>
            <select aria-label="Select edge to change" value={selectedSegIndex ?? 0} onChange={(event) => setSelectedSegIndex(Number(event.target.value))} className="w-24 rounded-lg border border-slate-700 bg-slate-900 px-2 py-2 text-xs text-white">
              {selected.segments.map((segment, index) => <option key={segment.id} value={index}>Edge {index + 1}</option>)}
            </select>
            <select aria-label="Edge type" value={selected.segments[selectedSegIndex ?? 0]?.kind || 'leg'} onChange={(event) => {
              const index = selectedSegIndex ?? 0;
              const kind = event.target.value as FlashingSegment['kind'];
              const defaults = SEGMENT_KINDS.find((item) => item.value === kind);
              updateSegmentAt(index, { kind, lengthMm: defaults && (selected.segments[index]?.kind === 'leg' || !selected.segments[index]?.lengthMm) ? defaults.defaultMm : selected.segments[index]?.lengthMm });
            }} className="min-w-0 flex-1 rounded-lg border border-slate-700 bg-slate-900 px-2 py-2 text-xs text-white">
              {SEGMENT_KINDS.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}
            </select>
          </div>
        )}
        {mode === 'edit' && selected && onSaveToLibrary && (
          <div className="mt-2 flex justify-end">
            <button onClick={saveCurrentToLibrary} className="px-3 py-2 rounded-lg border border-emerald-700 bg-emerald-950 text-emerald-200 text-xs font-bold">Save as new library profile</button>
          </div>
        )}
      </div>}

      {/* Profile list sheet */}
      {showSheet && (
        <div className="absolute inset-0 z-50 bg-slate-950/80 flex flex-col justify-end">
          <button
            className="flex-1 cursor-pointer"
            onClick={() => setShowSheet(false)}
            aria-label="Close sheet"
          />
          <div className="bg-slate-900 rounded-t-2xl border-t border-slate-700 max-h-[70vh] overflow-y-auto pb-[max(1rem,env(safe-area-inset-bottom))]">
            <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800">
              <span className="text-sm font-bold">Saved profiles</span>
              <button
                onClick={() => setShowSheet(false)}
                className="p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <ul className="divide-y divide-slate-800">
              {profiles.length === 0 && (
                <li className="px-4 py-8 text-center text-xs text-slate-500">
                  None yet — draw one on the canvas
                </li>
              )}
              {profiles.map((p) => (
                <li key={p.id}>
                  <button
                    onClick={() => {
                      setSelectedId(p.id);
                      setShowSheet(false);
                      setMode('edit');
                    }}
                    className="w-full text-left px-4 py-3 hover:bg-slate-800 cursor-pointer"
                  >
                    <div className="text-sm font-semibold">{p.name}</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">
                      {p.segments.length} legs · blank{' '}
                      {p.developedLengthMm || developedMm(p.segments)} mm
                      {p.paintSide ? ` · paint ${p.paintSide}` : ''}
                    </div>
                  </button>
                </li>
              ))}
            </ul>
            <div className="px-4 pt-2">
              <button
                onClick={newProfile}
                className="w-full py-3 rounded-xl bg-white text-slate-900 text-sm font-bold cursor-pointer"
              >
                New profile
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};